# ShiftCash: Every Table. Every Dollar.

A private, offline financial record for restaurant servers. It tracks every table, cash payment, change, tip, tip-out, shift and end-of-night restaurant settlement, then compares your numbers with the restaurant's checkout report. It is **not** a POS and processes no payments. Everything stays on the phone.

**Start here:** [`docs/PHONE-GUIDE.md`](docs/PHONE-GUIDE.md) explains how to install the web app on Namecheap and build the Android APK on GitHub, all from an Android phone.

| Folder / file | Purpose |
|---|---|
| `www/` | The app: HTML, CSS, JS, local fonts and icons |
| `.github/workflows/build.yml` | Cloud build: tests → web build → Capacitor Android APK |
| `.github/workflows/create-release-key.yml` | One-time creation of your release signing key |
| `scripts/` | `build-web.mjs` (PWA package), `android-setup.mjs` (Capacitor project + version/signing) |
| `tests/` | Accounting, SQLite storage and browser end-to-end tests |
| `hosting/.htaccess` | Apache/cPanel settings (HTTPS, headers, APK type) |
| `android-config/debug.keystore` | Shared *test-only* signing key, so test builds update in place |
| `docs/` | Phone guide, accounting rules, testing |

Features: fast keypad entry (cash, card, split; "tip later"), round-down cash discount by default, configurable rounding engine, change and shortage detection, cash ledger and denomination counter, tip-out rules (fixed or % of sales or tips), breaks, double shifts and overnight shifts, a 4-step settlement wizard with POS comparison and likely causes, transaction history with corrections and audit trail, walkouts, incidents, redactable receipt photos, reports and charts, Tip Records & Taxes with W-2 comparison, encrypted and checksummed backups, CSV exports, privacy PIN, dark mode.
