// ShiftCash — storage layer. Records are never deleted automatically.
// Android app: SQLite (@capacitor-community/sqlite) through SqliteStore.
// Browser / PWA: IndexedDB. Both expose the same API and use the same record migrations.
import { SCHEMA_VERSION, STORES, migrateRecord, checkIntegrity } from './schema.js';
import { SqliteStore } from './sqlite-store.js';
import { openNativeSqlite } from './native.js';

const DB_NAME = 'shiftcash';
const IDB_VERSION = 3; // structural version (object stores / indexes)
let dbp = null;
let sql = null;          // SqliteStore when running natively
export let backendName = 'indexeddb';

/** Select the backend once at startup. */
export async function initStorage() {
  if (sql || dbp) return backendName;
  try {
    const conn = await openNativeSqlite();
    if (conn) {
      sql = await new SqliteStore(conn).init();
      backendName = 'sqlite';
      await migrateSqlite();
      return backendName;
    }
  } catch (e) {
    console.error('SQLite unavailable, falling back to IndexedDB', e);
    sql = null;
  }
  await openDB();
  return backendName;
}

async function migrateSqlite() {
  const from = await sql.getMeta('schemaVersion');
  if (from === undefined) { await sql.setMeta('schemaVersion', SCHEMA_VERSION); await sql.setMeta('createdAt', Date.now()); return; }
  if (from < SCHEMA_VERSION) {
    const ops = [];
    for (const store of STORES) for (const rec of await sql.all(store)) ops.push([store, migrateRecord(store, rec, from)]);
    await sql.putMany(ops); // one atomic transaction
    await sql.setMeta('schemaVersion', SCHEMA_VERSION);
    await sql.setMeta('migratedAt', { at: Date.now(), from });
  }
}

function upgrade(db, oldVersion, tx) {
  // v1: core stores
  if (oldVersion < 1) {
    db.createObjectStore('meta', { keyPath: 'key' });
    db.createObjectStore('settings', { keyPath: 'key' });
    const shifts = db.createObjectStore('shifts', { keyPath: 'id' });
    shifts.createIndex('startedAt', 'startedAt');
    const checks = db.createObjectStore('checks', { keyPath: 'id' });
    checks.createIndex('shiftId', 'shiftId');
    checks.createIndex('createdAt', 'createdAt');
    const moves = db.createObjectStore('moves', { keyPath: 'id' });
    moves.createIndex('shiftId', 'shiftId');
    db.createObjectStore('photos', { keyPath: 'id' });
  }
  // v2: payouts, incidents, audit log, pre-restore snapshots
  if (oldVersion < 2) {
    const payouts = db.createObjectStore('payouts', { keyPath: 'id' });
    payouts.createIndex('shiftId', 'shiftId');
    const inc = db.createObjectStore('incidents', { keyPath: 'id' });
    inc.createIndex('shiftId', 'shiftId');
    const audit = db.createObjectStore('audit', { keyPath: 'id' });
    audit.createIndex('entityId', 'entityId');
    db.createObjectStore('snapshots', { keyPath: 'id' });
  }
  // v3: tip records & taxes (reported tips, W-2 figures, yearly notes)
  if (oldVersion < 3) {
    db.createObjectStore('taxes', { keyPath: 'id' });
  }
}

export function openDB(name = DB_NAME) {
  if (name === DB_NAME && dbp) return dbp;
  const p = new Promise((resolve, reject) => {
    const req = indexedDB.open(name, IDB_VERSION);
    req.onupgradeneeded = e => upgrade(req.result, e.oldVersion, req.transaction);
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { db.close(); location.reload(); };
      resolve(db);
    };
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('Database upgrade blocked — close other ShiftCash tabs.'));
  });
  if (name === DB_NAME) dbp = p.then(async db => { await migrateStoredData(db); return db; });
  return name === DB_NAME ? dbp : p;
}

function reqP(r) { return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
function txDone(tx) { return new Promise((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('Transaction aborted')); }); }

/** Record-level data migrations, applied once per schema bump, inside one transaction. */
async function migrateStoredData(db) {
  const tx = db.transaction(['meta', ...STORES], 'readwrite');
  const meta = tx.objectStore('meta');
  const cur = await reqP(meta.get('schemaVersion'));
  const from = cur ? cur.value : null;
  if (from === null) {
    meta.put({ key: 'schemaVersion', value: SCHEMA_VERSION });
    meta.put({ key: 'createdAt', value: Date.now() });
  } else if (from < SCHEMA_VERSION) {
    for (const store of STORES) {
      const all = await reqP(tx.objectStore(store).getAll());
      for (const rec of all) tx.objectStore(store).put(migrateRecord(store, rec, from));
    }
    meta.put({ key: 'schemaVersion', value: SCHEMA_VERSION });
    meta.put({ key: 'migratedAt', value: Date.now(), from });
  }
  await txDone(tx);
}

export async function get(store, key) {
  if (sql) return store === 'meta' ? undefined : sql.get(store, key);
  const db = await openDB();
  return reqP(db.transaction(store).objectStore(store).get(key));
}
export async function all(store) {
  if (sql) return sql.all(store);
  const db = await openDB();
  return reqP(db.transaction(store).objectStore(store).getAll());
}
export async function byIndex(store, index, value) {
  if (sql) return sql.byIndex(store, index, value);
  const db = await openDB();
  return reqP(db.transaction(store).objectStore(store).index(index).getAll(value));
}
/** Put one or many records atomically. */
export async function put(store, ...recs) {
  await putMany(recs.map(r => [store, r]));
  return recs[0];
}
/** Atomic multi-store write: ops = [[store, record], ...] — every related financial change goes through here. */
export async function putMany(ops) {
  if (sql) return sql.putMany(ops);
  const db = await openDB();
  const stores = [...new Set(ops.map(o => o[0]))];
  const tx = db.transaction(stores, 'readwrite');
  for (const [s, r] of ops) tx.objectStore(s).put(r);
  await txDone(tx);
}
/** Atomic multi-record delete — only for explicit, user-confirmed actions. pairs = [[store, key], ...] */
export async function delMany(pairs) {
  if (!pairs.length) return;
  if (sql) return sql.delMany(pairs);
  const db = await openDB();
  const stores = [...new Set(pairs.map(p => p[0]))];
  const tx = db.transaction(stores, 'readwrite');
  for (const [s, k] of pairs) tx.objectStore(s).delete(k);
  await txDone(tx);
}
/** Save a full copy of the data (restorable from Settings) before anything is deleted. */
export async function snapshot(reason) {
  const snap = { id: 'snap_' + Date.now(), at: Date.now(), reason, data: await exportAll() };
  await put('snapshots', snap);
  return snap.id;
}
/** Only used for explicit, user-confirmed actions (e.g. removing a photo they chose to delete). */
export async function del(store, key) {
  if (sql) return sql.del(store, key);
  const db = await openDB();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).delete(key);
  await txDone(tx);
}
export async function meta(key, value) {
  if (sql) return value === undefined ? sql.getMeta(key) : sql.setMeta(key, value);
  const db = await openDB();
  if (value === undefined) { const r = await reqP(db.transaction('meta').objectStore('meta').get(key)); return r ? r.value : undefined; }
  const tx = db.transaction('meta', 'readwrite'); tx.objectStore('meta').put({ key, value }); await txDone(tx);
}

/** Storage-level + accounting-level integrity check. */
export async function integrityCheck() {
  const problems = [];
  if (sql) problems.push(...await sql.integrity());
  const data = {};
  for (const s of STORES) data[s] = await all(s);
  problems.push(...checkIntegrity(data));
  return { problems, backend: backendName, counts: Object.fromEntries(STORES.map(s => [s, data[s].length])) };
}

// ---------- settings ----------
export const DEFAULT_SETTINGS = {
  restaurantName: '',
  roundingMethod: 'down',        // restaurant gives a cash discount: cash checks round DOWN to the dollar
  roundingTarget: 'ticket',
  roundingHalf: 'up',
  policyCollect: 'rounded',      // restaurant collects the rounded-down (discounted) cash amount
  policyCardTips: 'deduct',
  policyAdjustments: [],
  hourlyWage: 0,
  favoriteTables: ['1', '2', '3', '4', '5', '10', '12', '20'],
  currency: 'USD',
  locale: '',
  theme: 'system',
  pinHash: '', pinSalt: '', pinLockMinutes: 5,
  backupReminderDays: 7,
  lastBackupAt: 0,
  weeklyGoal: 0,
  lunchCutoffHour: 16,
  // master-spec additions
  startingBank: 0,              // default starting change bank
  tipoutRules: [],              // [{ id, name, mode: 'fixed'|'pct_sales'|'pct_tips', cents, bp, via: 'cash'|'deducted' }]
  uiMode: 'simple',             // 'simple' (everyday screen) | 'full' (all features)
  homeScreen: 'home',           // 'home' | 'tables' | 'shift'
  afterSave: 'next',            // 'next' (stay ready for another) | 'home'
  confirmPartial: true,
  confirmDuplicate: true,
  haptics: true,
  retentionYears: 4,
  taxReminder: true,
  allowRoundUp: false,          // when false, no option anywhere can make a customer pay more than the ticket
  qtdNotes: '',                 // user's own notes on qualified-tip deduction rules
};

export async function loadSettings() {
  const rows = await all('settings');
  const s = { ...DEFAULT_SETTINGS };
  for (const r of rows) if (r.key in DEFAULT_SETTINGS) s[r.key] = r.value;
  return s;
}
export async function saveSetting(key, value) { await put('settings', { key, value }); }

// ---------- backup / restore ----------
async function readPhotosAsDataUrls() {
  const photos = await all('photos');
  const out = [];
  for (const p of photos) {
    const { blob, ...rest } = p;
    out.push({ ...rest, dataUrl: blob ? await blobToDataUrl(blob) : p.dataUrl });
  }
  return out;
}
export function blobToDataUrl(blob) {
  return new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(fr.error); fr.readAsDataURL(blob); });
}
export async function dataUrlToBlob(url) { return (await fetch(url)).blob(); }

export async function exportAll({ photos = true } = {}) {
  const data = {};
  for (const s of STORES) data[s] = s === 'photos' ? (photos ? await readPhotosAsDataUrls() : []) : await all(s);
  data.settings = data.settings.filter(r => r.key !== 'pinHash' && r.key !== 'pinSalt'); // PIN is device-local
  return data;
}

/**
 * Restore: mode 'merge' (add/update by id; nothing removed) or 'replace'.
 * Before any restore, a full snapshot of the current database is saved in the "snapshots" store.
 * "replace" never deletes the snapshot, so a bad restore can be undone.
 */
export async function restore(data, mode = 'merge') {
  const snapshot = { id: 'snap_' + Date.now(), at: Date.now(), reason: 'Before restore (' + mode + ')', data: await exportAll() };
  await put('snapshots', snapshot);
  const ops = [];
  for (const s of STORES) {
    for (const r of data[s] || []) {
      if (s === 'photos' && r.dataUrl && !sql) { const { dataUrl, ...rest } = r; rest.blob = dataUrlToBlobSync(dataUrl); ops.push([s, rest]); }
      else ops.push([s, r]);
    }
  }
  const replaceStores = mode === 'replace' ? STORES.filter(s => s !== 'settings') : [];
  if (sql) { await sql.replaceStores(replaceStores, ops); return snapshot.id; }
  const db = await openDB();
  const tx = db.transaction(STORES, 'readwrite');
  for (const s of replaceStores) tx.objectStore(s).clear();
  for (const [s, r] of ops) tx.objectStore(s).put(r);
  await txDone(tx);
  return snapshot.id;
}

export function dataUrlToBlobSync(url) {
  const [head, b64] = url.split(',');
  const mime = head.match(/data:([^;]+)/)[1];
  const bin = atob(b64); const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type: mime });
}

export async function listSnapshots() { return (await all('snapshots')).map(s => ({ id: s.id, at: s.at, reason: s.reason })); }
export async function restoreSnapshot(id) { const s = await get('snapshots', id); if (!s) throw new Error('Snapshot not found'); return restore(s.data, 'replace'); }

export async function storageInfo() {
  const out = { persisted: null, usage: null, quota: null };
  try { if (navigator.storage?.persisted) out.persisted = await navigator.storage.persisted(); } catch {}
  try { if (navigator.storage?.estimate) { const e = await navigator.storage.estimate(); out.usage = e.usage; out.quota = e.quota; } } catch {}
  return out;
}
export async function requestPersist() {
  try { return navigator.storage?.persist ? await navigator.storage.persist() : false; } catch { return false; }
}

export function uid(prefix = '') {
  const a = new Uint8Array(9); crypto.getRandomValues(a);
  return prefix + Date.now().toString(36) + Array.from(a, b => (b % 36).toString(36)).join('');
}

/** Append-only local audit log entry. */
export function auditEntry(entity, entityId, action, before, after, reason = '') {
  return { id: uid('a'), entity, entityId, action, before: before ?? null, after: after ?? null, reason, at: Date.now() };
}
