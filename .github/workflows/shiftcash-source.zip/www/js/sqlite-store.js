// ShiftCash — SQLite record store (used inside the Android app).
// Works with any connection object that offers:
//   exec(sql)                 – run DDL / statements without results
//   query(sql, values) → rows – SELECT
//   executeSet(set)           – [{ statement, values }] executed atomically in ONE transaction
// The Android app supplies a connection backed by @capacitor-community/sqlite (see native.js);
// the automated tests supply one backed by Node's built-in SQLite engine.

export const DDL = [
  `CREATE TABLE IF NOT EXISTS records (
     store TEXT NOT NULL,
     id TEXT NOT NULL,
     shift_id TEXT,
     entity_id TEXT,
     updated_at INTEGER NOT NULL,
     data TEXT NOT NULL,
     PRIMARY KEY (store, id))`,
  `CREATE INDEX IF NOT EXISTS idx_records_shift ON records(store, shift_id)`,
  `CREATE INDEX IF NOT EXISTS idx_records_entity ON records(store, entity_id)`,
  `CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
];

const keyOf = (store, rec) => (store === 'settings' || store === 'meta' ? rec.key : rec.id);

export class SqliteStore {
  constructor(conn) { this.conn = conn; }

  async init() { for (const s of DDL) await this.conn.exec(s); return this; }

  #row(store, rec) {
    const id = keyOf(store, rec);
    if (typeof id !== 'string' || !id) throw new Error(`Record in ${store} has no id`);
    return { statement: 'INSERT OR REPLACE INTO records (store, id, shift_id, entity_id, updated_at, data) VALUES (?, ?, ?, ?, ?, ?)',
      values: [store, id, rec.shiftId ?? null, rec.entityId ?? null, Date.now(), JSON.stringify(rec)] };
  }
  #parse(rows) {
    const out = [];
    for (const r of rows) { try { out.push(JSON.parse(r.data)); } catch { /* reported by integrity() */ } }
    return out;
  }

  async get(store, key) {
    const rows = await this.conn.query('SELECT data FROM records WHERE store = ? AND id = ?', [store, key]);
    return this.#parse(rows)[0];
  }
  async all(store) { return this.#parse(await this.conn.query('SELECT data FROM records WHERE store = ? ORDER BY rowid', [store])); }
  async byIndex(store, index, value) {
    const col = index === 'shiftId' ? 'shift_id' : index === 'entityId' ? 'entity_id' : null;
    if (!col) return (await this.all(store)).filter(r => r[index] === value);
    return this.#parse(await this.conn.query(`SELECT data FROM records WHERE store = ? AND ${col} = ? ORDER BY rowid`, [store, value]));
  }
  /** ops: [[store, record], ...] — all-or-nothing. */
  async putMany(ops) { if (ops.length) await this.conn.executeSet(ops.map(([s, r]) => this.#row(s, r))); }
  async del(store, key) { await this.conn.executeSet([{ statement: 'DELETE FROM records WHERE store = ? AND id = ?', values: [store, key] }]); }
  /** Atomic replace of whole stores (used by restore "replace"). */
  async replaceStores(stores, ops) {
    const set = stores.map(s => ({ statement: 'DELETE FROM records WHERE store = ?', values: [s] }));
    for (const [s, r] of ops) set.push(this.#row(s, r));
    await this.conn.executeSet(set);
  }
  async getMeta(key) {
    const rows = await this.conn.query('SELECT value FROM meta WHERE key = ?', [key]);
    return rows.length ? JSON.parse(rows[0].value) : undefined;
  }
  async setMeta(key, value) { await this.conn.executeSet([{ statement: 'INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)', values: [key, JSON.stringify(value)] }]); }

  /** SQLite's own integrity check plus a JSON check of every row. */
  async integrity() {
    const problems = [];
    try {
      const r = await this.conn.query('PRAGMA integrity_check', []);
      const v = r[0] && (r[0].integrity_check ?? Object.values(r[0])[0]);
      if (v !== 'ok') problems.push('SQLite integrity_check: ' + v);
    } catch (e) { problems.push('integrity_check unavailable: ' + e.message); }
    const rows = await this.conn.query('SELECT store, id, data FROM records', []);
    for (const r of rows) { try { JSON.parse(r.data); } catch { problems.push(`Unreadable record ${r.store}/${r.id}`); } }
    return problems;
  }
  async count() { const r = await this.conn.query('SELECT store, COUNT(*) AS n FROM records GROUP BY store', []); return Object.fromEntries(r.map(x => [x.store, x.n])); }
}
