// ShiftCash — native (Capacitor / Android) integration with safe browser fallbacks.
// Plugins are reached through window.Capacitor.Plugins, so no bundler is needed.

export const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const P = name => window.Capacitor?.Plugins?.[name];
export const platform = () => window.Capacitor?.getPlatform?.() || 'web';

const DB = 'shiftcash';

/** Connection object for SqliteStore, backed by @capacitor-community/sqlite. Returns null if unavailable. */
export async function openNativeSqlite() {
  const S = P('CapacitorSQLite');
  if (!isNative() || !S) return null;
  try { await S.closeConnection({ database: DB, readonly: false }); } catch { /* not open yet */ }
  await S.createConnection({ database: DB, version: 1, encrypted: false, mode: 'no-encryption', readonly: false });
  await S.open({ database: DB, readonly: false });
  const rows = r => {
    let v = (r && r.values) || [];
    // iOS returns a leading { ios_columns: [...] } row
    if (v.length && v[0] && v[0].ios_columns) v = v.slice(1);
    return v;
  };
  return {
    kind: 'sqlite',
    exec: sql => S.execute({ database: DB, statements: sql, transaction: false, readonly: false }),
    query: async (sql, values = []) => rows(await S.query({ database: DB, statement: sql, values, readonly: false })),
    executeSet: set => S.executeSet({ database: DB, set, transaction: true, readonly: false }),
  };
}

/**
 * Save a text file. Android: written to Documents/ShiftCash then the share sheet opens
 * (Drive, email, Files…). Browser: normal download.
 */
export async function saveFile(filename, text, mime = 'application/json', { share = true } = {}) {
  const FS = P('Filesystem');
  if (isNative() && FS) {
    const path = 'ShiftCash/' + filename;
    let res;
    try { res = await FS.writeFile({ path, data: text, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true }); }
    catch { res = await FS.writeFile({ path, data: text, directory: 'DATA', encoding: 'utf8', recursive: true }); }
    const Sh = P('Share');
    if (share && Sh) { try { await Sh.share({ title: filename, url: res.uri, dialogTitle: 'Save or share ShiftCash file' }); } catch { /* user cancelled */ } }
    return { saved: true, where: 'Documents/ShiftCash/' + filename, uri: res.uri };
  }
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return { saved: true, where: 'Downloads' };
}

export function haptic(ms = 10) {
  const H = P('Haptics');
  if (isNative() && H) { H.impact({ style: 'LIGHT' }).catch(() => {}); return; }
  try { navigator.vibrate?.(ms); } catch {}
}

/** Android lifecycle hooks (pause/resume/back button). */
export function onLifecycle({ pause, resume, back }) {
  const A = P('App');
  if (!isNative() || !A) return;
  if (pause) A.addListener('pause', pause);
  if (resume) A.addListener('resume', resume);
  if (back) A.addListener('backButton', back);
}
export function exitApp() { P('App')?.exitApp?.(); }
export async function appInfo() { try { return await P('App')?.getInfo?.(); } catch { return null; } }
