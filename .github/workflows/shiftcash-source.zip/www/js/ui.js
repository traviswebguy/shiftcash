// ShiftCash — safe templating + UI primitives (sheets, dialogs, flash messages).
// All interpolated values are HTML-escaped unless explicitly wrapped with raw() by trusted code.

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' };
export const esc = s => String(s).replace(/[&<>"'`]/g, c => ESC[c]);
export const raw = s => ({ __raw: String(s) });
function render(v) {
  if (v === null || v === undefined || v === false) return '';
  if (Array.isArray(v)) return v.map(render).join('');
  if (typeof v === 'object' && '__raw' in v) return v.__raw;
  return esc(v);
}
export function html(strings, ...vals) {
  let out = strings[0];
  for (let i = 0; i < vals.length; i++) out += render(vals[i]) + strings[i + 1];
  return raw(out);
}
export function setHTML(el, tpl) { el.innerHTML = tpl.__raw; }
export const icon = (name, cls = '') => raw(`<svg class="i ${esc(cls)}" aria-hidden="true"><use href="#i-${esc(name)}"/></svg>`);
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

// ---------- dates ----------
export const fmtTime = t => t ? new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '—';
export const fmtDate = t => new Date(t).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
export const fmtDateLong = t => new Date(t).toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
export const fmtDur = ms => { const m = Math.floor(ms / 60000); return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`; };
export const dayKey = t => { const d = new Date(t); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const toLocalInput = t => { const d = new Date(t); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
export const fromLocalInput = s => { const t = new Date(s).getTime(); return Number.isFinite(t) ? t : null; };

// ---------- sheets ----------
const stack = [];
/**
 * Open a sheet. opts: { title, sub, full, body(tpl), foot(tpl), onClose, onMount(el), className }
 * Returns a controller { el, body, update(tpl), close() }.
 */
export function openSheet(opts) {
  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  const el = document.createElement('section');
  el.className = 'sheet' + (opts.full ? ' full' : '') + (opts.className ? ' ' + opts.className : '');
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true');
  setHTML(el, html`
    <div class="sheet-head">
      ${opts.back ? html`<button class="iconbtn" data-sheet-close aria-label="Back">${icon('back')}</button>` : ''}
      <h2>${opts.title || ''}${opts.sub ? html`<div class="sub">${opts.sub}</div>` : ''}</h2>
      ${opts.headExtra || ''}
      ${opts.back ? '' : html`<button class="iconbtn" data-sheet-close aria-label="Close">${icon('close')}</button>`}
    </div>
    <div class="sheet-body"></div>
    ${opts.foot ? html`<div class="sheet-foot"></div>` : ''}
    ${opts.after ? opts.after : ''}`);
  document.body.append(scrim, el);
  const ctl = {
    el, scrim,
    body: el.querySelector('.sheet-body'),
    foot: el.querySelector('.sheet-foot'),
    update(tpl) { const st = this.body.scrollTop; setHTML(this.body, tpl); this.body.scrollTop = st; },
    setFoot(tpl) { if (this.foot) setHTML(this.foot, tpl); },
    close(result) {
      if (ctl.closed) return; ctl.closed = true;
      const i = stack.indexOf(ctl); if (i >= 0) stack.splice(i, 1);
      el.classList.remove('show'); scrim.classList.remove('show');
      setTimeout(() => { el.remove(); scrim.remove(); }, 260);
      if (opts.onClose) opts.onClose(result);
      if (!stack.length) document.body.style.overflow = '';
    },
  };
  if (opts.body) ctl.update(opts.body);
  if (opts.foot) ctl.setFoot(opts.foot);
  scrim.addEventListener('click', () => { if (!opts.modal) ctl.close(); });
  el.addEventListener('click', e => { if (e.target.closest('[data-sheet-close]')) ctl.close(); });
  stack.push(ctl);
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => { scrim.classList.add('show'); el.classList.add('show'); });
  if (opts.onMount) opts.onMount(ctl);
  return ctl;
}
export function topSheet() { return stack[stack.length - 1]; }
export function closeAllSheets() { [...stack].reverse().forEach(s => s.close()); }
window.addEventListener('keydown', e => { if (e.key === 'Escape' && stack.length) topSheet().close(); });

// ---------- dialogs ----------
export function confirmDialog({ title, message, ok = 'Confirm', cancel = 'Cancel', danger = false }) {
  return new Promise(resolve => {
    let done = false;
    const s = openSheet({
      title,
      body: html`<p style="margin:4px 2px 4px;color:var(--ink-2)">${message}</p>`,
      foot: html`<div class="btnrow"><button class="btn" data-x="no">${cancel}</button><button class="btn ${danger ? 'danger' : 'primary'}" data-x="yes">${ok}</button></div>`,
      onClose: () => { if (!done) resolve(false); },
    });
    s.foot.addEventListener('click', e => {
      const b = e.target.closest('[data-x]'); if (!b) return;
      done = true; resolve(b.dataset.x === 'yes'); s.close();
    });
  });
}

/** Ask for a reason (required for corrections, voids). Resolves to string or null. */
export function promptDialog({ title, label, placeholder = '', ok = 'Save', required = true, value = '', multiline = false }) {
  return new Promise(resolve => {
    let done = false;
    const s = openSheet({
      title,
      body: html`<label class="field"><span>${label}</span>
        ${multiline ? html`<textarea class="input" maxlength="500" placeholder="${placeholder}">${value}</textarea>` : html`<input class="input" maxlength="200" placeholder="${placeholder}" value="${value}">`}</label>`,
      foot: html`<div class="btnrow"><button class="btn" data-x="no">Cancel</button><button class="btn primary" data-x="yes">${ok}</button></div>`,
      onClose: () => { if (!done) resolve(null); },
      onMount: c => setTimeout(() => c.body.querySelector('input,textarea')?.focus(), 280),
    });
    s.foot.addEventListener('click', e => {
      const b = e.target.closest('[data-x]'); if (!b) return;
      if (b.dataset.x === 'no') { s.close(); return; }
      const v = s.body.querySelector('input,textarea').value.trim();
      if (required && !v) { s.body.querySelector('input,textarea').focus(); return; }
      done = true; resolve(v); s.close();
    });
  });
}

// ---------- flash ----------
let flashTimer;
export function flash(message, actions = [], ms = 4200) {
  const el = document.getElementById('flash');
  setHTML(el, html`<div class="grow">${message}</div>${actions.map((a, i) => html`<button data-flash="${i}">${a.label}</button>`)}`);
  el.onclick = e => {
    const b = e.target.closest('[data-flash]'); if (!b) return;
    actions[+b.dataset.flash].run(); el.classList.remove('show');
  };
  el.classList.add('show');
  clearTimeout(flashTimer);
  flashTimer = setTimeout(() => el.classList.remove('show'), ms);
}

export function download(filename, text, type = 'application/octet-stream') {
  const blob = text instanceof Blob ? text : new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function vibrate(ms = 12) { try { navigator.vibrate?.(ms); } catch {} }
