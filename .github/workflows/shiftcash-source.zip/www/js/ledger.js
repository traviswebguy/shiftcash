// ShiftCash — shift accounting, cash ledger and restaurant settlement.
// Pure functions: no DOM, no storage. Shared by the app, reports and the test-suite.
import { computePayment, roundDollar, pctOf, fmt } from './money.js';

export const MOVE_TYPES = {
  tipout:    { label: 'Tip-out',                     sign: -1 },
  withdraw:  { label: 'Cash removed from apron',     sign: -1 },
  add:       { label: 'Cash added to apron',         sign: +1 },
  drop:      { label: 'Cash paid to restaurant',     sign: -1 },
  other_in:  { label: 'Other cash in',               sign: +1 },
  other_out: { label: 'Other cash out',              sign: -1 },
};

export const PAYOUT_VIA = {
  cash: 'Paid in cash',
  settlement: 'Deducted from settlement',
  payroll: 'Paid through payroll',
  later: 'Paid at a later date',
  other: 'Other',
};

export const DEFAULT_POLICY = {
  collect: 'original',      // 'original' | 'rounded' — which cash figure the restaurant collects
  cardTips: 'deduct',       // 'deduct' | 'separate' | 'payroll' | 'later'
  adjustments: [],          // [{ label, cents }] standing custom adjustments added to the amount owed
};

/** Net billable amount of one check (original ticket minus discounts and comps). */
export function checkNetDue(check) {
  return Math.max(0, (check.ticketCents | 0) - (check.discountCents | 0) - (check.compCents | 0));
}

/** Per-check derived state. */
export function checkState(check) {
  const pays = (check.payments || []).filter(p => !p.voided).map(p => ({ raw: p, c: computePayment(p) })).filter(x => x.c);
  const netDue = checkNetDue(check);
  let applied = 0, refunds = 0;
  for (const { c } of pays) {
    if (c.method === 'refund') refunds += c.amount; else applied += c.due;
  }
  const balance = check.voided ? 0 : netDue - applied;
  const methods = new Set(pays.filter(x => x.c.method !== 'refund').map(x => x.c.method));
  const kind = methods.size > 1 || pays.filter(x => x.c.method !== 'refund').length > 1 ? 'split' : (methods.values().next().value || 'open');
  const flags = new Set();
  for (const { c } of pays) for (const w of c.warnings) flags.add(w.code);
  if (check.walkout && !check.voided) flags.add('walkout');
  else if (balance > 0 && !check.voided) flags.add('balance');
  if (balance < 0 && !check.voided) flags.add('overpaid');
  return { netDue, applied, refunds, balance, kind, payments: pays, flags: [...flags], status: check.voided ? 'void' : balance > 0 ? (applied > 0 ? 'partial' : 'open') : 'paid' };
}

/** Hours worked in milliseconds, after unpaid breaks. Handles shifts crossing midnight (absolute timestamps). */
export function workedMs(shift, now = Date.now()) {
  if (!shift || !shift.startedAt) return 0;
  const end = shift.endedAt || now;
  let ms = Math.max(0, end - shift.startedAt);
  for (const b of shift.breaks || []) {
    if (b.paid) continue;
    const bs = Math.max(b.start, shift.startedAt);
    const be = Math.min(b.end || now, end);
    if (be > bs) ms -= (be - bs);
  }
  return Math.max(0, ms);
}

export function breakMs(shift, now = Date.now()) {
  let ms = 0;
  for (const b of shift.breaks || []) ms += Math.max(0, (b.end || now) - b.start);
  return ms;
}

/**
 * Summarize one shift.
 *   shift   – shift record
 *   checks  – checks belonging to the shift
 *   moves   – cash ledger movements of the shift
 *   payouts – card-tip payouts attributed to the shift
 *   policy  – settlement policy (falls back to shift.policy, then DEFAULT_POLICY)
 */
export function summarizeShift({ shift, checks = [], moves = [], payouts = [], policy, now = Date.now() }) {
  const pol = { ...DEFAULT_POLICY, ...(shift?.policy || {}), ...(policy || {}) };
  const s = {
    billed: 0, cashSales: 0, cardSales: 0, refundsCash: 0, refundsCard: 0,
    cashDueOriginal: 0, cashDueRounded: 0, roundingAdj: 0,
    cardTips: 0, cashTipsConfirmed: 0, cashTipsExtra: 0, cashTips: 0,
    unconfirmedExcess: 0, overChange: 0, outstanding: 0, discounts: 0, comps: 0,
    walkouts: 0, walkoutAmount: 0, cashTipsPending: 0, cardTipsPending: 0, cardTipsDisputed: 0, cardTipsConfirmed: 0,
    paymentsCashIn: 0, cashReceived: 0, changeGiven: 0,
    checks: 0, payments: 0, voidedChecks: 0, tables: 0, visits: 0,
    bySegment: { lunch: { tips: 0, sales: 0, checks: 0 }, dinner: { tips: 0, sales: 0, checks: 0 } },
  };
  const tables = new Set(), visits = new Set();
  for (const ch of checks) {
    if (ch.voided) { s.voidedChecks++; continue; }
    const st = checkState(ch);
    s.checks++;
    s.billed += st.netDue;
    s.discounts += ch.discountCents | 0;
    s.comps += ch.compCents | 0;
    if (ch.walkout) { s.walkouts++; s.walkoutAmount += Math.max(0, st.balance); }
    else if (st.balance > 0) s.outstanding += st.balance;
    tables.add(String(ch.table));
    visits.add(ch.visitId || ch.id);
    const seg = s.bySegment[ch.segment === 'lunch' ? 'lunch' : 'dinner'];
    seg.checks++;
    for (const { c } of st.payments) {
      s.payments++;
      s.paymentsCashIn += c.cashIn;
      if (c.method === 'cash') {
        s.cashSales += c.due;
        s.cashDueOriginal += c.due;
        s.cashDueRounded += c.roundedDue;
        s.roundingAdj += c.roundingAdj;
        if (c.tipPending) s.cashTipsPending++;
        s.cashTipsConfirmed += c.keptTip;
        s.cashTipsExtra += c.extraTip;
        s.unconfirmedExcess += c.unconfirmed;
        s.overChange += c.shortage;
        s.cashReceived += c.received;
        s.changeGiven += c.changeGiven;
        seg.sales += c.due; seg.tips += c.cashTip;
      } else if (c.method === 'card') {
        s.cardSales += c.due;
        s.cardTips += c.tip;
        if (c.tipStatus === 'pending') s.cardTipsPending++;
        if (c.tipStatus === 'disputed') s.cardTipsDisputed += c.tip;
        if (c.tipStatus === 'confirmed') s.cardTipsConfirmed += c.tip;
        s.cashTipsExtra += c.extraCashTip;
        seg.sales += c.due; seg.tips += c.tip + c.extraCashTip;
      } else if (c.method === 'refund') {
        if (c.via === 'cash') { s.refundsCash += c.amount; s.cashSales -= c.amount; }
        else { s.refundsCard += c.amount; s.cardSales -= c.amount; }
        seg.sales -= c.amount;
      }
    }
  }
  s.tables = tables.size;
  s.visits = visits.size;
  s.cashTips = s.cashTipsConfirmed + s.cashTipsExtra;
  s.totalTips = s.cashTips + s.cardTips;
  s.totalSales = s.cashSales + s.cardSales;

  // Cash ledger movements
  s.tipoutsCash = 0; s.tipoutsDeducted = 0; s.withdrawn = 0; s.added = 0; s.drops = 0; s.otherIn = 0; s.otherOut = 0;
  for (const m of moves) {
    if (m.voided) continue;
    const a = Math.max(0, m.amount | 0);
    switch (m.type) {
      case 'tipout': if (m.via === 'deducted') s.tipoutsDeducted += a; else s.tipoutsCash += a; break;
      case 'withdraw': s.withdrawn += a; break;
      case 'add': s.added += a; break;
      case 'drop': s.drops += a; break;
      case 'other_in': s.otherIn += a; break;
      case 'other_out': s.otherOut += a; break;
    }
  }
  s.tipouts = s.tipoutsCash + s.tipoutsDeducted;

  // Card-tip payouts
  s.cardTipsPaid = 0; s.cardTipsPaidCashInApron = 0; s.cardTipsBySettlement = 0;
  for (const p of payouts) {
    if (p.voided) continue;
    const a = Math.max(0, p.amount | 0);
    s.cardTipsPaid += a;
    if (p.via === 'cash' && p.inApron) s.cardTipsPaidCashInApron += a;
    if (p.via === 'settlement') s.cardTipsBySettlement += a;
  }
  s.cardTipsOutstanding = Math.max(0, s.cardTips - s.cardTipsPaid);
  s.tipsReceived = s.cashTips + Math.min(s.cardTipsPaid, s.cardTips);
  s.netTips = s.totalTips - s.tipouts;

  // Physical cash expected in the apron (before settling with the restaurant)
  s.startingCash = shift?.startingCash | 0;
  s.expectedCash = s.startingCash + s.paymentsCashIn + s.added + s.otherIn + s.cardTipsPaidCashInApron
    - s.tipoutsCash - s.withdrawn - s.drops - s.otherOut;

  // Restaurant settlement (separate from physical cash)
  s.owed = expectedOwed(s, pol, shift?.settlement?.adjustments);
  s.expectedTakeHome = s.expectedCash - s.owed;

  // Time
  s.workedMs = workedMs(shift, now);
  s.breakMs = shift ? breakMs(shift, now) : 0;
  s.hours = s.workedMs / 3_600_000;
  s.tipsPerHour = s.hours >= 0.25 ? Math.round(s.netTips / s.hours) : 0; // too short to be meaningful under 15 min
  s.wage = shift?.hourlyWage ? Math.round((shift.hourlyWage | 0) * s.hours) : 0;
  s.avgTipPct = s.totalSales > 0 ? Math.round(s.totalTips / s.totalSales * 1000) / 10 : 0;
  s.avgTicket = s.checks > 0 ? Math.round(s.billed / s.checks) : 0;
  s.policy = pol;
  return s;
}

/**
 * Expected amount owed to the restaurant (positive = server pays restaurant; negative = restaurant owes server).
 *   + cash sales collected (original or rounded, per policy), net of cash refunds
 *   − card tips, when the policy deducts them from the amount owed (minus any already paid separately)
 *   + tip-outs the restaurant pays on the server's behalf ("deducted")
 *   − cash already paid to the restaurant during the shift (drops)
 *   + custom adjustments
 */
export function expectedOwed(s, policy, extraAdjustments = []) {
  const pol = { ...DEFAULT_POLICY, ...(policy || {}) };
  let owed = (pol.collect === 'rounded' ? s.cashDueRounded : s.cashDueOriginal) - s.refundsCash;
  if (pol.cardTips === 'deduct') {
    const alreadyPaidOutside = s.cardTipsPaid - s.cardTipsBySettlement;
    owed -= Math.max(0, s.cardTips - alreadyPaidOutside);
  }
  owed += s.tipoutsDeducted;
  owed -= s.drops;
  for (const a of [...(pol.adjustments || []), ...(extraAdjustments || [])]) owed += a.cents | 0;
  return owed;
}

/**
 * Compare tracked figures with the restaurant's reported POS checkout.
 * reported: { cashSales, cardSales, totalSales, cardTips, tipouts, settlement, other }
 * Missing reported values (null/undefined) are skipped. Differences are reported − tracked.
 * Nothing is forced to balance.
 */
export function compareReported(s, reported = {}) {
  const rows = [
    ['cashSales', 'Cash sales', s.cashSales],
    ['cardSales', 'Card sales', s.cardSales],
    ['totalSales', 'Total sales', s.totalSales],
    ['cardTips', 'Card tips', s.cardTips],
    ['tipouts', 'Tip-outs', s.tipouts],
    ['settlement', 'Settlement amount', s.owed],
  ];
  const out = [];
  for (const [key, label, tracked] of rows) {
    const r = reported[key];
    if (!Number.isSafeInteger(r)) continue;
    out.push({ key, label, tracked, reported: r, diff: r - tracked });
  }
  if (Number.isSafeInteger(reported.other) && reported.other !== 0) {
    out.push({ key: 'other', label: 'Other adjustments', tracked: 0, reported: reported.other, diff: reported.other });
  }
  return out;
}

/** Explain a comparison difference in neutral, non-accusatory terms. */
export function describeDiff(row) {
  if (row.diff === 0) return 'Matches';
  const more = row.diff > 0;
  switch (row.key) {
    case 'cardTips': return more ? 'Restaurant reports more card tips than you tracked' : 'Possible missing card tips — restaurant reports less than you tracked';
    case 'settlement': return more ? 'Restaurant expects more than you calculated' : 'Restaurant expects less than you calculated';
    case 'tipouts': return more ? 'Restaurant shows higher tip-outs' : 'Restaurant shows lower tip-outs';
    default: return more ? 'Restaurant reports more than you tracked' : 'Restaurant reports less than you tracked';
  }
}

/**
 * Final settlement outcome. Nothing is forced to balance.
 * st: { reported, paidToRestaurant, receivedFromRestaurant, actualPaid (legacy net), cardTipsCredited, cardTipsCash,
 *       countedCash (before settling), countedAfter (after settling), closedAt }
 */
export function finalSummary(s, st = {}) {
  const rows = compareReported(s, st.reported || {});
  const isInt = Number.isSafeInteger;
  let actualPaid = null;
  if (isInt(st.paidToRestaurant) || isInt(st.receivedFromRestaurant)) actualPaid = (st.paidToRestaurant | 0) - (st.receivedFromRestaurant | 0);
  else if (isInt(st.actualPaid)) actualPaid = st.actualPaid;
  const counted = isInt(st.countedCash) ? st.countedCash : null;
  const countedAfter = isInt(st.countedAfter) ? st.countedAfter : null;
  // Card-tip payouts entered in the settlement become payout records when the shift closes.
  // Before closing they are "pending" and must be added; afterwards they are already in s.cardTipsPaid.
  const pending = st.closedAt ? 0 : (st.cardTipsCredited | 0) + (st.cardTipsCash | 0);
  const cardCash = st.cardTipsCash | 0;
  const cashDiscrepancy = counted === null ? null : counted - s.expectedCash;
  const paymentDiff = actualPaid === null ? null : actualPaid - s.owed;
  const expectedAfter = (counted ?? s.expectedCash) - (actualPaid ?? s.owed) + cardCash;
  const afterDiscrepancy = countedAfter === null ? null : countedAfter - expectedAfter;
  const takeHome = countedAfter !== null ? countedAfter : (counted === null || actualPaid === null ? null : counted - actualPaid + cardCash);
  const cardPaid = Math.min(s.cardTips, s.cardTipsPaid + pending);
  const cardTipsOutstanding = Math.max(0, s.cardTips - s.cardTipsPaid - pending);
  const issues = [];
  for (const r of rows) if (r.diff !== 0) issues.push({ label: r.label, cents: r.diff, note: describeDiff(r), key: r.key });
  if (cashDiscrepancy) issues.push({ label: 'Counted cash vs expected', cents: cashDiscrepancy, note: cashDiscrepancy > 0 ? 'Cash overage' : 'Cash shortage', key: 'cash' });
  if (afterDiscrepancy) issues.push({ label: 'Cash after settlement vs expected', cents: afterDiscrepancy, note: afterDiscrepancy > 0 ? 'More cash left than expected' : 'Less cash left than expected', key: 'cashAfter' });
  if (paymentDiff) issues.push({ label: 'Paid vs expected owed', cents: paymentDiff, note: paymentDiff > 0 ? 'Paid more than calculated' : 'Paid less than calculated', key: 'paid' });
  if (s.unconfirmedExcess) issues.push({ label: 'Unconfirmed excess cash', cents: s.unconfirmedExcess, note: 'Kept change not confirmed as a tip', key: 'unconfirmed' });
  if (s.overChange) issues.push({ label: 'Possible cash shortage (excess change)', cents: -s.overChange, note: 'More change returned than expected', key: 'overchange' });
  if (s.outstanding) issues.push({ label: 'Unpaid check balances', cents: s.outstanding, note: 'Checks with an outstanding balance', key: 'balance' });
  if (s.walkoutAmount) issues.push({ label: 'Walkouts', cents: -s.walkoutAmount, note: `${s.walkouts} unpaid walkout check(s)`, key: 'walkout' });
  if (s.cardTipsPending + s.cashTipsPending) issues.push({ label: 'Tips not entered yet', cents: 0, note: `${s.cardTipsPending + s.cashTipsPending} table payment(s) still waiting for the tip amount`, key: 'pending' });
  return {
    rows,
    earned: s.totalTips,
    netTips: s.netTips,
    tipouts: s.tipouts,
    owesExpected: s.owed,
    owesReported: isInt(st.reported?.settlement) ? st.reported.settlement : null,
    actualPaid,
    paidToRestaurant: isInt(st.paidToRestaurant) ? st.paidToRestaurant : (actualPaid !== null && actualPaid > 0 ? actualPaid : null),
    receivedFromRestaurant: isInt(st.receivedFromRestaurant) ? st.receivedFromRestaurant : null,
    received: s.cashTips + cardPaid,
    startingCashReturned: s.startingCash,
    cardTipsOutstanding,
    cashDiscrepancy, afterDiscrepancy, expectedAfter, paymentDiff, takeHome,
    netTakeHomeIncome: takeHome === null ? null : takeHome - s.startingCash,
    expectedTakeHome: s.expectedTakeHome + cardCash,
    status: issues.length ? 'unresolved' : 'balanced',
    issues,
  };
}

/**
 * Point to transactions or categories that could explain a comparison difference.
 * Returns [{ text, checkId? }] — hints only, never conclusions.
 */
export function explainDiff(row, checks = [], s = null) {
  const hints = [];
  const d = Math.abs(row.diff);
  if (!d) return hints;
  const live = checks.filter(c => !c.voided);
  for (const c of live) {
    for (const p of (c.payments || []).filter(p => !p.voided)) {
      const x = computePayment(p); if (!x) continue;
      if (row.key === 'cardTips' && x.method === 'card') {
        if (x.tipStatus === 'pending') hints.push({ text: `Table ${c.table}: card tip not entered yet`, checkId: c.id });
        else if (x.tip === d) hints.push({ text: `Table ${c.table}: card tip of ${fmt(x.tip)} matches the difference`, checkId: c.id });
        else if (x.tipStatus === 'disputed') hints.push({ text: `Table ${c.table}: disputed card tip ${fmt(x.tip)}`, checkId: c.id });
      }
      if ((row.key === 'cashSales' || row.key === 'totalSales' || row.key === 'settlement') && x.method === 'cash' && x.due === d)
        hints.push({ text: `Table ${c.table}: cash payment of ${fmt(x.due)} matches the difference`, checkId: c.id });
      if ((row.key === 'cardSales' || row.key === 'totalSales') && x.method === 'card' && x.due === d)
        hints.push({ text: `Table ${c.table}: card payment of ${fmt(x.due)} matches the difference`, checkId: c.id });
    }
    if (['cashSales', 'cardSales', 'totalSales'].includes(row.key) && ((c.discountCents | 0) === d || (c.compCents | 0) === d))
      hints.push({ text: `Table ${c.table}: discount/comp of ${fmt(d)}`, checkId: c.id });
    if (['cashSales', 'totalSales', 'settlement'].includes(row.key) && checkState(c).balance === d)
      hints.push({ text: `Table ${c.table}: unpaid balance of ${fmt(d)}`, checkId: c.id });
  }
  if (s) {
    if (['cashSales', 'settlement'].includes(row.key) && s.roundingAdj && Math.abs(s.roundingAdj) === d)
      hints.push({ text: 'Equals your total rounding adjustments — the restaurant may settle on rounded (or original) cash totals' });
    if (row.key === 'settlement' && s.cardTips === d) hints.push({ text: 'Equals your card tips — check whether card tips were deducted from what you owe' });
    if (row.key === 'settlement' && s.tipoutsDeducted === d) hints.push({ text: 'Equals tip-outs deducted by the restaurant' });
    if (row.key === 'tipouts' && s.tipouts) hints.push({ text: 'Compare each tip-out in your cash ledger with the restaurant report' });
  }
  return hints.slice(0, 8);
}

/**
 * Tip-out calculation. rule: { mode: 'fixed' | 'pct_sales' | 'pct_tips', cents, bp }
 * bp = basis points (300 = 3.00%). Percentages use gross figures of the shift.
 */
export function tipoutAmount(rule, s) {
  if (!rule) return 0;
  if (rule.mode === 'pct_sales') return pctOf(Math.max(0, s.totalSales), rule.bp | 0);
  if (rule.mode === 'pct_tips') return pctOf(Math.max(0, s.totalTips), rule.bp | 0);
  return Math.max(0, rule.cents | 0);
}

// ---------------- Tip records & taxes ----------------

/** Daily records keyed YYYY-MM-DD (local time of shift start). */
export function dailyRecords(summaries) {
  const out = {};
  for (const s of summaries) {
    const d = new Date(s.shift.startedAt);
    const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const r = out[k] ||= { day: k, cashTips: 0, cardTips: 0, tipouts: 0, netTips: 0, hours: 0, sales: 0, shifts: 0 };
    r.cashTips += s.cashTips; r.cardTips += s.cardTips; r.tipouts += s.tipouts; r.netTips += s.netTips; r.hours += s.hours; r.sales += s.totalSales; r.shifts++;
  }
  return out;
}

/**
 * Monthly + annual tip summary for a year.
 * reported: [{ period: 'YYYY-MM', amount }] tips the user reported to the employer.
 * Retained tips (gross tips − tip-outs paid) are what most employees report; the app only compares, it does not decide.
 */
export function taxYear(summaries, reported = [], year) {
  const months = Array.from({ length: 12 }, (_, i) => ({ month: i + 1, period: `${year}-${String(i + 1).padStart(2, '0')}`, cashTips: 0, cardTips: 0, grossTips: 0, tipouts: 0, netTips: 0, hours: 0, received: 0, outstanding: 0, reported: 0, shifts: 0 }));
  for (const s of summaries) {
    const d = new Date(s.shift.startedAt); if (d.getFullYear() !== year) continue;
    const m = months[d.getMonth()];
    m.cashTips += s.cashTips; m.cardTips += s.cardTips; m.grossTips += s.totalTips; m.tipouts += s.tipouts; m.netTips += s.netTips;
    m.hours += s.hours; m.received += s.tipsReceived; m.outstanding += s.cardTipsOutstanding; m.shifts++;
  }
  for (const r of reported) {
    if (r.voided || typeof r.period !== 'string' || !r.period.startsWith(year + '-')) continue;
    const m = months[parseInt(r.period.slice(5, 7), 10) - 1]; if (m) m.reported += r.amount | 0;
  }
  for (const m of months) m.unreported = m.netTips - m.reported;
  const total = months.reduce((t, m) => { for (const k of ['cashTips', 'cardTips', 'grossTips', 'tipouts', 'netTips', 'hours', 'received', 'outstanding', 'reported', 'unreported', 'shifts']) t[k] += m[k]; return t; },
    { cashTips: 0, cardTips: 0, grossTips: 0, tipouts: 0, netTips: 0, hours: 0, received: 0, outstanding: 0, reported: 0, unreported: 0, shifts: 0 });
  return { year, months, total, differs: months.some(m => m.shifts && m.unreported !== 0) };
}

/** Compare optional W-2 figures with personal records. w2: { wages, ssTips (box 7), allocated (box 8) } */
export function w2Compare(total, w2 = {}) {
  const rows = [];
  if (Number.isSafeInteger(w2.ssTips)) {
    rows.push({ label: 'W-2 box 7 (social security tips) vs tips you reported', a: w2.ssTips, b: total.reported, diff: w2.ssTips - total.reported });
    rows.push({ label: 'W-2 box 7 vs your recorded retained tips', a: w2.ssTips, b: total.netTips, diff: w2.ssTips - total.netTips });
  }
  if (Number.isSafeInteger(w2.allocated) && w2.allocated) rows.push({ label: 'W-2 box 8 allocated tips', a: w2.allocated, b: 0, diff: w2.allocated });
  return rows;
}

/** Cash counter: { denominationCents: count } → total cents */
export const DENOMINATIONS = [10000, 5000, 2000, 1000, 500, 200, 100, 50, 25, 10, 5, 1];
export function countCash(counts = {}) {
  let t = 0;
  for (const d of DENOMINATIONS) t += d * Math.max(0, counts[d] | 0);
  return t;
}

/** Aggregate multiple shift summaries for reports. */
export function aggregate(summaries) {
  const keys = ['totalTips', 'cashTips', 'cardTips', 'netTips', 'tipouts', 'totalSales', 'cashSales', 'cardSales', 'billed', 'roundingAdj',
    'unconfirmedExcess', 'overChange', 'checks', 'tables', 'visits', 'payments', 'cardTipsPaid', 'cardTipsOutstanding', 'wage', 'workedMs', 'outstanding', 'tipsReceived'];
  const a = Object.fromEntries(keys.map(k => [k, 0]));
  a.lunch = { tips: 0, sales: 0, checks: 0 }; a.dinner = { tips: 0, sales: 0, checks: 0 };
  a.cashDiscrepancy = 0; a.shifts = summaries.length;
  for (const s of summaries) {
    for (const k of keys) a[k] += s[k] || 0;
    for (const seg of ['lunch', 'dinner']) for (const f of ['tips', 'sales', 'checks']) a[seg][f] += s.bySegment[seg][f];
    if (s.final && Number.isSafeInteger(s.final.cashDiscrepancy)) a.cashDiscrepancy += s.final.cashDiscrepancy;
  }
  a.hours = a.workedMs / 3_600_000;
  a.tipsPerHour = a.hours >= 0.25 ? Math.round(a.netTips / a.hours) : 0;
  a.earningsPerHour = a.hours >= 0.25 ? Math.round((a.netTips + a.wage) / a.hours) : 0;
  a.avgTipPct = a.totalSales > 0 ? Math.round(a.totalTips / a.totalSales * 1000) / 10 : 0;
  a.avgTicket = a.checks > 0 ? Math.round(a.billed / a.checks) : 0;
  return a;
}

export { roundDollar };
