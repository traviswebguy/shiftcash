// ShiftCash — application state and data operations. Every completed action is written to IndexedDB immediately.
import * as db from './db.js';
import { summarizeShift, finalSummary } from './ledger.js';
import { safeRounding } from './money.js';

export const S = {
  settings: null,
  shift: null,       // active shift or null
  checks: [], moves: [], payouts: [], incidents: [],
  summary: null,
};

const subs = new Set();
export const subscribe = fn => (subs.add(fn), () => subs.delete(fn));
const emit = () => subs.forEach(fn => { try { fn(); } catch (e) { console.error(e); } });

export function policyFromSettings(st = S.settings) {
  return { collect: st.policyCollect, cardTips: st.policyCardTips, adjustments: st.policyAdjustments || [] };
}
export function roundingFromSettings(st = S.settings) {
  return safeRounding({ method: st.roundingMethod, target: st.roundingTarget, half: st.roundingHalf }, !!st.allowRoundUp);
}

export async function init() {
  S.settings = await db.loadSettings();
  await reload();
}

export async function reload() {
  const shifts = await db.all('shifts');
  S.shift = shifts.filter(s => s.status === 'active').sort((a, b) => b.startedAt - a.startedAt)[0] || null;
  if (S.shift) Object.assign(S, await shiftData(S.shift.id));
  else Object.assign(S, { checks: [], moves: [], payouts: [], incidents: [] });
  recompute();
  emit();
}

export function recompute() {
  S.summary = S.shift ? summarizeShift({ shift: S.shift, checks: S.checks, moves: S.moves, payouts: S.payouts }) : null;
}

export async function shiftData(shiftId) {
  const [shift, checks, moves, payouts, incidents] = await Promise.all([
    db.get('shifts', shiftId), db.byIndex('checks', 'shiftId', shiftId), db.byIndex('moves', 'shiftId', shiftId),
    db.byIndex('payouts', 'shiftId', shiftId), db.byIndex('incidents', 'shiftId', shiftId),
  ]);
  checks.sort((a, b) => a.createdAt - b.createdAt);
  moves.sort((a, b) => a.createdAt - b.createdAt);
  return { shift, checks, moves, payouts, incidents };
}

export async function summaryFor(shiftId) {
  const d = await shiftData(shiftId);
  const s = summarizeShift(d);
  if (d.shift?.settlement) s.final = finalSummary(s, d.shift.settlement);
  return { ...d, summary: s };
}

export async function setSetting(key, value) {
  S.settings[key] = value;
  await db.saveSetting(key, value);
  emit();
}

// ---------- shifts ----------
export function segmentFor(t = Date.now()) {
  return new Date(t).getHours() < (S.settings.lunchCutoffHour || 16) ? 'lunch' : 'dinner';
}

export async function startShift({ startingCash = 0, hourlyWage = S.settings.hourlyWage, startedAt = Date.now(), segment } = {}) {
  if (S.shift) return S.shift;
  const shift = {
    id: db.uid('s'), status: 'active', startedAt, endedAt: null, startingCash, hourlyWage,
    segment: segment || segmentFor(startedAt), breaks: [], counts: [], policy: policyFromSettings(),
    settlement: null, notes: '', history: [], restaurantName: S.settings.restaurantName,
  };
  await db.putMany([['shifts', shift], ['audit', db.auditEntry('shift', shift.id, 'start', null, { startingCash, startedAt })]]);
  await reload();
  return shift;
}

/** Update a shift and keep the previous values in its history + audit log. */
export async function updateShift(id, patch, reason = '') {
  const before = await db.get('shifts', id);
  const prev = {}; for (const k of Object.keys(patch)) prev[k] = before[k];
  const after = { ...before, ...patch };
  if (reason) after.history = [...(before.history || []), { at: Date.now(), reason, before: prev }];
  await db.putMany([['shifts', after], ['audit', db.auditEntry('shift', id, 'update', prev, patch, reason)]]);
  await reload();
  return after;
}

export function onBreak(shift = S.shift) { return !!shift?.breaks?.some(b => !b.end); }
export async function toggleBreak(paid = false) {
  const sh = S.shift; if (!sh) return;
  const breaks = (sh.breaks || []).map(b => ({ ...b }));
  const open = breaks.find(b => !b.end);
  if (open) open.end = Date.now(); else breaks.push({ start: Date.now(), end: null, paid });
  await updateShift(sh.id, { breaks });
}

export async function setSegment(segment) { if (S.shift) await updateShift(S.shift.id, { segment }); }

export async function closeShift(settlement, endedAt = Date.now()) {
  const sh = S.shift; if (!sh) return;
  const ops = [];
  const credited = settlement.cardTipsCredited | 0;
  if (credited > 0) ops.push(['payouts', { id: db.uid('p'), shiftId: sh.id, amount: credited, via: settlement.cardTipsVia || 'settlement', inApron: false, at: endedAt, note: 'Recorded at settlement', fromSettlement: true }]);
  const cashPaid = settlement.cardTipsCash | 0;
  if (cashPaid > 0) ops.push(['payouts', { id: db.uid('p'), shiftId: sh.id, amount: cashPaid, via: 'cash', inApron: false, at: endedAt, note: 'Card tips paid in cash at checkout', fromSettlement: true }]);
  const closed = { ...sh, status: 'closed', endedAt: sh.endedAt || endedAt, settlement: { ...settlement, closedAt: Date.now() }, policy: settlement.policy || sh.policy };
  ops.push(['shifts', closed]);
  ops.push(['audit', db.auditEntry('shift', sh.id, 'close', null, closed.settlement)]);
  await db.putMany(ops);
  await reload();
  return closed;
}

export async function reopenShift(id, reason) {
  if (S.shift) throw new Error('End the current shift before reopening another.');
  const sh = await db.get('shifts', id);
  // Payouts recorded by the settlement are voided (kept) so re-settling does not double count them.
  const payouts = (await db.byIndex('payouts', 'shiftId', id)).filter(p => p.fromSettlement && !p.voided);
  if (payouts.length) await db.putMany(payouts.map(p => ['payouts', { ...p, voided: true, voidReason: 'Shift reopened: ' + reason }]));
  await updateShift(id, { status: 'active', endedAt: null, settlement: null, reopenedFrom: sh.settlement || null }, reason);
}

// ---------- checks ----------
export async function saveNewCheck(check) {
  const rec = { history: [], photoIds: [], voided: false, ...check, id: check.id || db.uid('c'), createdAt: check.createdAt || Date.now(), updatedAt: Date.now() };
  await db.putMany([['checks', rec], ['audit', db.auditEntry('check', rec.id, 'create', null, { table: rec.table, ticketCents: rec.ticketCents, payments: rec.payments.length })]]);
  await reload();
  return rec;
}

async function mutateCheck(id, fn, action, reason) {
  const before = await db.get('checks', id);
  if (!before) throw new Error('Check not found');
  const snap = JSON.parse(JSON.stringify({ ...before, history: undefined, photoIds: undefined }));
  const after = fn(JSON.parse(JSON.stringify(before)));
  after.updatedAt = Date.now();
  after.history = [...(before.history || []), { at: Date.now(), action, reason, before: snap }];
  await db.putMany([['checks', after], ['audit', db.auditEntry('check', id, action, snap, null, reason)]]);
  await reload();
  return after;
}
export const editCheck = (id, patch, reason) => mutateCheck(id, c => Object.assign(c, patch), 'edit', reason);
export const voidCheck = (id, reason) => mutateCheck(id, c => Object.assign(c, { voided: true, voidReason: reason }), 'void', reason);
export const unvoidCheck = (id, reason) => mutateCheck(id, c => Object.assign(c, { voided: false }), 'restore', reason);
export const addPayment = (id, payment, reason = 'Payment added') =>
  mutateCheck(id, c => { c.payments.push({ id: db.uid('p'), createdAt: Date.now(), ...payment }); return c; }, 'add-payment', reason);
export const voidPayment = (id, payId, reason) =>
  mutateCheck(id, c => { const p = c.payments.find(x => x.id === payId); if (p) { p.voided = true; p.voidReason = reason; } return c; }, 'void-payment', reason);
export const patchPayment = (id, payId, patch, reason) =>
  mutateCheck(id, c => { const p = c.payments.find(x => x.id === payId); if (p) Object.assign(p, patch); return c; }, 'edit-payment', reason);
export const addCheckPhoto = (id, photoId) =>
  mutateCheck(id, c => { c.photoIds = [...(c.photoIds || []), photoId]; return c; }, 'photo', 'Photo attached');

// ---------- cash ledger ----------
export async function addMove(move) {
  const sh = S.shift; if (!sh) throw new Error('No active shift');
  const rec = { id: db.uid('m'), shiftId: sh.id, createdAt: Date.now(), voided: false, ...move };
  await db.putMany([['moves', rec], ['audit', db.auditEntry('move', rec.id, 'create', null, rec)]]);
  await reload();
  return rec;
}
export async function voidMove(id, reason) {
  const m = await db.get('moves', id);
  await db.putMany([['moves', { ...m, voided: true, voidReason: reason }], ['audit', db.auditEntry('move', id, 'void', m, null, reason)]]);
  await reload();
}

// ---------- card-tip payouts ----------
export async function addPayout({ shiftId, amount, via, note = '', inApron = false, at = Date.now() }) {
  const rec = { id: db.uid('p'), shiftId, amount, via, note, inApron, at, voided: false };
  await db.putMany([['payouts', rec], ['audit', db.auditEntry('payout', rec.id, 'create', null, rec)]]);
  await reload();
  return rec;
}
export async function voidPayout(id, reason) {
  const p = await db.get('payouts', id);
  await db.putMany([['payouts', { ...p, voided: true, voidReason: reason }], ['audit', db.auditEntry('payout', id, 'void', p, null, reason)]]);
  await reload();
}

// ---------- mid-shift cash count ----------
export async function recordCount(counted, note = '') {
  const sh = S.shift; if (!sh) return;
  const entry = { at: Date.now(), counted, expected: S.summary.expectedCash, note };
  await updateShift(sh.id, { counts: [...(sh.counts || []), entry] });
  return entry;
}

// ---------- incidents ----------
export const INCIDENT_TYPES = {
  disputed: 'Disputed payment', change: 'Incorrect change', walkout: 'Walkout', missing_tip: 'Missing tip',
  checkout: 'Checkout discrepancy', comp: 'Comped / voided item', other: 'Other issue',
};
export async function saveIncident(inc) {
  const rec = { id: db.uid('i'), createdAt: Date.now(), resolved: false, photoIds: [], shiftId: S.shift?.id || null, ...inc };
  await db.putMany([['incidents', rec], ['audit', db.auditEntry('incident', rec.id, inc.id ? 'update' : 'create', null, rec)]]);
  await reload();
  return rec;
}

// ---------- photos ----------
export async function savePhoto(blob, ref, meta = {}) {
  const rec = { id: db.uid('ph'), size: blob.size, type: blob.type, createdAt: Date.now(), ref, ...meta };
  // SQLite stores JSON, so photos are kept as compressed JPEG data URLs there; IndexedDB keeps the Blob.
  if (db.backendName === 'sqlite') rec.dataUrl = await db.blobToDataUrl(blob); else rec.blob = blob;
  await db.put('photos', rec);
  return rec.id;
}
export async function getPhoto(id) {
  const p = await db.get('photos', id);
  if (p && !p.blob && p.dataUrl) p.blob = db.dataUrlToBlobSync(p.dataUrl);
  return p;
}

// ---------- user-confirmed deletion (a safety snapshot is always saved first) ----------
/** Every record that belongs to a shift: [[store, key], ...] */
async function shiftRecords(id) {
  const d = await shiftData(id);
  const pairs = [['shifts', id]];
  const photoIds = new Set(d.shift?.settlement?.photoIds || []);
  for (const c of d.checks) { pairs.push(['checks', c.id]); (c.photoIds || []).forEach(p => photoIds.add(p)); }
  for (const m of d.moves) pairs.push(['moves', m.id]);
  for (const p of d.payouts) pairs.push(['payouts', p.id]);
  for (const i of d.incidents) { pairs.push(['incidents', i.id]); (i.photoIds || []).forEach(p => photoIds.add(p)); }
  for (const p of photoIds) pairs.push(['photos', p]);
  return { pairs, counts: { checks: d.checks.length, shift: d.shift } };
}
export async function shiftDeletePreview(id) { return (await shiftRecords(id)).counts; }

export async function deleteShift(id) {
  const { pairs, counts } = await shiftRecords(id);
  const when = counts.shift ? new Date(counts.shift.startedAt).toLocaleString() : id;
  await db.snapshot(`Before deleting shift of ${when}`);
  await db.delMany(pairs);
  await db.put('audit', db.auditEntry('shift', id, 'delete', null, null, `Deleted by user (${counts.checks} checks)`));
  await reload();
}

/** Erase all records (settings are kept). */
export async function eraseAllRecords() {
  await db.snapshot('Before erasing all records');
  const pairs = [];
  for (const store of ['shifts', 'checks', 'moves', 'payouts', 'incidents', 'photos', 'audit', 'taxes']) for (const r of await db.all(store)) pairs.push([store, r.id]);
  await db.delMany(pairs);
  await db.put('audit', db.auditEntry('app', 'all', 'erase', null, null, 'All records erased by user'));
  await reload();
}
