// ShiftCash — data schema, migrations and backup validation (pure; shared by app + tests).

export const SCHEMA_VERSION = 3;
export const STORES = ['settings', 'shifts', 'checks', 'moves', 'payouts', 'incidents', 'photos', 'audit', 'taxes'];
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const MAX_STR = 2000;
const MAX_CENTS = 100_000_000_00;

/**
 * Record-level migrations. Each entry upgrades every record from version (n-1) to n.
 * They are used both for the on-device database and for older backup files.
 */
export const MIGRATIONS = {
  // v1 → v2: introduced visits (multiple checks per table visit), lunch/dinner segments,
  // and renamed cash payment field "tipConfirmed" → "keptTip".
  2(store, rec) {
    if (store === 'checks') {
      if (!rec.visitId) rec.visitId = rec.id;
      if (!rec.segment) rec.segment = new Date(rec.createdAt || Date.now()).getHours() < 16 ? 'lunch' : 'dinner';
      for (const p of rec.payments || []) {
        if (p.method === 'cash' && p.tipConfirmed !== undefined && p.keptTip === undefined) { p.keptTip = p.tipConfirmed; delete p.tipConfirmed; }
      }
      if (!Array.isArray(rec.history)) rec.history = [];
    }
    if (store === 'shifts' && !Array.isArray(rec.breaks)) rec.breaks = [];
    return rec;
  },
  // v2 → v3: card-tip states (pending / entered / confirmed / disputed) and the tip-records store.
  3(store, rec) {
    if (store === 'checks') {
      for (const p of rec.payments || []) {
        if (p.method === 'card' && !p.tipStatus) p.tipStatus = (p.tip === null || p.tip === undefined) ? 'pending' : 'entered';
      }
      if (rec.walkout === undefined) rec.walkout = false;
    }
    return rec;
  },
};

export function migrateRecord(store, rec, fromVersion, toVersion = SCHEMA_VERSION) {
  let r = rec;
  for (let v = fromVersion + 1; v <= toVersion; v++) if (MIGRATIONS[v]) r = MIGRATIONS[v](store, r) || r;
  return r;
}

export function migrateData(data, fromVersion) {
  const out = {};
  for (const store of STORES) out[store] = (data[store] || []).map(r => migrateRecord(store, r, fromVersion));
  return out;
}

// ---------- sanitizing / validation (protects against unsafe imports) ----------

function cleanValue(v, depth = 0) {
  if (depth > 24) throw new Error('Data nested too deeply');
  if (v === null) return null;
  switch (typeof v) {
    case 'string': return v.length > MAX_STR && !v.startsWith('data:image/') ? v.slice(0, MAX_STR) : v;
    case 'number': if (!Number.isFinite(v)) throw new Error('Invalid number'); return v;
    case 'boolean': return v;
    case 'object': {
      if (Array.isArray(v)) { if (v.length > 5000) throw new Error('List too long'); return v.map(x => cleanValue(x, depth + 1)); }
      const o = {};
      for (const k of Object.keys(v)) {
        if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
        if (k.length > 64) continue;
        o[k] = cleanValue(v[k], depth + 1);
      }
      return o;
    }
    default: return undefined;
  }
}

function checkCents(v, label) {
  if (v === undefined || v === null) return;
  if (!Number.isSafeInteger(v) || Math.abs(v) > MAX_CENTS) throw new Error(`${label} is not a valid amount in cents`);
}

export function validateRecord(store, rec) {
  if (!rec || typeof rec !== 'object' || Array.isArray(rec)) throw new Error(`Invalid ${store} record`);
  const key = store === 'settings' ? rec.key : rec.id;
  if (typeof key !== 'string' || !ID_RE.test(key)) throw new Error(`Invalid id in ${store}`);
  if (store === 'checks') {
    ['ticketCents', 'discountCents', 'compCents'].forEach(f => checkCents(rec[f], f));
    if (!Array.isArray(rec.payments)) throw new Error('Check without payments list');
    for (const p of rec.payments) {
      if (!['cash', 'card', 'refund'].includes(p.method)) throw new Error('Unknown payment method');
      ['due', 'received', 'changeGiven', 'keptTip', 'extraTip', 'tip', 'extraCashTip', 'amount'].forEach(f => checkCents(p[f], f));
    }
  }
  if (store === 'moves' || store === 'payouts') checkCents(rec.amount, 'amount');
  if (store === 'taxes') { checkCents(rec.amount, 'amount'); ['wages', 'ssTips', 'allocated', 'cap'].forEach(f => checkCents(rec[f], f)); }
  if (store === 'shifts') { checkCents(rec.startingCash, 'startingCash'); checkCents(rec.hourlyWage, 'hourlyWage'); }
  if (store === 'photos' && rec.dataUrl !== undefined && !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(rec.dataUrl)) throw new Error('Invalid photo data');
  return true;
}

/** Parse + validate + migrate a backup file. Throws with a readable message. */
export function parseBackup(text) {
  if (typeof text !== 'string' || text.length > 200 * 1024 * 1024) throw new Error('File is empty or too large');
  let raw;
  try { raw = JSON.parse(text); } catch { throw new Error('Not a valid JSON file'); }
  if (!raw || raw.app !== 'ShiftCash' || typeof raw.data !== 'object') throw new Error('This is not a ShiftCash backup');
  const ver = raw.schemaVersion | 0;
  if (ver < 1) throw new Error('Unknown backup version');
  if (ver > SCHEMA_VERSION) throw new Error('This backup was made by a newer version of ShiftCash. Update the app first.');
  const clean = cleanValue(raw.data);
  const data = migrateData(clean, ver);
  let count = 0;
  for (const store of STORES) for (const r of data[store]) { validateRecord(store, r); count++; }
  return { exportedAt: raw.exportedAt, fromVersion: ver, data, count };
}

export function buildBackup(data) {
  return JSON.stringify({ app: 'ShiftCash', schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data });
}

/** CSV helper with formula-injection protection. */
export function toCSV(rows) {
  const esc = v => {
    if (v === null || v === undefined) return '';
    let s = String(v);
    if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s;
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return rows.map(r => r.map(esc).join(',')).join('\r\n');
}

/**
 * Data integrity check over a full data set (same shape as a backup's data).
 * Returns a list of readable problems; an empty list means no problems were found.
 */
export function checkIntegrity(data) {
  const problems = [];
  const ids = new Set();
  for (const store of STORES) {
    for (const r of data[store] || []) {
      const key = store + ':' + (store === 'settings' ? r.key : r.id);
      if (ids.has(key)) problems.push(`Duplicate record ${key}`);
      ids.add(key);
      try { validateRecord(store, r); } catch (e) { problems.push(`${store} ${r.id || r.key}: ${e.message}`); }
    }
  }
  const shiftIds = new Set((data.shifts || []).map(s => s.id));
  const active = (data.shifts || []).filter(s => s.status === 'active');
  if (active.length > 1) problems.push(`${active.length} shifts are marked active (only one should be)`);
  for (const c of data.checks || []) {
    if (!shiftIds.has(c.shiftId)) problems.push(`Check ${c.id} (table ${c.table}) belongs to a missing shift`);
    const payIds = new Set();
    for (const p of c.payments || []) { if (p.id && payIds.has(p.id)) problems.push(`Check ${c.id} has a duplicated payment ${p.id}`); payIds.add(p.id); }
  }
  for (const m of [...(data.moves || []), ...(data.payouts || [])]) if (m.shiftId && !shiftIds.has(m.shiftId)) problems.push(`Ledger entry ${m.id} belongs to a missing shift`);
  for (const s of data.shifts || []) if (s.endedAt && s.endedAt < s.startedAt) problems.push(`Shift ${s.id} ends before it starts`);
  return problems;
}
