// ShiftCash — backup sealing: SHA-256 checksum and optional AES-256-GCM encryption (password → PBKDF2-SHA256).
import { buildBackup, parseBackup } from './schema.js';

const enc = new TextEncoder(), dec = new TextDecoder();
const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const ITER = 210000;

export async function sha256(text) {
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(text)));
  return Array.from(h, b => b.toString(16).padStart(2, '0')).join('');
}

async function keyFrom(password, salt, iter) {
  const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

/** Build a backup file string. With a password the payload is encrypted. */
export async function sealBackup(data, password = '') {
  const plain = JSON.parse(buildBackup(data));
  plain.checksum = await sha256(JSON.stringify(plain.data));
  const text = JSON.stringify(plain);
  if (!password) return text;
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keyFrom(password, salt, ITER);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(text)));
  return JSON.stringify({ app: 'ShiftCash', encrypted: true, alg: 'AES-256-GCM', kdf: 'PBKDF2-SHA256', iter: ITER, salt: b64(salt), iv: b64(iv), data: b64(ct) });
}

export function isEncrypted(text) {
  try { const o = JSON.parse(text); return !!(o && o.app === 'ShiftCash' && o.encrypted); } catch { return false; }
}

/** Decrypt (if needed), verify checksum, validate + migrate. Throws readable errors. Nothing is written. */
export async function openBackup(text, password = '') {
  let raw;
  try { raw = JSON.parse(text); } catch { throw new Error('Not a valid JSON file'); }
  if (raw && raw.encrypted) {
    if (!password) throw new Error('This backup is encrypted. Enter its password.');
    let plain;
    try {
      const key = await keyFrom(password, unb64(raw.salt), raw.iter | 0 || ITER);
      plain = dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(raw.iv) }, key, unb64(raw.data)));
    } catch { throw new Error('Wrong password, or the file is damaged.'); }
    text = plain; raw = JSON.parse(plain);
  }
  if (raw && raw.checksum) {
    const actual = await sha256(JSON.stringify(raw.data));
    if (actual !== raw.checksum) throw new Error('Backup integrity check failed — the file was changed or damaged.');
  }
  const res = parseBackup(text);
  res.checksumVerified = !!raw.checksum;
  return res;
}
