// ShiftCash accounting test cases — run in Node (tests/run.mjs) and in-app (Settings → Diagnostics).
import { toCents, roundDollar, cashPayment, cardPayment, roundedPayable, keypadAppend, keypadBackspace, safeRounding, roundingChoices } from './money.js';
import { summarizeShift, checkState, finalSummary, compareReported, countCash, workedMs, aggregate, explainDiff, tipoutAmount, taxYear, w2Compare } from './ledger.js';
import { parseBackup, buildBackup, migrateRecord, SCHEMA_VERSION, toCSV } from './schema.js';

const H = 3_600_000;
const T0 = Date.UTC(2026, 10, 14, 16, 0); // fixed start time
const shift = (o = {}) => ({ id: 's1', startedAt: T0, endedAt: T0 + 8 * H, startingCash: 0, breaks: [], ...o });
let n = 0;
const chk = (table, ticket, payments, o = {}) => ({ id: 'c' + (++n), visitId: o.visitId || 'v' + n, table, ticketCents: ticket, payments: payments.map((p, i) => ({ id: 'p' + n + '_' + i, ...p })), segment: 'dinner', ...o });
const R = { method: 'nearest', target: 'ticket', half: 'up' };

export const cases = [
  // ---------------- parsing ----------------
  ['Parse money strings into cents', a => {
    a.eq(toCents('48'), 4800); a.eq(toCents('48.5'), 4850); a.eq(toCents('$1,234.56'), 123456);
    a.eq(toCents('0.07'), 7); a.ok(Number.isNaN(toCents('4.555'))); a.ok(Number.isNaN(toCents('abc')));
    a.eq(toCents(0.1 + 0.2), 30);
  }],
  ['Keypad entry shifts digits in from the right', a => {
    let c = 0; for (const d of [4, 8, 0, 0]) c = keypadAppend(c, d);
    a.eq(c, 4800); a.eq(keypadBackspace(c), 480);
  }],

  // ---------------- rounding ----------------
  ['Exact cash payment (no rounding needed)', a => {
    const p = cashPayment({ due: 4800, received: 4800, rounding: R });
    a.eq(p.roundedDue, 4800); a.eq(p.expectedChange, 0); a.eq(p.roundingAdj, 0); a.eq(p.cashTip, 0); a.eq(p.cashIn, 4800);
  }],
  ['Ticket rounded up to whole dollar', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R });
    a.eq(p.roundedDue, 4800); a.eq(p.roundingAdj, 40); a.eq(p.expectedChange, 200);
    a.eq(p.cashTip, 0, 'rounding is never a tip');
  }],
  ['Ticket rounded down to whole dollar', a => {
    const p = cashPayment({ due: 4740, received: 5000, rounding: R });
    a.eq(p.roundedDue, 4700); a.eq(p.roundingAdj, -40); a.eq(p.expectedChange, 300);
  }],
  ['Half-dollar: rounds up by default, down when configured', a => {
    a.eq(roundDollar(4750, 'nearest', 'up'), 4800);
    a.eq(roundDollar(4750, 'nearest', 'down'), 4700);
    a.eq(roundDollar(4751, 'nearest', 'down'), 4800);
    a.eq(roundDollar(4749, 'nearest', 'up'), 4700);
  }],
  ['Always up / always down / exact / manual', a => {
    a.eq(roundedPayable(4701, 5000, { method: 'up' }), 4800);
    a.eq(roundedPayable(4799, 5000, { method: 'down' }), 4700);
    a.eq(roundedPayable(4737, 5000, { method: 'exact' }), 4737);
    a.eq(roundedPayable(4737, 5000, { method: 'manual', manualDue: 4500 }), 4500);
  }],
  ['Rounding the change amount instead of the ticket', a => {
    // ticket 47.40, $50 given: exact change 2.60
    a.eq(roundedPayable(4740, 5000, { method: 'up', target: 'change' }), 4700, 'change up → $3 back');
    a.eq(roundedPayable(4740, 5000, { method: 'up', target: 'ticket' }), 4800, 'ticket up → $2 back');
    a.eq(roundedPayable(4740, 5000, { method: 'down', target: 'change' }), 4800, 'change down → $2 back');
  }],
  ['Original ticket total is never modified', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R });
    a.eq(p.due, 4760);
  }],

  // ---------------- change / tips ----------------
  ['Customer says keep the change → confirmed tip', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R, changeGiven: 0, keptTip: 200 });
    a.eq(p.cashTip, 200); a.eq(p.unconfirmed, 0); a.eq(p.cashIn, 5000);
  }],
  ['Unreturned change is NOT a tip unless confirmed', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R, changeGiven: 0 });
    a.eq(p.cashTip, 0); a.eq(p.unconfirmed, 200);
    a.ok(p.warnings.some(w => w.code === 'unconfirmed'));
  }],
  ['Excessive change returned is flagged', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R, changeGiven: 500 });
    a.eq(p.shortage, 300); a.ok(p.warnings.some(w => w.code === 'overchange')); a.eq(p.cashIn, 4500);
  }],
  ['Cash tip left after change is not double counted', a => {
    const p = cashPayment({ due: 4760, received: 10000, rounding: R, changeGiven: 5200, extraTip: 800 });
    a.eq(p.expectedChange, 5200); a.eq(p.cashTip, 800);
    a.eq(p.cashIn, 4800 + 800, 'apron gets rounded ticket + tip only');
  }],
  ['Kept tip cannot exceed actual excess', a => {
    const p = cashPayment({ due: 4760, received: 5000, rounding: R, changeGiven: 100, keptTip: 999 });
    a.eq(p.keptTip, 100); a.eq(p.unconfirmed, 0);
  }],
  ['Underpayment detected', a => {
    const p = cashPayment({ due: 4760, received: 4000, rounding: R });
    a.eq(p.underpaid, 800); a.ok(p.warnings.some(w => w.code === 'underpaid'));
  }],

  // ---------------- card ----------------
  ['Card payment with additional cash tip', a => {
    const p = cardPayment({ due: 3277, tip: 600, extraCashTip: 200 });
    a.eq(p.charge, 3877, 'card is never rounded'); a.eq(p.cashTip, 200); a.eq(p.cashIn, 200);
  }],

  // ---------------- checks / shift ----------------
  ['Split check: payments sum, ticket not double counted', a => {
    const c = chk('12', 9000, [
      { method: 'card', due: 4500, tip: 900 },
      { method: 'cash', due: 4500, received: 5000, rounding: R, changeGiven: 500 },
    ]);
    const st = checkState(c);
    a.eq(st.applied, 9000); a.eq(st.balance, 0); a.eq(st.kind, 'split');
    const s = summarizeShift({ shift: shift(), checks: [c] });
    a.eq(s.billed, 9000); a.eq(s.totalSales, 9000); a.eq(s.checks, 1); a.eq(s.payments, 2);
  }],
  ['Multiple checks at one table, table reused later', a => {
    const checks = [
      chk('12', 2000, [{ method: 'card', due: 2000, tip: 400 }], { visitId: 'A' }),
      chk('12', 3000, [{ method: 'card', due: 3000, tip: 500 }], { visitId: 'A' }),
      chk('12', 1500, [{ method: 'card', due: 1500, tip: 300 }], { visitId: 'B' }),
    ];
    const s = summarizeShift({ shift: shift(), checks });
    a.eq(s.tables, 1); a.eq(s.visits, 2); a.eq(s.checks, 3); a.eq(s.payments, 3); a.eq(s.cardTips, 1200);
  }],
  ['Partial payment leaves outstanding balance', a => {
    const c = chk('5', 6000, [{ method: 'card', due: 2500, tip: 0 }]);
    const st = checkState(c);
    a.eq(st.balance, 3500); a.eq(st.status, 'partial');
    a.eq(summarizeShift({ shift: shift(), checks: [c] }).outstanding, 3500);
  }],
  ['Discounts and comps reduce billable total only', a => {
    const c = chk('7', 5000, [{ method: 'card', due: 3500, tip: 700 }], { discountCents: 1000, compCents: 500 });
    const st = checkState(c);
    a.eq(st.netDue, 3500); a.eq(st.balance, 0);
  }],
  ['Refund and voided check / payment', a => {
    const checks = [
      chk('1', 4000, [{ method: 'cash', due: 4000, received: 4000, rounding: R }, { method: 'refund', via: 'cash', amount: 1000 }]),
      chk('2', 9999, [{ method: 'card', due: 9999, tip: 2000 }], { voided: true }),
      chk('3', 2000, [{ method: 'card', due: 2000, tip: 300, voided: true }, { method: 'card', due: 2000, tip: 400 }]),
    ];
    const s = summarizeShift({ shift: shift(), checks });
    a.eq(s.cashSales, 3000); a.eq(s.cardSales, 2000); a.eq(s.cardTips, 400); a.eq(s.voidedChecks, 1);
    a.eq(s.expectedCash, 3000, 'cash refund leaves apron');
  }],

  // ---------------- cash ledger ----------------
  ['Tip-outs, cash removed and added mid-shift', a => {
    const checks = [chk('1', 4760, [{ method: 'cash', due: 4760, received: 5000, rounding: R, changeGiven: 0, keptTip: 200 }])];
    const moves = [
      { id: 'm1', type: 'tipout', amount: 300, via: 'cash' },
      { id: 'm2', type: 'withdraw', amount: 1000 },
      { id: 'm3', type: 'add', amount: 2000 },
      { id: 'm4', type: 'tipout', amount: 500, via: 'deducted' },
    ];
    const s = summarizeShift({ shift: shift({ startingCash: 5000 }), checks, moves, policy: { collect: 'original', cardTips: 'deduct' } });
    a.eq(s.expectedCash, 5000 + 5000 - 300 - 1000 + 2000);
    a.eq(s.tipouts, 800); a.eq(s.netTips, 200 - 800);
    a.eq(s.owed, 4760 + 500, 'restaurant collects original ticket + deducted tip-out');
  }],
  ['Settlement: rounded vs original basis and card-tip deduction', a => {
    const checks = [
      chk('1', 4760, [{ method: 'cash', due: 4760, received: 5000, rounding: R }]),
      chk('2', 2000, [{ method: 'card', due: 2000, tip: 400 }]),
    ];
    const base = { shift: shift(), checks };
    a.eq(summarizeShift({ ...base, policy: { collect: 'original', cardTips: 'deduct' } }).owed, 4760 - 400);
    a.eq(summarizeShift({ ...base, policy: { collect: 'rounded', cardTips: 'deduct' } }).owed, 4800 - 400);
    a.eq(summarizeShift({ ...base, policy: { collect: 'rounded', cardTips: 'payroll' } }).owed, 4800);
    a.eq(summarizeShift({ ...base, policy: { collect: 'original', cardTips: 'separate', adjustments: [{ label: 'Fee', cents: 150 }] } }).owed, 4910);
  }],
  ['Missing card tips & outstanding card tips', a => {
    const checks = [chk('1', 2000, [{ method: 'card', due: 2000, tip: 500 }]), chk('2', 3000, [{ method: 'card', due: 3000, tip: 700 }])];
    const s = summarizeShift({ shift: shift(), checks, payouts: [{ id: 'x', amount: 500, via: 'payroll' }], policy: { cardTips: 'payroll' } });
    a.eq(s.cardTipsOutstanding, 700); a.eq(s.tipsReceived, 500);
    const rows = compareReported(s, { cardTips: 1000 });
    a.eq(rows[0].diff, -200);
  }],
  ['Restaurant settlement discrepancies are reported, not forced', a => {
    const checks = [chk('1', 4760, [{ method: 'cash', due: 4760, received: 5000, rounding: R }])];
    const s = summarizeShift({ shift: shift({ startingCash: 2000 }), checks, policy: { collect: 'original', cardTips: 'deduct' } });
    a.eq(s.expectedCash, 2000 + 4800); a.eq(s.owed, 4760);
    const f = finalSummary(s, { reported: { cashSales: 4800, settlement: 4800 }, actualPaid: 4800, countedCash: 6700 });
    a.eq(f.cashDiscrepancy, -100); a.eq(f.paymentDiff, 40); a.eq(f.takeHome, 1900);
    a.ok(f.issues.length >= 3); a.eq(f.rows.find(r => r.key === 'cashSales').diff, 40);
  }],
  ['Cash counter totals bills and coins', a => {
    a.eq(countCash({ 10000: 1, 2000: 3, 100: 4, 25: 3, 1: 2 }), 10000 + 6000 + 400 + 75 + 2);
  }],

  // ---------------- time ----------------
  ['Hours after unpaid breaks; paid breaks count', a => {
    const s = shift({ breaks: [{ start: T0 + 2 * H, end: T0 + 3 * H }, { start: T0 + 5 * H, end: T0 + 5.25 * H, paid: true }] });
    a.eq(workedMs(s), 7 * H);
  }],
  ['Shift crossing midnight', a => {
    const start = new Date(2026, 10, 14, 20, 0).getTime();
    const s = { startedAt: start, endedAt: start + 6.5 * H, breaks: [] };
    a.eq(workedMs(s), 6.5 * H);
  }],
  ['Double shift: lunch + dinner segments aggregate', a => {
    const checks = [
      chk('1', 2000, [{ method: 'card', due: 2000, tip: 300 }], { segment: 'lunch' }),
      chk('2', 4000, [{ method: 'card', due: 4000, tip: 800 }], { segment: 'dinner' }),
    ];
    const s = summarizeShift({ shift: shift({ endedAt: T0 + 11 * H, breaks: [{ start: T0 + 4 * H, end: T0 + 5 * H }] }), checks });
    a.eq(s.bySegment.lunch.tips, 300); a.eq(s.bySegment.dinner.tips, 800); a.eq(s.hours, 10);
    const ag = aggregate([s, s]); a.eq(ag.totalTips, 2200); a.eq(ag.lunch.tips, 600);
  }],

  // ---------------- backup / migration ----------------
  ['Backup round trip preserves every record', a => {
    const data = { settings: [{ key: 'restaurantName', value: 'Test' }], shifts: [shift()], checks: [chk('1', 100, [{ method: 'card', due: 100, tip: 0 }])], moves: [], payouts: [], incidents: [], photos: [], audit: [] };
    const res = parseBackup(buildBackup(data));
    a.eq(res.count, 3); a.eq(res.data.checks[0].ticketCents, 100); a.eq(res.data.settings[0].value, 'Test');
  }],
  ['Unsafe or malformed imports are rejected', a => {
    a.throws(() => parseBackup('{bad json'));
    a.throws(() => parseBackup(JSON.stringify({ app: 'Other', data: {} })));
    a.throws(() => parseBackup(JSON.stringify({ app: 'ShiftCash', schemaVersion: 2, data: { checks: [{ id: '<script>', payments: [] }] } })));
    a.throws(() => parseBackup(JSON.stringify({ app: 'ShiftCash', schemaVersion: 2, data: { checks: [{ id: 'ok', ticketCents: 1.5, payments: [] }] } })));
    a.throws(() => parseBackup(JSON.stringify({ app: 'ShiftCash', schemaVersion: 99, data: {} })));
    const r = parseBackup(JSON.stringify({ app: 'ShiftCash', schemaVersion: 2, data: { settings: [{ key: 'x', value: { __proto__: { polluted: 1 } } }] } }));
    a.eq(({}).polluted, undefined);
    a.ok(r.count === 1);
  }],
  ['Migration v1 → v2 upgrades old records', a => {
    const old = { id: 'c1', table: '4', ticketCents: 1000, createdAt: new Date(2026, 0, 1, 12).getTime(), payments: [{ method: 'cash', due: 1000, received: 1000, tipConfirmed: 0 }] };
    const m = migrateRecord('checks', JSON.parse(JSON.stringify(old)), 1);
    a.eq(m.visitId, 'c1'); a.eq(m.segment, 'lunch'); a.eq(m.payments[0].keptTip, 0); a.eq(m.payments[0].tipConfirmed, undefined);
    const res = parseBackup(JSON.stringify({ app: 'ShiftCash', schemaVersion: 1, data: { checks: [old] } }));
    a.eq(res.fromVersion, 1); a.eq(res.data.checks[0].visitId, 'c1'); a.eq(SCHEMA_VERSION, 3); a.eq(res.data.checks[0].walkout, false);
  }],
  ['CSV export neutralises spreadsheet formulas', a => {
    a.eq(toCSV([['=HYPERLINK("x")', '-12.50', 'a,b']]), `"'=HYPERLINK(""x"")",-12.50,"a,b"`);
  }],

  // ---------------- master-spec scenarios ----------------
  ['Spec example: $42.65 ticket, $60 given → $43 payable, $17 change, +$0.35 rounding, $0 tip', a => {
    const p = cashPayment({ due: 4265, received: 6000, rounding: R });
    a.eq(p.roundedDue, 4300); a.eq(p.expectedChange, 1700); a.eq(p.roundingAdj, 35); a.eq(p.cashTip, 0);
  }],
  ['Card payment without a tip', a => { const p = cardPayment({ due: 2500, tip: 0 }); a.eq(p.charge, 2500); a.eq(p.tip, 0); a.eq(p.tipStatus, 'entered'); }],
  ['Card tip entered later (pending → entered) without duplicating sales', a => {
    const c = chk('9', 5000, [{ method: 'card', due: 5000, tip: null }]);
    let s = summarizeShift({ shift: shift(), checks: [c] });
    a.eq(s.cardTips, 0); a.eq(s.cardTipsPending, 1); a.eq(s.cardSales, 5000);
    c.payments[0].tip = 900; c.payments[0].tipStatus = 'entered';
    s = summarizeShift({ shift: shift(), checks: [c] });
    a.eq(s.cardTips, 900); a.eq(s.cardTipsPending, 0); a.eq(s.cardSales, 5000, 'sales counted once');
  }],
  ['Customer walkout: no sales, no cash, flagged — not a shortage of your cash', a => {
    const c = chk('8', 6400, [], { walkout: true });
    const s = summarizeShift({ shift: shift({ startingCash: 2000 }), checks: [c] });
    a.eq(s.totalSales, 0); a.eq(s.walkouts, 1); a.eq(s.walkoutAmount, 6400); a.eq(s.outstanding, 0); a.eq(s.expectedCash, 2000);
    a.ok(finalSummary(s, {}).issues.some(i => i.key === 'walkout'));
  }],
  ['Card tips paid in cash at checkout (policy: paid separately)', a => {
    const checks = [chk('1', 4000, [{ method: 'cash', due: 4000, received: 4000, rounding: R }]), chk('2', 3000, [{ method: 'card', due: 3000, tip: 600 }])];
    const s = summarizeShift({ shift: shift(), checks, policy: { collect: 'original', cardTips: 'separate' } });
    a.eq(s.owed, 4000);
    const f = finalSummary(s, { paidToRestaurant: 4000, cardTipsCash: 600, countedCash: 4000 });
    a.eq(f.takeHome, 600); a.eq(f.cardTipsOutstanding, 0); a.eq(f.received, 600); a.eq(f.status, 'balanced');
  }],
  ['Card tips offset against cash owed (policy: deducted)', a => {
    const checks = [chk('1', 4000, [{ method: 'cash', due: 4000, received: 4000, rounding: R }]), chk('2', 3000, [{ method: 'card', due: 3000, tip: 600 }])];
    const s = summarizeShift({ shift: shift(), checks, policy: { collect: 'original', cardTips: 'deduct' } });
    a.eq(s.owed, 3400);
    const f = finalSummary(s, { paidToRestaurant: 3400, cardTipsCredited: 600, countedCash: 4000 });
    a.eq(f.takeHome, 600); a.eq(f.cardTipsOutstanding, 0); a.eq(f.status, 'balanced');
  }],
  ['Card tips through payroll stay outstanding and are never physical cash', a => {
    const s = summarizeShift({ shift: shift(), checks: [chk('2', 3000, [{ method: 'card', due: 3000, tip: 600 }])], policy: { cardTips: 'payroll' } });
    a.eq(s.expectedCash, 0); a.eq(s.cardTipsOutstanding, 600); a.eq(s.tipsReceived, 0); a.eq(s.owed, 0);
  }],
  ['Settlement after a cash shortage (too much change) shows the shortage', a => {
    const checks = [chk('1', 4760, [{ method: 'cash', due: 4760, received: 5000, rounding: R, changeGiven: 700 }])];
    const s = summarizeShift({ shift: shift({ startingCash: 2000 }), checks, policy: { collect: 'original', cardTips: 'deduct' } });
    a.eq(s.overChange, 500); a.eq(s.expectedCash, 2000 + 4300); a.eq(s.owed, 4760);
    const f = finalSummary(s, { paidToRestaurant: 4760, countedCash: 6300 });
    a.eq(f.takeHome, 1540, 'starting $20 minus $4.60 net loss'); a.ok(f.issues.some(i => i.key === 'overchange'));
  }],
  ['Spec example: card tips $62 vs restaurant $52 → $10 discrepancy pointing to a $10 tip', a => {
    const checks = [chk('4', 4000, [{ method: 'card', due: 4000, tip: 1000 }]), chk('5', 20000, [{ method: 'card', due: 20000, tip: 5200 }])];
    const s = summarizeShift({ shift: shift(), checks });
    const row = compareReported(s, { cardTips: 5200 })[0];
    a.eq(row.diff, -1000);
    const hints = explainDiff(row, checks, s);
    a.ok(hints.some(h => /Table 4/.test(h.text)), 'should point to table 4');
  }],
  ['Spec example: 10 AM–9 PM double with 2-hour unpaid break = 9 hours', a => {
    const start = new Date(2026, 10, 14, 10, 0).getTime();
    const s = { startedAt: start, endedAt: start + 11 * H, breaks: [{ start: start + 4 * H, end: start + 6 * H }] };
    a.eq(workedMs(s), 9 * H);
  }],
  ['Tip-outs: fixed, % of sales, % of tips (integer cents)', a => {
    const s = { totalSales: 123456, totalTips: 23450 };
    a.eq(tipoutAmount({ mode: 'fixed', cents: 1000 }, s), 1000);
    a.eq(tipoutAmount({ mode: 'pct_sales', bp: 150 }, s), 1852, '1.5% of $1,234.56 = $18.5184 → $18.52');
    a.eq(tipoutAmount({ mode: 'pct_tips', bp: 1000 }, s), 2345);
  }],
  ['Monthly tax record summary compares retained vs reported tips', a => {
    const mk = (m, tip) => summarizeShift({ shift: { id: 'x' + m, startedAt: new Date(2026, m, 5, 12).getTime(), endedAt: new Date(2026, m, 5, 18).getTime(), breaks: [] }, checks: [chk('1', 5000, [{ method: 'card', due: 5000, tip }])] });
    const sums = [mk(0, 1000), mk(0, 500), mk(1, 700)].map(x => x);
    sums.forEach((x, i) => { x.shift = { startedAt: new Date(2026, i < 2 ? 0 : 1, 5, 12).getTime() }; });
    const y = taxYear(sums, [{ period: '2026-01', amount: 1500 }, { period: '2026-02', amount: 500 }], 2026);
    a.eq(y.months[0].netTips, 1500); a.eq(y.months[0].unreported, 0); a.eq(y.months[1].unreported, 200); a.eq(y.total.netTips, 2200); a.eq(y.differs, true);
    a.eq(w2Compare(y.total, { ssTips: 2000 })[0].diff, 0);
  }],

  ['Default cash discount: $42.65 rounds DOWN to $42, $18 change, −$0.65 discount, restaurant collects $42', a => {
    const D = safeRounding({ method: 'down', target: 'ticket' }, false);
    const p = cashPayment({ due: 4265, received: 6000, rounding: D });
    a.eq(p.roundedDue, 4200); a.eq(p.expectedChange, 1800); a.eq(p.roundingAdj, -65); a.eq(p.cashTip, 0);
    const s = summarizeShift({ shift: shift({ startingCash: 5000 }), checks: [chk('12', 4265, [{ method: 'cash', due: 4265, received: 6000, rounding: D }])], policy: { collect: 'rounded', cardTips: 'deduct' } });
    a.eq(s.owed, 4200, 'restaurant absorbs the discount'); a.eq(s.expectedCash, 5000 + 4200); a.eq(s.expectedTakeHome, 5000, 'server neither gains nor loses');
  }],
  ['Round-up disabled: no option can make the customer pay more than the ticket', a => {
    a.eq(Object.keys(roundingChoices(false)).includes('up'), false);
    a.eq(Object.keys(roundingChoices(false)).includes('nearest'), false);
    a.eq(safeRounding({ method: 'up', target: 'ticket' }, false).method, 'down');
    a.eq(safeRounding({ method: 'down', target: 'change' }, false).target, 'ticket', 'rounding change down = paying more');
    a.eq(safeRounding({ method: 'manual', manualDue: 5000 }, false, 4265).manualDue, 4265);
    for (const due of [4201, 4250, 4299, 4265, 1]) { const p = cashPayment({ due, received: 10000, rounding: safeRounding({ method: 'down' }, false) }); a.ok(p.roundedDue <= due, 'never above ticket'); }
  }],

  ['Cash tip entered later at the POS: payment not counted twice', a => {
    const c = chk('12', 4265, [{ method: 'cash', due: 4265, received: 6000, rounding: { method: 'down' }, tipPending: true }]);
    let s = summarizeShift({ shift: shift({ startingCash: 5000 }), checks: [c] });
    a.eq(s.cashTipsPending, 1); a.eq(s.cashTips, 0); a.eq(s.expectedCash, 9200);
    c.payments[0].extraTip = 500; c.payments[0].tipPending = false;
    s = summarizeShift({ shift: shift({ startingCash: 5000 }), checks: [c] });
    a.eq(s.cashTipsPending, 0); a.eq(s.cashTips, 500); a.eq(s.cashSales, 4265); a.eq(s.expectedCash, 9700, 'only the tip is added');
  }],

  // ---------------- full-shift reconciliation ----------------
  ['Full shift reconciles with no double counting', a => {
    const checks = [
      chk('12', 4800, [{ method: 'cash', due: 4800, received: 5000, rounding: R, changeGiven: 200, extraTip: 800 }]),
      chk('14', 3200, [{ method: 'card', due: 3200, tip: 600 }]),
      chk('16', 5530, [{ method: 'cash', due: 5530, received: 6000, rounding: R, changeGiven: 0, keptTip: 500 }]),
      chk('21', 4100, [{ method: 'card', due: 2000, tip: 300 }, { method: 'cash', due: 2100, received: 2500, rounding: R, changeGiven: 400 }]),
    ];
    const s = summarizeShift({ shift: shift({ startingCash: 3000 }), checks, moves: [{ id: 'm', type: 'tipout', amount: 500, via: 'cash' }], policy: { collect: 'original', cardTips: 'deduct' } });
    a.eq(s.cashSales, 4800 + 5530 + 2100); a.eq(s.cardSales, 5200); a.eq(s.totalSales, 17630); a.eq(s.billed, 17630);
    a.eq(s.cashTips, 800 + 500); a.eq(s.cardTips, 900); a.eq(s.totalTips, 2200); a.eq(s.unconfirmedExcess, 0);
    a.eq(s.roundingAdj, -30, '$55.30 rounded to $55.00');
    // cash in = 4800+800 + 6000 + 2100 = 13700; apron = 3000 + 13700 - 500
    a.eq(s.expectedCash, 16200);
    a.eq(s.owed, 12430 - 900);
    // money identity: apron − owed = start + cash tips + card tips(deducted) + rounding + unconfirmed − tipouts
    a.eq(s.expectedCash - s.owed, s.startingCash + s.cashTips + s.cardTips + s.roundingAdj + s.unconfirmedExcess - s.tipoutsCash - s.overChange);
  }],
];

/** Tiny assertion helper + runner usable in both Node and the browser. */
export function runCases(list = cases) {
  const results = [];
  for (const [name, fn] of list) {
    const a = {
      eq(x, y, m = '') { if (!Object.is(x, y)) throw new Error(`${m} expected ${JSON.stringify(y)}, got ${JSON.stringify(x)}`); },
      ok(x, m = 'expected truthy') { if (!x) throw new Error(m); },
      throws(f) { let t = false; try { f(); } catch { t = true; } if (!t) throw new Error('expected an error'); },
    };
    try { fn(a); results.push({ name, ok: true }); } catch (e) { results.push({ name, ok: false, error: e.message }); }
  }
  return results;
}
