// ShiftCash — Settings, privacy, backup/restore, exports, storage, offline status and diagnostics.
import { html, icon, openSheet, flash, confirmDialog, promptDialog, fmtDate, fmtTime } from '../ui.js';
import { fmt, toCents, plain, setCurrency, ROUNDING_METHODS, computePayment, roundingChoices } from '../money.js';
import { checkState, summarizeShift } from '../ledger.js';
import { toCSV, SCHEMA_VERSION } from '../schema.js';
import { sealBackup, openBackup, isEncrypted } from '../crypto.js';
import * as store from '../store.js';
import { S } from '../store.js';
import * as db from '../db.js';
import { saveFile, isNative, platform } from '../native.js';
import { setPin, clearPin, pinSupported } from '../lock.js';
import { moneyInput, readMoney } from './forms.js';

export const APP_VERSION = '1.0.0';
export function title() { return { title: 'Settings', sub: 'Restaurant, privacy & data' }; }

let info = { storage: {}, sw: null, snapshots: [], photos: { n: 0, bytes: 0 } };
export async function load() {
  info.storage = await db.storageInfo();
  info.snapshots = await db.listSnapshots();
  const photos = await db.all('photos');
  info.photos = { n: photos.length, bytes: photos.reduce((a, p) => a + (p.size || 0), 0) };
  info.sw = null;
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const keys = await caches.keys();
      let n = 0; for (const k of keys) n += (await (await caches.open(k)).keys()).length;
      info.sw = { caches: keys, files: n };
    }
  } catch {}
}

const kb = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB';

export function render() {
  const st = S.settings;
  const sel = (key, opts) => html`<select class="input" data-set="${key}">${Object.entries(opts).map(([k, v]) => html`<option value="${k}" ${String(st[key]) === k ? 'selected' : ''}>${v}</option>`)}</select>`;
  const toggle = (key, label) => html`<label class="toggle"><span>${label}</span><span class="switch"><input type="checkbox" data-set-bool="${key}" ${st[key] ? 'checked' : ''}><span></span></span></label>`;
  const last = st.lastBackupAt ? `${fmtDate(st.lastBackupAt)} ${fmtTime(st.lastBackupAt)}` : 'Never';
  const offlineReady = !!info.sw || isNative();
  return html`
    <div class="section-title">Restaurant</div>
    <div class="card pad stack">
      <label class="field"><span>Restaurant name</span><input class="input" data-set="restaurantName" maxlength="60" value="${st.restaurantName}"></label>
      <label class="field"><span>Cash rounding method</span>${sel('roundingMethod', roundingChoices(!!st.allowRoundUp))}</label>
      ${toggle('allowRoundUp', 'Allow rounding up (off = cash checks only round down)')}
      ${st.allowRoundUp ? html`<div class="grid2">
        <label class="field"><span>Round what</span>${sel('roundingTarget', { ticket: 'Ticket total', change: 'Change amount' })}</label>
        <label class="field"><span>Exactly $.50</span>${sel('roundingHalf', { up: 'Rounds up', down: 'Rounds down' })}</label>
      </div>` : ''}
      <label class="field"><span>Cash settlement basis</span>${sel('policyCollect', { original: 'Restaurant collects original cash totals', rounded: 'Restaurant collects rounded cash totals' })}</label>
      <label class="field"><span>Card tip payout</span>${sel('policyCardTips', { deduct: 'Deducted from money owed', separate: 'Paid separately in cash', payroll: 'Paid through payroll', later: 'Paid at a later date' })}</label>
      <div class="grid2">
        <label class="field"><span>Default hourly wage</span><input class="input num" inputmode="decimal" data-set-money="hourlyWage" value="${st.hourlyWage ? plain(st.hourlyWage) : ''}" placeholder="0.00"></label>
        <label class="field"><span>Starting change bank</span><input class="input num" inputmode="decimal" data-set-money="startingBank" value="${st.startingBank ? plain(st.startingBank) : ''}" placeholder="0.00"></label>
      </div>
      <label class="field"><span>Common table numbers (comma separated)</span><input class="input" data-set-list="favoriteTables" value="${(st.favoriteTables || []).join(', ')}" maxlength="200"></label>
      <label class="field"><span>Lunch ends at (hour, 24h)</span><input class="input num" inputmode="numeric" data-set-int="lunchCutoffHour" value="${st.lunchCutoffHour}" maxlength="2"></label>
      <button class="btn sm" data-act="tipouts">${icon('users', 'sm')} Tip-out rules (${(st.tipoutRules || []).length})</button>
      <p class="muted" style="font-size:12.5px;margin:0">${st.allowRoundUp ? 'Rounding: “nearest” rounds 1–49¢ down and 51–99¢ up; exactly 50¢ follows the $.50 setting.' : 'Cash checks round down to the whole dollar (e.g. $42.65 → $42.00); the cents are a cash discount.'} Rounding differences are tracked separately and are never counted as tips. Original ticket totals are never changed.</p>
    </div>

    <div class="section-title">App preferences</div>
    <div class="card pad stack">
      <label class="field"><span>Everyday screen</span>${sel('uiMode', { simple: 'Simple (recommended)', full: 'Full — all features' })}</label>
      <label class="field"><span>Appearance</span>${sel('theme', { system: 'Match device', light: 'Light', dark: 'Dark' })}</label>
      <label class="field"><span>Open app to</span>${sel('homeScreen', { home: 'Home', tables: 'Tables', shift: 'Shift' })}</label>
      <label class="field"><span>After saving a transaction</span>${sel('afterSave', { next: 'Stay ready for the next table', home: 'Return to Home' })}</label>
      <label class="field"><span>Currency</span>${sel('currency', { USD: 'US Dollar ($)', CAD: 'Canadian Dollar', EUR: 'Euro (€)', GBP: 'British Pound (£)', AUD: 'Australian Dollar', MXN: 'Mexican Peso' })}</label>
      ${toggle('confirmDuplicate', 'Warn about possible duplicate entries')}
      ${toggle('confirmPartial', 'Confirm before saving a partial payment')}
      ${toggle('haptics', 'Haptic feedback on keypad')}
    </div>

    <div class="section-title">Privacy</div>
    <div class="card pad stack">
      <div class="row between"><div><b>Privacy PIN</b><div class="muted" style="font-size:13px">${st.pinHash ? 'On' : 'Off'}</div></div>
        <button class="btn sm" data-act="${st.pinHash ? 'pin-off' : 'pin-on'}" ${pinSupported() ? '' : 'disabled'}>${st.pinHash ? 'Remove PIN' : 'Set PIN'}</button></div>
      ${st.pinHash ? html`<label class="field"><span>Lock after the app is hidden for</span>${sel('pinLockMinutes', { 0: 'Immediately', 1: '1 minute', 5: '5 minutes', 15: '15 minutes', 60: '1 hour' })}</label>` : ''}
      <div class="banner info">${icon('shield', 'sm')}<div><b>PIN limits:</b> the PIN only hides the app's screens. Your records are stored unencrypted on this device. It does not protect against someone with your unlocked phone, a computer connection, or device backups. Use your phone's screen lock too.</div></div>
      <p class="muted" style="font-size:12.5px;margin:0">No analytics, ads, tracking or accounts. Data never leaves this device unless you export it.</p>
    </div>

    <div class="section-title">Backup & restore</div>
    <div class="card pad stack">
      <div class="row between"><span>Last backup</span><b>${last}</b></div>
      <div class="btnrow"><button class="btn primary" data-act="backup">${icon('download', 'sm')} Back up now</button><button class="btn" data-act="restore">${icon('upload', 'sm')} Restore</button></div>
      <label class="field"><span>Backup reminder</span>${sel('backupReminderDays', { 0: 'Off', 1: 'Daily', 3: 'Every 3 days', 7: 'Weekly', 30: 'Monthly' })}</label>
      <div class="banner warn">${icon('alert', 'sm')}<div>Records live only on this device. Uninstalling the app, clearing browser/site data or losing the phone can permanently erase them unless you keep a backup elsewhere (e.g. Google Drive).</div></div>
      ${info.snapshots.length ? html`<div class="field"><span>Automatic pre-restore snapshots</span><div class="list">${info.snapshots.map(sn => html`<button class="li" data-snap="${sn.id}">${icon('undo', 'sm')}<div class="grow"><div class="t">${fmtDate(sn.at)} ${fmtTime(sn.at)}</div><div class="s">${sn.reason}</div></div></button>`)}</div></div>` : ''}
    </div>

    <div class="section-title">Start fresh</div>
    <div class="card pad stack">
      <div class="muted" style="font-size:13.5px">Delete one shift: open it from <b>Shift → Previous shifts</b> or <b>Reports</b> and tap <b>Delete this shift</b>. To clear all practice data at once:</div>
      <button class="btn danger block" data-act="erase">Erase all shifts & tables</button>
      <div class="muted" style="font-size:12.5px">Settings are kept. A safety copy is saved above under snapshots, so this can be undone.</div>
    </div>

    <div class="section-title">Export reports (CSV)</div>
    <div class="card pad grid2">
      <button class="btn sm" data-csv="tx">Transactions</button><button class="btn sm" data-csv="shifts">Shifts</button>
      <button class="btn sm" data-csv="ledger">Cash ledger</button><button class="btn sm" data-csv="incidents">Incidents</button>
    </div>

    <div class="section-title">Storage & offline</div>
    <div class="card pad">
      <div class="kv"><span class="k">Database</span><span class="v">${db.backendName === 'sqlite' ? 'SQLite (Android app)' : 'IndexedDB (browser)'}</span></div>
      <div class="kv"><span class="k">Offline ready</span><span class="v ${offlineReady ? 'pos' : 'warn'}">${isNative() ? 'Yes — built into app' : offlineReady ? `Yes — ${info.sw.files} files cached` : 'Not yet — reload once online'}</span></div>
      <div class="kv"><span class="k">Connection</span><span class="v">${navigator.onLine ? 'Online' : 'Offline'}</span></div>
      ${!isNative() ? html`<div class="kv"><span class="k">Persistent storage</span><span class="v">${info.storage.persisted === null ? 'Unknown' : info.storage.persisted ? html`<span class="pos">Granted</span>` : html`<button class="pill warn" data-act="persist">Not granted — request</button>`}</span></div>` : ''}
      ${info.storage.usage != null ? html`<div class="kv"><span class="k">Space used</span><span class="v">${kb(info.storage.usage)}${info.storage.quota ? ' of ' + kb(info.storage.quota) : ''}</span></div>` : ''}
      <div class="kv"><span class="k">Photos</span><span class="v">${info.photos.n} · ${kb(info.photos.bytes)}</span></div>
      <div class="kv"><span class="k">Version</span><span class="v">${APP_VERSION} · data v${SCHEMA_VERSION} · ${platform()}</span></div>
      <div class="btnrow" style="margin-top:10px"><button class="btn sm" data-act="integrity">${icon('shield', 'sm')} Integrity check</button><button class="btn sm" data-act="diag">${icon('check', 'sm')} Run tests</button></div>
      <button class="btn sm block" style="margin-top:8px" data-act="audit">${icon('file', 'sm')} View change log</button>
    </div>
    <p class="faint" style="text-align:center;font-size:12px;margin:18px 0 0">ShiftCash ${APP_VERSION} — Every Table. Every Dollar.<br>Personal recordkeeping tool. Not a POS, payroll or tax service.</p>`;
}

export function applyTheme() {
  const t = S.settings.theme;
  const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0F1A13' : '#0A3520');
}

export function mount(root, rerender) {
  const save = async (k, v) => { await store.setSetting(k, v); if (k === 'theme') applyTheme(); if (k === 'currency') setCurrency(v); };
  root.addEventListener('change', async e => {
    const t = e.target, d = t.dataset;
    if (d.set) { let v = t.value; if (d.set === 'uiMode') { await save('uiMode', v); location.hash = v === 'simple' ? '#simple' : '#home'; return; } if (['backupReminderDays', 'pinLockMinutes'].includes(d.set)) v = +v; if (d.set === 'restaurantName') v = v.trim().slice(0, 60); await save(d.set, v); flash('Saved'); }
    if (d.setBool) {
      await save(d.setBool, t.checked);
      if (d.setBool === 'allowRoundUp' && !t.checked) { if (['up', 'nearest'].includes(S.settings.roundingMethod)) await save('roundingMethod', 'down'); await save('roundingTarget', 'ticket'); }
      if (d.setBool === 'allowRoundUp') rerender();
    }
    if (d.setMoney) { const c = t.value.trim() === '' ? 0 : toCents(t.value); if (Number.isNaN(c) || c < 0) return flash('Enter a valid amount.'); await save(d.setMoney, c); flash('Saved'); }
    if (d.setList) { const list = [...new Set(t.value.split(',').map(x => x.trim()).filter(Boolean).map(x => x.slice(0, 6)))].slice(0, 30); await save(d.setList, list); flash('Saved'); }
    if (d.setInt) { const n = Math.max(0, Math.min(23, parseInt(t.value, 10) || 0)); await save(d.setInt, n); }
  });
  root.addEventListener('click', async e => {
    const t = e.target;
    const csv = t.closest('[data-csv]'); if (csv) return exportCSV({ kind: csv.dataset.csv });
    const sn = t.closest('[data-snap]');
    if (sn) {
      if (!(await confirmDialog({ title: 'Restore snapshot?', message: 'Your current data will first be saved as another snapshot, then replaced with this one.', ok: 'Restore' }))) return;
      await db.restoreSnapshot(sn.dataset.snap); await store.init(); await load(); rerender(); return flash('Snapshot restored');
    }
    switch (t.closest('[data-act]')?.dataset.act) {
      case 'pin-on': {
        const a = await promptDialog({ title: 'Set PIN', label: 'Choose a 4–6 digit PIN', placeholder: '••••' }); if (!a) return;
        if (!/^\d{4,6}$/.test(a)) return flash('PIN must be 4–6 digits.');
        const b = await promptDialog({ title: 'Confirm PIN', label: 'Enter the PIN again' }); if (a !== b) return flash('PINs did not match.');
        await setPin(a); rerender(); return flash('PIN set');
      }
      case 'pin-off': if (await confirmDialog({ title: 'Remove PIN?', message: 'The app will open without a PIN.', ok: 'Remove' })) { await clearPin(); rerender(); } return;
      case 'backup': return backupSheet(rerender);
      case 'restore': return restoreSheet(rerender);
      case 'persist': { const ok = await db.requestPersist(); await load(); rerender(); return flash(ok ? 'Persistent storage granted' : 'Browser declined. Installing the app to the home screen usually helps.'); }
      case 'integrity': {
        const r = await db.integrityCheck();
        return openSheet({ title: 'Integrity check', body: html`<div class="stack">${r.problems.length ? html`<div class="banner warn">${icon('alert', 'sm')}<div>${r.problems.length} problem(s) found. Nothing was changed.</div></div><div class="list">${r.problems.map(p => html`<div class="li"><div class="grow s">${p}</div></div>`)}</div>` : html`<div class="banner ok">${icon('check', 'sm')}<div>No problems found in ${r.backend === 'sqlite' ? 'SQLite' : 'IndexedDB'}.</div></div>`}
          <div class="card pad">${Object.entries(r.counts).map(([k, v]) => html`<div class="kv"><span class="k">${k}</span><span class="v num">${v}</span></div>`)}</div></div>` });
      }
      case 'erase': {
        const n = (await db.all('shifts')).length;
        const v = await promptDialog({ title: 'Erase everything?', label: `This deletes ${n} shift${n === 1 ? '' : 's'} with all tables, tips and cash entries. Type DELETE to confirm.`, ok: 'Erase all' });
        if (v === null) return;
        if (v.trim().toUpperCase() !== 'DELETE') return flash('Nothing erased — type DELETE to confirm.');
        await store.eraseAllRecords(); await load(); rerender(); return flash('All records erased. Fresh start!');
      }
      case 'diag': return diagnostics();
      case 'audit': return auditLog();
      case 'tipouts': return tipoutRules(rerender);
    }
  });
}

// ---------- backup ----------
function backupSheet(rerender) {
  const s = openSheet({
    title: 'Back up now', body: html`<div class="stack">
      <label class="toggle"><span>Include photos</span><span class="switch"><input type="checkbox" data-photos checked><span></span></span></label>
      <label class="field"><span>Password (optional — encrypts the file)</span><input class="input" type="password" data-pw autocomplete="new-password" maxlength="100" placeholder="Leave blank for an unencrypted file"></label>
      <p class="muted" style="font-size:12.5px;margin:0">Encrypted backups use AES-256. If you forget the password, the backup cannot be opened. ${isNative() ? 'The file is saved to Documents/ShiftCash and the share sheet opens so you can also save it to Google Drive.' : 'The file downloads to your phone. Upload it to Google Drive or email it to yourself for safekeeping.'}</p></div>`,
    foot: html`<button class="btn primary block">${icon('download', 'sm')} Create backup</button>`,
  });
  s.foot.addEventListener('click', async () => {
    const pw = s.body.querySelector('[data-pw]').value;
    if (pw && pw.length < 6) return flash('Use at least 6 characters for the password.');
    const data = await db.exportAll({ photos: s.body.querySelector('[data-photos]').checked });
    const text = await sealBackup(data, pw);
    // verify the file can be read back before calling it a backup
    try { await openBackup(text, pw); } catch (e) { return flash('Backup verification failed: ' + e.message); }
    const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
    const res = await saveFile(`shiftcash-backup-${stamp}${pw ? '-encrypted' : ''}.json`, text, 'application/json');
    await store.setSetting('lastBackupAt', Date.now());
    s.close(); rerender(); flash(`Backup saved to ${res.where} (verified)`);
  });
}

function restoreSheet(rerender) {
  const s = openSheet({
    title: 'Restore from backup', body: html`<div class="stack">
      <input type="file" accept="application/json,.json" class="input" data-file style="padding-top:12px">
      <div data-preview></div></div>`,
  });
  let parsed = null;
  s.body.addEventListener('change', async e => {
    if (!e.target.matches('[data-file]')) return;
    const f = e.target.files?.[0]; if (!f) return;
    if (f.size > 200 * 1024 * 1024) return flash('File too large.');
    const text = await f.text();
    let pw = '';
    if (isEncrypted(text)) { pw = await promptDialog({ title: 'Encrypted backup', label: 'Backup password', ok: 'Unlock' }); if (pw === null) return; }
    try { parsed = await openBackup(text, pw); } catch (err) { parsed = null; s.body.querySelector('[data-preview]').innerHTML = ''; return flash(err.message, [], 6000); }
    const d = parsed.data;
    const pv = s.body.querySelector('[data-preview]');
    pv.replaceChildren();
    const tmp = document.createElement('div');
    tmp.innerHTML = html`<div class="card pad">
      <div class="kv"><span class="k">Created</span><span class="v">${parsed.exportedAt ? new Date(parsed.exportedAt).toLocaleString() : 'Unknown'}</span></div>
      <div class="kv"><span class="k">Shifts · checks</span><span class="v">${d.shifts.length} · ${d.checks.length}</span></div>
      <div class="kv"><span class="k">Photos</span><span class="v">${d.photos.length}</span></div>
      <div class="kv"><span class="k">Integrity</span><span class="v pos">${parsed.checksumVerified ? 'Checksum verified' : 'Valid (no checksum)'}</span></div></div>
      <div class="btnrow" style="margin-top:10px"><button class="btn" data-mode="merge">Merge</button><button class="btn danger" data-mode="replace">Replace all</button></div>
      <p class="muted" style="font-size:12.5px">Merge adds and updates records by ID and removes nothing. Replace swaps your data for the backup. Either way, a snapshot of your current data is saved first so you can undo.</p>`.__raw;
    pv.append(...tmp.childNodes);
  });
  s.body.addEventListener('click', async e => {
    const m = e.target.closest('[data-mode]'); if (!m || !parsed) return;
    if (m.dataset.mode === 'replace' && !(await confirmDialog({ title: 'Replace all data?', message: 'Your current records will be replaced by the backup. A snapshot of the current data is kept so this can be undone.', ok: 'Replace', danger: true }))) return;
    await db.restore(parsed.data, m.dataset.mode);
    await store.init(); s.close(); rerender(); flash('Backup restored');
  });
}

// ---------- CSV ----------
export async function exportCSV({ kind = 'tx', from = 0, to = Infinity } = {}) {
  const inRange = t => t >= from && t < to;
  const shifts = (await db.all('shifts')).filter(s => inRange(s.startedAt));
  const ids = new Set(shifts.map(s => s.id));
  const d = t => new Date(t).toLocaleString();
  const m = c => (c / 100).toFixed(2);
  let rows;
  if (kind === 'shifts') {
    const [checks, moves, payouts] = await Promise.all([db.all('checks'), db.all('moves'), db.all('payouts')]);
    rows = [['Shift start', 'Shift end', 'Hours', 'Checks', 'Tables', 'Cash sales', 'Card sales', 'Cash tips', 'Card tips', 'Tip-outs', 'Net tips', 'Card tips outstanding', 'Rounding', 'Expected owed', 'Expected cash', 'Status']];
    for (const sh of shifts) {
      const s = summarizeShift({ shift: sh, checks: checks.filter(c => c.shiftId === sh.id), moves: moves.filter(x => x.shiftId === sh.id), payouts: payouts.filter(x => x.shiftId === sh.id) });
      rows.push([d(sh.startedAt), sh.endedAt ? d(sh.endedAt) : '', s.hours.toFixed(2), s.checks, s.tables, m(s.cashSales), m(s.cardSales), m(s.cashTips), m(s.cardTips), m(s.tipouts), m(s.netTips), m(s.cardTipsOutstanding), m(s.roundingAdj), m(s.owed), m(s.expectedCash), sh.status]);
    }
  } else if (kind === 'ledger') {
    rows = [['Time', 'Type', 'Amount', 'Via', 'Note', 'Voided']];
    for (const x of (await db.all('moves')).filter(x => ids.has(x.shiftId))) rows.push([d(x.createdAt), x.type, m(x.amount), x.via || '', x.note || '', x.voided ? 'yes' : '']);
    for (const x of (await db.all('payouts')).filter(x => ids.has(x.shiftId))) rows.push([d(x.at), 'card tip payout', m(x.amount), x.via, x.note || '', x.voided ? 'yes' : '']);
  } else if (kind === 'incidents') {
    rows = [['Time', 'Type', 'Table', 'Amount', 'Description', 'Resolution', 'Resolved']];
    for (const i of await db.all('incidents')) if (inRange(i.createdAt)) rows.push([d(i.createdAt), store.INCIDENT_TYPES[i.type] || i.type, i.table || '', m(i.amount | 0), i.description || '', i.resolution || '', i.resolved ? 'yes' : 'no']);
  } else {
    rows = [['Time', 'Table', 'Ticket #', 'Ticket total', 'Discount', 'Comp', 'Payment', 'Amount', 'Rounded payable', 'Cash received', 'Change returned', 'Rounding', 'Card tip', 'Card tip status', 'Cash tip', 'Unconfirmed excess', 'Shortage', 'Check status', 'Voided', 'Notes']];
    for (const c of (await db.all('checks')).filter(c => ids.has(c.shiftId)).sort((a, b) => a.createdAt - b.createdAt)) {
      const st = checkState(c);
      const pays = (c.payments || []);
      if (!pays.length) rows.push([d(c.createdAt), c.table, c.ticketNo || '', m(c.ticketCents), m(c.discountCents | 0), m(c.compCents | 0), '', '', '', '', '', '', '', '', '', '', '', st.status, c.voided ? 'yes' : '', c.notes || '']);
      pays.forEach((p, i) => {
        const x = computePayment(p) || {};
        rows.push([d(p.createdAt || c.createdAt), c.table, c.ticketNo || '', i === 0 ? m(c.ticketCents) : '', i === 0 ? m(c.discountCents | 0) : '', i === 0 ? m(c.compCents | 0) : '',
          x.method === 'refund' ? 'refund ' + x.via : x.method, m(x.method === 'refund' ? -x.amount : x.due), x.roundedDue != null ? m(x.roundedDue) : '', x.received != null ? m(x.received) : '',
          x.changeGiven != null ? m(x.changeGiven) : '', x.roundingAdj != null ? m(x.roundingAdj) : '', x.tip != null ? m(x.tip) : '', x.tipStatus || '', m(x.cashTip || 0), m(x.unconfirmed || 0), m(x.shortage || 0),
          st.status, c.voided || p.voided ? 'yes' : '', c.notes || '']);
      });
    }
  }
  const res = await saveFile(`shiftcash-${kind}-${new Date().toISOString().slice(0, 10)}.csv`, toCSV(rows), 'text/csv');
  flash(`CSV saved to ${res.where}`);
}

// ---------- tip-out rules ----------
function tipoutRules(rerender) {
  let rules = (S.settings.tipoutRules || []).map(r => ({ ...r }));
  const s = openSheet({ title: 'Tip-out rules', body: html``, foot: html`<button class="btn primary block" data-save>Save rules</button>` });
  const draw = () => s.update(html`<div class="stack">
    <p class="muted" style="font-size:13px;margin:0">Optional. Rules appear as one-tap buttons on the Shift screen and calculate from that shift's gross figures.</p>
    ${rules.map((r, i) => html`<div class="card pad stack">
      <div class="grid2"><label class="field"><span>Recipient</span><input class="input" data-r="${i}" data-k="name" value="${r.name}" maxlength="30" placeholder="Busser"></label>
      <label class="field"><span>Type</span><select class="input" data-r="${i}" data-k="mode"><option value="fixed" ${r.mode === 'fixed' ? 'selected' : ''}>Fixed $</option><option value="pct_sales" ${r.mode === 'pct_sales' ? 'selected' : ''}>% of sales</option><option value="pct_tips" ${r.mode === 'pct_tips' ? 'selected' : ''}>% of tips</option></select></label></div>
      <div class="grid2"><label class="field"><span>${r.mode === 'fixed' ? 'Amount' : 'Percent'}</span><input class="input num" inputmode="decimal" data-r="${i}" data-k="val" value="${r.mode === 'fixed' ? plain(r.cents | 0) : ((r.bp | 0) / 100).toFixed(2)}"></label>
      <label class="field"><span>Paid</span><select class="input" data-r="${i}" data-k="via"><option value="cash" ${r.via !== 'deducted' ? 'selected' : ''}>From my cash</option><option value="deducted" ${r.via === 'deducted' ? 'selected' : ''}>Restaurant deducts</option></select></label></div>
      <button class="btn sm danger" data-del="${i}">Remove</button></div>`)}
    <button class="btn" data-add>${icon('plus', 'sm')} Add rule</button></div>`);
  const sync = () => s.body.querySelectorAll('[data-r]').forEach(el => {
    const r = rules[+el.dataset.r], k = el.dataset.k, v = el.value;
    if (k === 'val') { if (r.mode === 'fixed') r.cents = Math.max(0, toCents(v) || 0); else r.bp = Math.max(0, Math.min(10000, Math.round(parseFloat(v) * 100) || 0)); }
    else r[k] = k === 'name' ? v.trim().slice(0, 30) : v;
  });
  s.body.addEventListener('change', e => { if (e.target.dataset.k === 'mode') { sync(); draw(); } });
  s.body.addEventListener('click', e => {
    if (e.target.closest('[data-add]')) { sync(); rules.push({ id: db.uid('r'), name: '', mode: 'pct_sales', bp: 0, cents: 0, via: 'cash' }); draw(); }
    const d = e.target.closest('[data-del]'); if (d) { sync(); rules.splice(+d.dataset.del, 1); draw(); }
  });
  s.foot.addEventListener('click', async () => { sync(); rules = rules.filter(r => r.name); await store.setSetting('tipoutRules', rules); s.close(); rerender(); flash('Tip-out rules saved'); });
  draw();
}

// ---------- diagnostics ----------
async function diagnostics() {
  const s = openSheet({ title: 'Self-test', body: html`<div class="empty">Running…</div>` });
  const { runCases } = await import('../testcases.js');
  const res = runCases();
  // storage round trip in a separate scratch area (never touches your records)
  let storage = 'skipped';
  try {
    const id = 'selftest_' + Date.now();
    await db.meta(id, { ok: 1, cents: 12345 });
    const back = await db.meta(id);
    storage = back && back.cents === 12345 ? 'passed' : 'FAILED';
  } catch (e) { storage = 'FAILED: ' + e.message; }
  const failed = res.filter(r => !r.ok);
  s.update(html`<div class="stack">
    <div class="banner ${failed.length ? 'neg' : 'ok'}">${icon(failed.length ? 'alert' : 'check', 'sm')}<div><b>${res.length - failed.length}/${res.length}</b> accounting tests passed · storage write/read ${storage}</div></div>
    <div class="list">${res.map(r => html`<div class="li"><span class="${r.ok ? 'pos' : 'neg'}">${icon(r.ok ? 'check' : 'close', 'sm')}</span><div class="grow"><div class="t" style="font-weight:500;font-size:14px">${r.name}</div>${r.ok ? '' : html`<div class="s neg">${r.error}</div>`}</div></div>`)}</div></div>`);
}

async function auditLog() {
  const items = (await db.all('audit')).sort((a, b) => b.at - a.at).slice(0, 200);
  openSheet({
    title: 'Change log', sub: 'Local record — not tamper-proof',
    body: html`${items.length ? html`<div class="list">${items.map(a => html`<div class="li"><div class="grow"><div class="t" style="font-size:14px">${a.entity} · ${a.action}</div><div class="s">${fmtDate(a.at)} ${fmtTime(a.at)}${a.reason ? ' · ' + a.reason : ''}</div></div></div>`)}</div>` : html`<div class="empty">No changes recorded yet.</div>`}`,
  });
}
