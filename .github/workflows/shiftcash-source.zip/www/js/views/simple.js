// ShiftCash — Simple mode: the everyday screen.
// One list of tables. "New table" asks one thing per screen: table → bill → cash/card → (cash given → change).
// When the table leaves: tap it, type the tip, close it. Everything else lives behind "Details".
import { html, icon, openSheet, flash, confirmDialog, fmtTime, $ } from '../ui.js';
import { fmt, keypadAppend, keypadBackspace, cashPayment, cardPayment, computePayment } from '../money.js';
import { checkState } from '../ledger.js';
import * as store from '../store.js';
import { S } from '../store.js';
import { uid } from '../db.js';
import { haptic } from '../native.js';
import { pendingTips } from './tips.js';
import { openCheckDetail } from './tables.js';

export function title() {
  return { title: 'ShiftCash', sub: S.settings.restaurantName || 'Every Table. Every Dollar.', logo: true, simple: true };
}

const tipOf = c => {
  let t = 0;
  for (const p of c.payments || []) { if (p.voided) continue; const x = computePayment(p); if (x) t += (x.tip || 0) + (x.cashTip || 0); }
  return t;
};

/** Group waiting payments by table so a big party's checks sit together. */
function groups(open) {
  const out = [];
  for (const o of open) {
    let g = out.find(x => x.table === String(o.check.table));
    if (!g) out.push(g = { table: String(o.check.table), items: [], ids: new Set() });
    g.items.push({ ...o, part: (o.check.payments || []).filter(p => !p.voided && p.method !== 'refund').length > 1 });
    g.ids.add(o.check.id);
  }
  for (const g of out) g.checks = g.ids.size;
  return out;
}

export function render() {
  const s = S.summary;
  const open = pendingTips();
  const openIds = new Set(open.map(o => o.check.id));
  const closed = [...S.checks].filter(c => !c.voided && !openIds.has(c.id)).reverse();
  return html`
    <div class="hero simple-hero">
      <div class="label">Tips today</div>
      <div class="big num">${fmt(s ? s.totalTips : 0)}</div>
      ${s ? html`<div class="split"><span>Cash ${fmt(s.cashTips)}</span><span>Card ${fmt(s.cardTips)}</span></div>` : ''}
    </div>

    <button class="btn primary block simple-new" data-act="new">${icon('plus')} New table</button>

    <div class="section-title">Waiting for tip ${open.length ? html`<span class="pill warn">${open.length}</span>` : ''}</div>
    ${open.length ? groups(open).map(g => html`<div class="list" style="margin-bottom:10px">
      ${g.checks > 1 || g.items.length > 1 ? html`<div class="li" style="min-height:44px;background:var(--surface-2)"><span class="tbl-badge big">${g.table}</span>
        <div class="grow"><div class="t">Table ${g.table}</div><div class="s">${g.checks} check${g.checks > 1 ? 's' : ''} open</div></div>
        <button class="btn sm" data-another="${g.table}">+ Another check</button></div>` : ''}
      ${g.items.map(({ check: c, pay: p, x, part }) => html`
      <button class="li simple-row" data-close="${c.id}|${p.id}">
        ${g.checks > 1 || g.items.length > 1 ? html`<span style="width:52px"></span>` : html`<span class="tbl-badge big">${c.table}</span>`}
        <div class="grow"><div class="t num">${part ? `${fmt(x.due)} of ${fmt(c.ticketCents)}` : fmt(c.ticketCents)}</div>
          <div class="s">${part ? 'Split · ' : ''}${x.method === 'cash' ? (x.changeGiven ? `Cash · gave back ${fmt(x.changeGiven)}` : 'Cash · exact') : 'Card'} · ${fmtTime(c.createdAt)}</div></div>
        <span class="btn sm primary" style="pointer-events:none">Add tip</span>
      </button>`)}
    </div>`)
    : html`<div class="card pad muted" style="text-align:center">No open tables. Tap <b>New table</b> when a table pays.</div>`}

    ${closed.length ? html`<div class="section-title">Closed <span class="muted" style="text-transform:none;letter-spacing:0;font-weight:500">${closed.length}</span></div>
      <div class="list">${closed.slice(0, 30).map(c => html`<button class="li" data-check="${c.id}">
        <span class="tbl-badge">${c.table}</span>
        <div class="grow"><div class="t num">${fmt(c.ticketCents)}</div><div class="s">${checkState(c).kind === 'cash' ? 'Cash' : checkState(c).kind === 'card' ? 'Card' : 'Split'} · ${fmtTime(c.createdAt)}</div></div>
        <span class="amt num pos">${fmt(tipOf(c))}</span></button>`)}</div>` : ''}

    ${S.shift ? html`<button class="btn block" style="margin-top:22px" data-act="end">${icon('stop', 'sm')} End of night</button>` : ''}
    <button class="btn ghost block" style="margin-top:6px" data-act="details">More details & settings</button>`;
}

export function mount(root) {
  root.addEventListener('click', e => {
    const t = e.target;
    const cl = t.closest('[data-close]'); if (cl) { const [cid, pid] = cl.dataset.close.split('|'); return closeTable(cid, pid); }
    const an = t.closest('[data-another]'); if (an) return newTable({ table: an.dataset.another });
    const ch = t.closest('[data-check]'); if (ch) return openCheckDetail(ch.dataset.check);
    switch (t.closest('[data-act]')?.dataset.act) {
      case 'new': return newTable();
      case 'end': return endNight();
      case 'details': return store.setSetting('uiMode', 'full').then(() => { location.hash = '#home'; });
    }
  });
}

// ---------------- shared big keypad ----------------
function keypadHTML(saveLabel) {
  return html`<div class="keypad big" id="skp">
    ${[1, 2, 3].map(n => html`<button data-k="${n}">${n}</button>`)}
    ${[4, 5, 6].map(n => html`<button data-k="${n}">${n}</button>`)}
    ${[7, 8, 9].map(n => html`<button data-k="${n}">${n}</button>`)}
    <button data-k="bs" class="k-act" aria-label="Delete">⌫</button><button data-k="0">0</button><button data-k="ok" class="k-ok" id="skOk">${saveLabel}</button>
  </div>`;
}

// ---------------- New table / new check wizard ----------------
// Each check is entered on its own. Checks at the same table while that table still has open checks
// belong to the same party (visit), so a 20-top with 6 checks counts as 1 table, 6 checks.
const openVisitFor = table => {
  const open = pendingTips().filter(o => String(o.check.table) === String(table));
  return open.length ? open[open.length - 1].check.visitId : null;
};

export async function newTable(preset = {}) {
  if (!S.shift) await store.startShift({ startingCash: S.settings.startingBank || 0 });
  const W = { step: preset.table ? 'bill' : 'table', table: preset.table ? String(preset.table) : '', bill: 0, method: null, given: 0, saving: false,
    parts: [], part: null };   // split: parts = [{ method, amount, given }]; part = the part being entered
  const s = openSheet({ full: true, title: preset.table ? `Another check · Table ${preset.table}` : 'New table', body: html``, after: keypadHTML('Next') });
  const kp = $('#skp', s.el), ok = $('#skOk', s.el);
  const rounding = store.roundingFromSettings();
  const cashOf = (due, given) => cashPayment({ due, received: given, rounding, changeGiven: null, tipPending: true });
  const remaining = () => W.bill - W.parts.reduce((a, p) => a + p.amount, 0);

  const changeCard = (due, given) => {
    const p = cashOf(due, given);
    if (!given) return html`<div class="change-card idle"><div class="lbl">Give back</div><div class="amt">Tap the bills they gave you</div></div>`;
    if (given < p.roundedDue) return html`<div class="change-card bad"><div class="lbl">Not enough</div><div class="amt num">${fmt(p.roundedDue - given)} short</div></div>`;
    return html`<div class="change-card"><div class="lbl">Give back</div><div class="amt num">${fmt(p.expectedChange)}</div>
      ${p.roundingAdj ? html`<div class="sub">${fmt(due)} → ${fmt(p.roundedDue)} cash</div>` : ''}</div>`;
  };
  const denoms = html`<div class="denoms">${[100, 500, 1000, 2000, 5000, 10000].map(v => html`<button data-denom="${v}">+$${v / 100}</button>`)}</div>`;

  function draw() {
    const back = W.step !== 'table' ? html`<button class="btn ghost sm" data-back style="margin:-4px 0 4px -6px">${icon('back', 'sm')} Back</button>` : '';
    const sameParty = W.table && openVisitFor(W.table);
    const summary = html`<div class="wiz-summary">${W.table ? html`<span>Table <b>${W.table}</b></span>` : ''}${W.bill && W.step !== 'bill' ? html`<span>Bill <b class="num">${fmt(W.bill)}</b></span>` : ''}${W.method ? html`<span><b>${{ cash: 'Cash', card: 'Card', split: 'Split' }[W.method]}</b></span>` : ''}</div>`;
    kp.classList.toggle('hidden', W.step === 'method' || W.step === 'split');
    ok.disabled = false;
    if (W.step === 'table') {
      const favs = S.settings.favoriteTables || [];
      s.update(html`${summary}<div class="wiz-q">Table number?</div>
        <div class="wiz-val num ${W.table ? '' : 'ph'}">${W.table || '—'}</div>
        ${sameParty ? html`<div class="banner info" style="justify-content:center">Table ${W.table} already has open checks — this will be another check for the same party.</div>` : ''}
        <div class="chips" style="justify-content:center;flex-wrap:wrap">${favs.map(t => html`<button class="chip ${W.table === t ? 'on' : ''}" data-table="${t}">${t}</button>`)}</div>`);
      ok.textContent = 'Next'; ok.disabled = !W.table;
    } else if (W.step === 'bill') {
      s.update(html`${preset.table ? '' : back}${summary}<div class="wiz-q">${sameParty ? 'How much is this check?' : 'How much is the bill?'}</div>
        <div class="wiz-val num ${W.bill ? '' : 'ph'}">${fmt(W.bill)}</div>
        <div class="muted" style="text-align:center;font-size:14px">Type every digit: 4 2 6 5 = $42.65</div>`);
      ok.textContent = 'Next'; ok.disabled = !W.bill;
    } else if (W.step === 'method') {
      s.update(html`${back}${summary}<div class="wiz-q">How are they paying?</div>
        <div class="wiz-methods">
          <button class="wiz-method" data-method="cash">${icon('cash', 'lg')}<span>Cash</span></button>
          <button class="wiz-method" data-method="card">${icon('card', 'lg')}<span>Card</span></button>
        </div>
        <button class="wiz-method wide" data-method="split">${icon('split', 'lg')}<span>Split <small>cash + card, or several cards</small></span></button>`);
    } else if (W.step === 'cash') {
      const p = cashOf(W.bill, W.given);
      s.update(html`${back}${summary}
        <div class="wiz-q" style="margin-top:4px">Cash they gave you</div>
        <div class="wiz-val num ${W.given ? '' : 'ph'}" style="font-size:40px">${fmt(W.given)}</div>
        ${denoms}${changeCard(W.bill, W.given)}
        <button class="btn sm block" data-clear style="margin-top:8px">Start over</button>`);
      ok.textContent = 'Save'; ok.disabled = !W.given || W.given < p.roundedDue || W.saving;
    } else if (W.step === 'split') {
      const rem = remaining();
      s.update(html`${back}${summary}
        <div class="wiz-q">Split the bill</div>
        <div class="card pad">
          ${W.parts.map((p, i) => html`<div class="kv"><span class="k">${icon(p.method === 'cash' ? 'cash' : 'card', 'sm')} <span>${p.method === 'cash' ? 'Cash' : 'Card'}${p.method === 'cash' ? html`<br><span class="muted" style="font-size:12.5px">gave back ${fmt(cashOf(p.amount, p.given).expectedChange)}</span>` : ''}</span></span>
            <span class="v num row" style="gap:8px">${fmt(p.amount)} <button class="iconbtn" style="width:34px;height:34px" data-delpart="${i}" aria-label="Remove">${icon('close', 'sm')}</button></span></div>`)}
          <div class="kv total"><span class="k">${rem > 0 ? 'Still to pay' : rem < 0 ? 'Too much' : 'All paid'}</span><span class="v num ${rem ? 'warn' : 'pos'}">${fmt(Math.abs(rem))}</span></div>
        </div>
        ${rem > 0 ? html`<div class="wiz-methods" style="margin-top:12px">
          <button class="wiz-method short" data-part="card">${icon('card', 'lg')}<span>+ Card part</span></button>
          <button class="wiz-method short" data-part="cash">${icon('cash', 'lg')}<span>+ Cash part</span></button></div>` : ''}
        ${rem === 0 ? html`<button class="btn primary lg block" style="margin-top:14px" data-savesplit ${W.saving ? 'disabled' : ''}>Save</button>` : ''}`);
    } else if (W.step === 'partAmount') {
      s.update(html`${back}${summary}<div class="wiz-q">How much on this ${W.part.method === 'cash' ? 'cash part' : 'card'}?</div>
        <div class="wiz-val num ${W.part.amount ? '' : 'ph'}">${fmt(W.part.amount)}</div>
        <div class="muted" style="text-align:center;font-size:14px">${W.part.fresh ? 'The rest of the bill — or type a different amount' : 'Still to pay: ' + fmt(remaining())}</div>`);
      ok.textContent = W.part.method === 'cash' ? 'Next' : 'Add';
      ok.disabled = !W.part.amount || W.part.amount > remaining();
    } else if (W.step === 'partCash') {
      const p = cashOf(W.part.amount, W.part.given);
      s.update(html`${back}${summary}
        <div class="wiz-q" style="margin-top:4px">Cash they gave for ${fmt(W.part.amount)}</div>
        <div class="wiz-val num ${W.part.given ? '' : 'ph'}" style="font-size:40px">${fmt(W.part.given)}</div>
        ${denoms}${changeCard(W.part.amount, W.part.given)}`);
      ok.textContent = 'Add'; ok.disabled = !W.part.given || W.part.given < p.roundedDue;
    }
  }

  const cashRecord = (due, given) => ({ method: 'cash', due, received: given, rounding, changeGiven: cashOf(due, given).expectedChange, keptTip: 0, extraTip: 0, tipPending: true });
  const cardRecord = due => ({ method: 'card', due, tip: null, tipStatus: 'pending', extraCashTip: 0, receipt: '' });

  async function save() {
    if (W.saving) return;
    W.saving = true; draw();
    try {
      let payments;
      if (W.method === 'cash') payments = [cashRecord(W.bill, W.given)];
      else if (W.method === 'card') payments = [cardRecord(W.bill)];
      else payments = W.parts.map(p => p.method === 'cash' ? cashRecord(p.amount, p.given) : cardRecord(p.amount));
      const visitId = openVisitFor(W.table) || uid('v');
      const saved = await store.saveNewCheck({
        shiftId: S.shift.id, visitId, table: W.table, ticketNo: '', ticketCents: W.bill, discountCents: 0, compCents: 0,
        notes: '', segment: S.shift.segment, payments: payments.map(p => ({ id: uid('p'), createdAt: Date.now(), ...p })),
      });
      s.close();
      const change = payments.filter(p => p.method === 'cash').reduce((a, p) => a + p.changeGiven, 0);
      flash(`Table ${saved.table} saved${change ? ` · gave back ${fmt(change)}` : ''}`, [
        { label: 'Another check', run: () => newTable({ table: saved.table }) },
        { label: 'Undo', run: async () => { await store.voidCheck(saved.id, 'Undone right after entry'); flash('Removed'); } },
      ], 6000);
    } finally { W.saving = false; }
  }

  kp.addEventListener('click', e => {
    const k = e.target.closest('[data-k]')?.dataset.k; if (!k) return;
    if (S.settings.haptics) haptic(6);
    const num = v => (k === 'bs' ? keypadBackspace(v) : keypadAppend(v, +k));
    if (k === 'ok') {
      if (ok.disabled) return;
      if (W.step === 'table') W.step = 'bill';
      else if (W.step === 'bill') W.step = 'method';
      else if (W.step === 'cash') return save();
      else if (W.step === 'partAmount') { if (W.part.method === 'cash') W.step = 'partCash'; else { W.parts.push(W.part); W.part = null; W.step = 'split'; } }
      else if (W.step === 'partCash') { W.parts.push(W.part); W.part = null; W.step = 'split'; }
      return draw();
    }
    if (W.step === 'table') W.table = k === 'bs' ? W.table.slice(0, -1) : (W.table.length < 4 ? (W.table + k).replace(/^0+(?=\d)/, '') : W.table);
    else if (W.step === 'bill') W.bill = num(W.bill);
    else if (W.step === 'cash') W.given = num(W.given);
    else if (W.step === 'partAmount') { if (W.part.fresh) { W.part.amount = 0; W.part.fresh = false; } W.part.amount = num(W.part.amount); }
    else if (W.step === 'partCash') W.part.given = num(W.part.given);
    draw();
  });
  s.body.addEventListener('click', async e => {
    const t = e.target;
    const tb = t.closest('[data-table]'); if (tb) { W.table = tb.dataset.table; W.step = 'bill'; return draw(); }
    const m = t.closest('[data-method]');
    if (m) {
      W.method = m.dataset.method;
      if (W.method === 'card') return save();
      W.step = W.method === 'cash' ? 'cash' : 'split';
      return draw();
    }
    const pt = t.closest('[data-part]'); if (pt) { W.part = { method: pt.dataset.part, amount: remaining(), given: 0, fresh: true }; W.step = 'partAmount'; return draw(); }
    const dp = t.closest('[data-delpart]'); if (dp) { W.parts.splice(+dp.dataset.delpart, 1); return draw(); }
    if (t.closest('[data-savesplit]')) return save();
    const d = t.closest('[data-denom]');
    if (d) { if (W.step === 'partCash') W.part.given += +d.dataset.denom; else W.given += +d.dataset.denom; if (S.settings.haptics) haptic(); return draw(); }
    if (t.closest('[data-clear]')) { W.given = 0; return draw(); }
    if (t.closest('[data-back]')) {
      const prev = { bill: 'table', method: 'bill', cash: 'method', split: 'method', partAmount: 'split', partCash: 'partAmount' }[W.step];
      if (W.step === 'partAmount') W.part = null;
      if (W.step === 'partCash') W.part.given = 0;
      if (prev === 'method') { W.method = null; W.given = 0; W.parts = []; }
      W.step = prev; return draw();
    }
  });
  draw();
}

// ---------------- Close a table: enter the tip ----------------
export function closeTable(checkId, payId) {
  const c = S.checks.find(x => x.id === checkId); if (!c) return;
  const p = c.payments.find(x => x.id === payId); const x = computePayment(p);
  let tip = 0, saving = false;
  const s = openSheet({ full: true, title: `Table ${c.table}`, sub: 'Close table', body: html``, after: keypadHTML('Close table') });
  const ok = $('#skOk', s.el);
  const draw = () => {
    s.update(html`
      <div class="wiz-summary"><span>Bill <b class="num">${fmt(c.ticketCents)}</b></span><span><b>${x.method === 'cash' ? 'Cash' : 'Card'}${x.due !== c.ticketCents ? ' ' + fmt(x.due) : ''}</b></span>
        ${x.method === 'cash' ? html`<span>Gave back <b class="num">${fmt(x.changeGiven)}</b></span>` : ''}</div>
      <div class="wiz-q">${x.method === 'cash' ? 'Tip they left?' : 'Tip on the card slip?'}</div>
      <div class="wiz-val num ${tip ? '' : 'ph'}">${fmt(tip)}</div>
      ${x.method === 'card' && tip ? html`<div class="muted" style="text-align:center;font-size:14px">${(tip / c.ticketCents * 100).toFixed(0)}% tip</div>` : ''}
      <button class="btn block" data-notip style="margin-top:14px">No tip — close table</button>
      <button class="btn ghost block" data-more style="margin-top:4px">Fix or view this table</button>`);
    ok.disabled = saving;
  };
  async function save(amount) {
    if (saving) return; saving = true; draw();
    const patch = x.method === 'cash' ? { extraTip: amount, tipPending: false } : { tip: amount, tipStatus: 'entered' };
    try { await store.patchPayment(c.id, p.id, patch, amount ? 'Tip entered' : 'No tip'); s.close(); flash(`Table ${c.table} closed${amount ? ' · tip ' + fmt(amount) : ''}`); }
    finally { saving = false; }
  }
  $('#skp', s.el).addEventListener('click', e => {
    const k = e.target.closest('[data-k]')?.dataset.k; if (!k) return;
    if (S.settings.haptics) haptic(6);
    if (k === 'ok') return save(tip);
    tip = k === 'bs' ? keypadBackspace(tip) : keypadAppend(tip, +k);
    draw();
  });
  s.body.addEventListener('click', e => {
    if (e.target.closest('[data-notip]')) return save(0);
    if (e.target.closest('[data-more]')) { s.close(); openCheckDetail(c.id); }
  });
  draw();
}

// ---------------- End of night ----------------
function endNight() {
  const s0 = S.summary; if (!s0) return;
  const waiting = pendingTips().length;
  const owed = s0.owed;
  const sheet = openSheet({
    title: 'End of night',
    body: html`<div class="stack">
      ${waiting ? html`<div class="banner warn">${icon('alert', 'sm')}<div><b>${waiting} table${waiting > 1 ? 's' : ''}</b> still need a tip entered. Close them first, or finish anyway.</div></div>` : ''}
      <div class="card pad">
        <div class="kv total"><span class="k">Your tips</span><span class="v num pos">${fmt(s0.totalTips)}</span></div>
        <div class="kv sub"><span class="k">Cash tips</span><span class="v num">${fmt(s0.cashTips)}</span></div>
        <div class="kv sub"><span class="k">Card tips</span><span class="v num">${fmt(s0.cardTips)}</span></div>
        <div class="kv total"><span class="k">${owed >= 0 ? 'Pay the restaurant' : 'Restaurant pays you'}</span><span class="v num">${fmt(Math.abs(owed))}</span></div>
        <div class="kv"><span class="k">Tables · checks</span><span class="v num">${s0.tables} · ${s0.checks}</span></div>
      </div>
      <p class="muted" style="font-size:13px;margin:0">"Pay the restaurant" is the cash bills they paid${s0.policy.cardTips === 'deduct' ? ', minus your card tips' : ''}. To compare with the restaurant's printout, use <b>More details → Shift → End Shift & Settle</b> instead.</p>
    </div>`,
    foot: html`<button class="btn primary lg block" data-finish>Finish night</button>`,
  });
  sheet.foot.addEventListener('click', async () => {
    if (waiting && !(await confirmDialog({ title: 'Tips not entered', message: `${waiting} table(s) have no tip entered. They will stay marked as missing a tip. Finish anyway?`, ok: 'Finish anyway' }))) return;
    if (store.onBreak()) await store.toggleBreak();
    await store.closeShift({
      policy: S.shift.policy, adjustments: [], reported: {}, countedCash: null, countedAfter: null,
      paidToRestaurant: owed > 0 ? owed : 0, receivedFromRestaurant: owed < 0 ? -owed : 0,
      cardTipsCredited: s0.policy.cardTips === 'deduct' ? s0.cardTipsOutstanding : 0, cardTipsVia: 'settlement',
      cardTipsCash: s0.policy.cardTips === 'separate' ? s0.cardTipsOutstanding : 0,
      notes: 'Closed from simple mode (end of night)', photoIds: [], simple: true,
    });
    sheet.close(); flash('Night finished and saved. Great work!');
  });
}
