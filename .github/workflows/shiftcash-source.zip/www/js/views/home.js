// ShiftCash — Home dashboard (live figures for the active shift).
import { html, icon, fmtTime, fmtDur } from '../ui.js';
import { fmt } from '../money.js';
import { checkState, summarizeShift } from '../ledger.js';
import * as db from '../db.js';
import { S, onBreak, toggleBreak } from '../store.js';
import { openEntry } from './entry.js';
import { openStartShift } from './shift.js';
import { openCheckDetail, txRow } from './tables.js';
import { pendingTips, openTipQueue } from './tips.js';

let moreOpen = false;
let earlierToday = { tips: 0, n: 0 };

/** Tips from other shifts that started today (e.g. a lunch shift closed before dinner). */
export async function load() {
  const d = new Date(); const start = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const shifts = (await db.all('shifts')).filter(x => x.startedAt >= start && x.status === 'closed' && x.id !== S.shift?.id);
  let tips = 0;
  for (const sh of shifts) {
    const [checks, moves, payouts] = await Promise.all([db.byIndex('checks', 'shiftId', sh.id), db.byIndex('moves', 'shiftId', sh.id), db.byIndex('payouts', 'shiftId', sh.id)]);
    tips += summarizeShift({ shift: sh, checks, moves, payouts }).totalTips;
  }
  earlierToday = { tips, n: shifts.length };
}

export function title() {
  return { title: 'ShiftCash', sub: S.settings.restaurantName ? `${S.settings.restaurantName} · Every Table. Every Dollar.` : 'Every Table. Every Dollar.', logo: true };
}

export function render() {
  const sh = S.shift, s = S.summary;
  const backupDue = S.settings.backupReminderDays > 0 && Date.now() - (S.settings.lastBackupAt || 0) > S.settings.backupReminderDays * 86400000;
  if (!sh) {
    return html`
      ${backupReminder(backupDue)}
      <div class="card pad stack" style="text-align:center;padding:28px 18px">
        <div style="display:grid;place-items:center">${icon('shift', 'lg')}</div>
        <div style="font-size:20px;font-weight:700">No active shift</div>
        <div class="muted">Start a shift to log tables, tips and cash.</div>
        <button class="btn primary lg block" data-act="start">${icon('play', 'sm')} Start Shift</button>
      </div>
      <div class="section-title">Quick guide</div>
      <div class="list">
        ${[['play', 'Start shift', 'Enter starting cash (your own money).'], ['plus', 'Log each table', 'Table #, ticket, cash or card, tip — about 5 seconds.'], ['reports', 'Track in real time', 'Tips, sales, cash on hand and what you owe.'], ['scale', 'End & settle', 'Compare with the restaurant checkout report.']].map(([i, t, d]) => html`
          <div class="li">${icon(i)}<div class="grow"><div class="t">${t}</div><div class="s">${d}</div></div></div>`)}
      </div>`;
  }
  const paused = onBreak();
  const open = S.checks.filter(c => !c.voided && checkState(c).balance > 0);
  const recent = [...S.checks].reverse().slice(0, 5);
  const discrepancies = s.unconfirmedExcess + s.overChange;
  return html`
    ${backupReminder(backupDue)}
    <div class="card pad">
      <div class="row between">
        <div class="row"><span class="dot ${paused ? 'paused' : ''}"></span><b style="font-size:16px">${paused ? 'On Break' : 'Active Shift'}</b>
          <span class="pill">${sh.segment === 'lunch' ? 'Lunch' : 'Dinner'}</span></div>
        <b class="num" style="font-size:16px">${fmtDur(s.workedMs)}</b>
      </div>
      <div class="row between muted" style="font-size:13px;margin-top:6px">
        <span>Started ${fmtTime(sh.startedAt)}</span>
        <span>${sh.breaks.length ? `Breaks ${fmtDur(s.breakMs)}` : 'No breaks'}</span>
      </div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn sm" data-act="break">${icon(paused ? 'play' : 'coffee', 'sm')} ${paused ? 'End Break' : 'Start Break'}</button>
        <a class="btn sm" href="#shift">${icon('scale', 'sm')} Cash & Settle</a>
      </div>
    </div>

    <div class="hero" style="margin-top:12px">
      <div class="label">Total Tips Earned Today</div>
      <div class="big num">${fmt(s.totalTips + earlierToday.tips)}</div>
      <div class="split"><span>Received ${fmt(s.tipsReceived)}</span><span>Outstanding ${fmt(s.cardTipsOutstanding)}</span><span>Net ${fmt(s.netTips)}</span></div>
      ${earlierToday.n ? html`<div class="split" style="margin-top:2px;opacity:.75">Includes ${fmt(earlierToday.tips)} from ${earlierToday.n} earlier shift${earlierToday.n > 1 ? 's' : ''} today</div>` : ''}
    </div>

    <div class="grid2" style="margin-top:10px">
      ${stat('cash', 'Cash Tips', s.cashTips)}
      ${stat('card', 'Card Tips', s.cardTips)}
      ${stat('wallet', 'Expected Cash', s.expectedCash, 'accent')}
      ${stat('scale', s.owed >= 0 ? 'Owed to Restaurant' : 'Restaurant Owes You', Math.abs(s.owed))}
    </div>
    <div class="grid3" style="margin-top:10px">
      ${stat(null, 'Ticket Sales', s.totalSales, '', true)}
      ${stat(null, 'Cash Sales', s.cashSales, '', true)}
      ${stat(null, 'Card Sales', s.cardSales, '', true)}
    </div>
    <div class="grid3" style="margin-top:10px">
      <div class="stat"><div class="k">${icon('table', 'xs')} Tables</div><div class="v num">${s.tables}</div></div>
      <div class="stat"><div class="k">${icon('receipt', 'xs')} Checks</div><div class="v num">${s.checks}</div></div>
      <div class="stat"><div class="k">${icon('percent', 'xs')} Avg Tip</div><div class="v num">${s.avgTipPct.toFixed(1)}%</div></div>
    </div>

    ${(sh.counts || []).length ? (() => { const c = sh.counts[sh.counts.length - 1]; const diff = c.counted - c.expected; return html`<div class="card pad" style="margin-top:10px"><div class="row between"><span class="muted">Last cash count (${fmtTime(c.at)})</span><b class="num">${fmt(c.counted)}</b></div>
      <div class="row between" style="font-size:13px;margin-top:2px"><span class="muted">vs expected then</span><span class="num ${diff ? (diff > 0 ? 'warn' : 'neg') : 'pos'}">${diff ? (diff > 0 ? '+' : '−') + fmt(Math.abs(diff)) : 'Balanced'}</span></div></div>`; })() : ''}
    ${discrepancies || s.cardTipsOutstanding || s.outstanding ? html`
      <div class="stack" style="margin-top:10px">
        ${s.unconfirmedExcess ? html`<div class="banner warn">${icon('alert', 'sm')}<div><b>${fmt(s.unconfirmedExcess)}</b> unconfirmed excess cash — not counted as tips.</div></div>` : ''}
        ${s.overChange ? html`<div class="banner neg">${icon('alert', 'sm')}<div>Possible cash shortage: <b>${fmt(s.overChange)}</b> extra change returned this shift.</div></div>` : ''}

      </div>` : ''}

    <details class="more card" style="margin-top:10px" ${moreOpen ? 'open' : ''} data-more>
      <summary class="row between pad" style="padding:13px 16px"><b>More figures</b>${icon('chevd', 'sm chev-rot')}</summary>
      <div style="padding:0 16px 10px">
        ${kv('Tips actually received', fmt(s.tipsReceived))}
        ${kv('Unpaid card tips', fmt(s.cardTipsOutstanding), s.cardTipsOutstanding ? 'warn' : '')}
        ${kv('Tip-outs', fmt(s.tipouts))}
        ${kv('Net tips after tip-outs', fmt(s.netTips))}
        ${kv('Rounding adjustments', (s.roundingAdj > 0 ? '+' : s.roundingAdj < 0 ? '−' : '') + fmt(Math.abs(s.roundingAdj)))}
        ${kv('Cash discrepancies', fmt(discrepancies), discrepancies ? 'warn' : '')}
        ${kv('Unpaid check balances', fmt(s.outstanding), s.outstanding ? 'warn' : '')}
        ${kv('Hours worked', fmtDur(s.workedMs))}
        ${kv('Tips per hour', fmt(s.tipsPerHour))}
        ${s.wage ? kv('Estimated wages', fmt(s.wage)) : ''}
        ${kv('Visits · payments', `${s.visits} · ${s.payments}`)}
        ${kv('Starting personal cash', fmt(s.startingCash))}
        ${kv('Average ticket', fmt(s.avgTicket))}
      </div>
    </details>

    ${(() => { const n = pendingTips().length; return html`<div class="btnrow" style="margin-top:14px">
      <button class="btn primary lg" data-act="new">${icon('plus', 'sm')} Log Table</button>
      ${n ? html`<button class="btn lg" data-act="tips" style="border-color:var(--brand);color:var(--brand);white-space:nowrap;padding:0 12px">Enter tips <span class="pill ok" style="margin-left:2px">${n}</span></button>` : ''}
    </div>`; })()}

    ${open.length ? html`
      <div class="section-title">Open balances</div>
      <div class="list">${open.map(c => html`<button class="li" data-check="${c.id}"><span class="tbl-badge">${c.table}</span>
        <div class="grow"><div class="t">Balance ${fmt(checkState(c).balance)}</div><div class="s">Ticket ${fmt(c.ticketCents)} · ${fmtTime(c.createdAt)}</div></div>
        <span class="btn sm" data-pay-check="${c.id}">Add payment</span></button>`)}</div>` : ''}

    <div class="section-title">Recent <a href="#tables" style="color:var(--brand);text-transform:none;letter-spacing:0;font-size:13.5px;text-decoration:none">See all</a></div>
    ${recent.length ? html`<div class="list">${recent.map(c => txRow(c))}</div>` : html`<div class="card empty">${icon('receipt')}<div>No tables yet this shift.</div></div>`}`;
}

function stat(ic, k, cents, cls = '', small = false) {
  return html`<div class="stat ${cls}"><div class="k">${ic ? icon(ic, 'xs') : ''}${k}</div><div class="v num ${small ? 'sm' : ''}">${fmt(cents)}</div></div>`;
}
function kv(k, v, cls = '') { return html`<div class="kv"><span class="k">${k}</span><span class="v num ${cls}">${v}</span></div>`; }
function backupReminder(due) {
  return due ? html`<a class="banner info" href="#setup" style="text-decoration:none;margin-bottom:12px">${icon('download', 'sm')}<div><b>Backup reminder.</b> Your data lives only on this device — export a backup.</div></a>` : '';
}

export function mount(root) {
  root.addEventListener('click', async e => {
    const t = e.target;
    const pay = t.closest('[data-pay-check]');
    if (pay) { e.stopPropagation(); const c = S.checks.find(x => x.id === pay.dataset.payCheck); return openEntry({ check: c }); }
    const ch = t.closest('[data-check]'); if (ch) return openCheckDetail(ch.dataset.check);
    const act = t.closest('[data-act]')?.dataset.act;
    if (act === 'new') openEntry();
    if (act === 'tips') openTipQueue();
    if (act === 'start') openStartShift();
    if (act === 'break') await toggleBreak();
    if (t.closest('[data-more] > summary')) setTimeout(() => { moreOpen = root.querySelector('[data-more]')?.open; }, 0);
  });
}
