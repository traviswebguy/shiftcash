// ShiftCash — Reports & analytics (locally computed, locally rendered charts).
import { html, raw, icon, openSheet, flash, promptDialog, fmtDate, fmtTime, fmtDur, dayKey, download, esc } from '../ui.js';
import { fmt, fmtSigned } from '../money.js';
import { summarizeShift, finalSummary, aggregate, PAYOUT_VIA, describeDiff, taxYear, w2Compare } from '../ledger.js';
import { toCSV } from '../schema.js';
import { saveFile } from '../native.js';
import * as store from '../store.js';
import { S } from '../store.js';
import * as db from '../db.js';
import { moneyInput, readMoney } from './forms.js';
import { editShiftTimes } from './shift.js';
import { exportCSV } from './settings.js';

const R = { period: 'week', offset: 0, from: '', to: '' };
let data = null;

export function title() { return { title: 'Reports', sub: 'Earnings & trends' }; }

function bounds() {
  const now = new Date();
  let a, b;
  if (R.period === 'custom') {
    a = R.from ? new Date(R.from + 'T00:00') : new Date(now.getFullYear(), now.getMonth(), 1);
    b = R.to ? new Date(R.to + 'T00:00') : new Date(now.getFullYear(), now.getMonth(), now.getDate());
    b.setDate(b.getDate() + 1);
  } else if (R.period === 'day') {
    a = new Date(now.getFullYear(), now.getMonth(), now.getDate() + R.offset); b = new Date(a); b.setDate(b.getDate() + 1);
  } else if (R.period === 'week') {
    const dow = (now.getDay() + 6) % 7; // Monday start
    a = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dow + R.offset * 7); b = new Date(a); b.setDate(b.getDate() + 7);
  } else if (R.period === 'month') {
    a = new Date(now.getFullYear(), now.getMonth() + R.offset, 1); b = new Date(a.getFullYear(), a.getMonth() + 1, 1);
  } else {
    a = new Date(now.getFullYear() + R.offset, 0, 1); b = new Date(a.getFullYear() + 1, 0, 1);
  }
  return [a.getTime(), b.getTime()];
}

async function summaries(shifts) {
  const [checks, moves, payouts] = await Promise.all([db.all('checks'), db.all('moves'), db.all('payouts')]);
  const by = (arr, k = 'shiftId') => arr.reduce((m, x) => ((m[x[k]] ||= []).push(x), m), {});
  const C = by(checks), M = by(moves), P = by(payouts);
  return shifts.map(sh => {
    const s = summarizeShift({ shift: sh, checks: C[sh.id] || [], moves: M[sh.id] || [], payouts: P[sh.id] || [] });
    if (sh.settlement) s.final = finalSummary(s, sh.settlement);
    s.shift = sh; return s;
  });
}

export async function load() {
  const [a, b] = bounds();
  const shifts = await db.all('shifts');
  const all = await summaries(shifts);
  const inRange = all.filter(s => s.shift.startedAt >= a && s.shift.startedAt < b).sort((x, y) => x.shift.startedAt - y.shift.startedAt);
  const owing = all.filter(s => s.shift.status === 'closed' && s.cardTipsOutstanding > 0).sort((x, y) => y.shift.startedAt - x.shift.startedAt);
  // current week for goal
  const now = new Date(); const dow = (now.getDay() + 6) % 7;
  const wk = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dow).getTime();
  const weekTips = all.filter(s => s.shift.startedAt >= wk).reduce((t, s) => t + s.netTips, 0);
  data = { a, b, list: inRange, agg: aggregate(inRange), owing, weekTips, total: all.length };
}

function series() {
  const { a, b, list } = data;
  const buckets = [];
  if (R.period === 'year' || (b - a) > 62 * 86400000) {
    const d = new Date(a);
    while (d.getTime() < b) { buckets.push({ key: d.getFullYear() + '-' + d.getMonth(), label: d.toLocaleDateString([], { month: 'short' }), v: 0 }); d.setMonth(d.getMonth() + 1); }
    for (const s of list) { const d2 = new Date(s.shift.startedAt); const k = buckets.find(x => x.key === d2.getFullYear() + '-' + d2.getMonth()); if (k) k.v += s.netTips; }
  } else if (R.period === 'day') {
    for (const s of list) buckets.push({ label: fmtTime(s.shift.startedAt), v: s.netTips });
  } else {
    for (let t = a; t < b; t += 86400000) { const d = new Date(t); buckets.push({ key: dayKey(t), label: (b - a) <= 8 * 86400000 ? d.toLocaleDateString([], { weekday: 'short' }) : String(d.getDate()), v: 0 }); }
    for (const s of list) { const k = buckets.find(x => x.key === dayKey(s.shift.startedAt)); if (k) k.v += s.netTips; }
  }
  return buckets;
}

function chart(buckets) {
  if (!buckets.length) return '';
  const W = 340, H = 170, top = 20, bottom = 22, left = 4;
  const max = Math.max(1, ...buckets.map(b => b.v));
  const bw = (W - left * 2) / buckets.length;
  const best = buckets.reduce((m, b, i) => b.v > buckets[m].v ? i : m, 0);
  const showVals = buckets.length <= 8;
  const lblEvery = buckets.length > 16 ? Math.ceil(buckets.length / 10) : 1;
  let svg = `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Net tips chart">`;
  for (let g = 1; g <= 3; g++) { const y = top + (H - top - bottom) * (1 - g / 3); svg += `<line class="grid" x1="0" x2="${W}" y1="${y}" y2="${y}"/>`; }
  buckets.forEach((b, i) => {
    const h = Math.max(b.v > 0 ? 2 : 0, (H - top - bottom) * Math.max(0, b.v) / max);
    const x = left + i * bw + bw * 0.18, w = bw * 0.64, y = H - bottom - h;
    svg += `<rect class="bar ${i === best && b.v > 0 ? 'best' : ''}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="3"><title>${esc(b.label)}: ${esc(fmt(b.v))}</title></rect>`;
    if (i % lblEvery === 0) svg += `<text x="${(x + w / 2).toFixed(1)}" y="${H - 6}" text-anchor="middle">${esc(b.label)}</text>`;
    if (showVals && b.v) svg += `<text class="val" x="${(x + w / 2).toFixed(1)}" y="${(y - 5).toFixed(1)}" text-anchor="middle">${esc(fmt(b.v).replace(/\.00$/, ''))}</text>`;
  });
  return raw(svg + '</svg>');
}

function rangeLabel() {
  const { a, b } = data;
  const end = new Date(b - 1);
  if (R.period === 'day') return fmtDate(a);
  if (R.period === 'month') return new Date(a).toLocaleDateString([], { month: 'long', year: 'numeric' });
  if (R.period === 'year') return String(new Date(a).getFullYear());
  return `${fmtDate(a)} – ${fmtDate(end)}`;
}

export function render() {
  if (!data) return html`<div class="empty">Loading…</div>`;
  const g = data.agg, buckets = series();
  const weekday = {};
  for (const s of data.list) { const k = new Date(s.shift.startedAt).toLocaleDateString([], { weekday: 'long' }); (weekday[k] ||= { t: 0, n: 0, h: 0 }); weekday[k].t += s.netTips; weekday[k].n++; weekday[k].h += s.hours; }
  const bestDays = Object.entries(weekday).map(([k, v]) => ({ k, avg: Math.round(v.t / v.n), ph: v.h ? Math.round(v.t / v.h) : 0 })).sort((x, y) => y.avg - x.avg).slice(0, 3);
  const unresolved = data.list.reduce((n, s) => n + (s.final ? s.final.issues.length : 0), 0);
  const goal = S.settings.weeklyGoal | 0;
  const kv = (k, v, cls = '') => html`<div class="kv"><span class="k">${k}</span><span class="v num ${cls}">${v}</span></div>`;
  return html`
    <div class="print-only"><h2 style="margin:0">ShiftCash report — ${rangeLabel()}</h2><p>${S.settings.restaurantName || ''} · Generated ${new Date().toLocaleString()}</p></div>
    <div class="seg no-print">${[['day', 'Day'], ['week', 'Week'], ['month', 'Month'], ['year', 'Year'], ['custom', 'Custom']].map(([k, v]) => html`<button class="${R.period === k ? 'on' : ''}" data-period="${k}">${v}</button>`)}</div>
    ${R.period === 'custom' ? html`<div class="grid2 no-print" style="margin-top:10px"><label class="field"><span>From</span><input class="input" type="date" data-from value="${R.from}"></label><label class="field"><span>To</span><input class="input" type="date" data-to value="${R.to}"></label></div>`
      : html`<div class="row between no-print" style="margin-top:10px"><button class="iconbtn" data-step="-1" aria-label="Previous">${icon('back')}</button><b>${rangeLabel()}</b><button class="iconbtn" data-step="1" aria-label="Next" ${R.offset >= 0 ? 'disabled style="opacity:.3"' : ''}>${icon('chev')}</button></div>`}

    <div class="card pad" style="margin-top:8px">
      <div class="row between"><span class="muted">Net tips</span><b class="num" style="font-size:28px">${fmt(g.netTips)}</b></div>
      <div class="row between muted" style="font-size:13px"><span>${g.shifts} shift${g.shifts === 1 ? '' : 's'} · ${g.hours.toFixed(1)} h</span><span>${fmt(g.tipsPerHour)}/h tips · ${fmt(g.earningsPerHour)}/h with wages</span></div>
      <div style="margin-top:10px">${data.list.length ? chart(buckets) : html`<div class="empty" style="padding:20px">${icon('reports')}<div>No shifts in this period.</div></div>`}</div>
    </div>

    ${goal ? html`<div class="card pad" style="margin-top:10px"><div class="row between"><span class="row">${icon('target', 'sm')} <b>Weekly goal</b></span><span class="num">${fmt(data.weekTips)} / ${fmt(goal)}</span></div>
      <div class="goal" style="margin-top:8px"><div style="width:${Math.min(100, Math.round(data.weekTips / goal * 100))}%"></div></div></div>` : ''}

    <div class="section-title">Tips</div>
    <div class="card pad">
      ${kv('Gross tips', fmt(g.totalTips))}${kv('Cash tips', fmt(g.cashTips))}${kv('Card tips', fmt(g.cardTips))}
      ${kv('Tip-outs', g.tipouts ? '−' + fmt(g.tipouts) : fmt(0))}${kv('Net tips', fmt(g.netTips), 'pos')}
      ${kv('Tips received', fmt(g.tipsReceived))}${kv('Card tips outstanding', fmt(g.cardTipsOutstanding), g.cardTipsOutstanding ? 'warn' : '')}
      ${kv('Average tip %', g.avgTipPct.toFixed(1) + '%')}
    </div>
    <div class="section-title">Earnings</div>
    <div class="card pad">
      ${kv('Hours worked', g.hours.toFixed(2))}${kv('Tips per hour', fmt(g.tipsPerHour))}${kv('Estimated wages', fmt(g.wage))}
      ${kv('Tips + wages', fmt(g.netTips + g.wage), 'pos')}${kv('Hourly earnings (with wages)', fmt(g.earningsPerHour))}
    </div>
    <div class="section-title">Sales</div>
    <div class="card pad">
      ${kv('Total sales', fmt(g.totalSales))}${kv('Cash sales', fmt(g.cashSales))}${kv('Card sales', fmt(g.cardSales))}
      ${kv('Average ticket', fmt(g.avgTicket))}${kv('Tables · checks', `${g.tables} · ${g.checks}`)}
    </div>
    <div class="section-title">Lunch vs dinner</div>
    <div class="grid2">
      <div class="stat"><div class="k">Lunch tips</div><div class="v num">${fmt(g.lunch.tips)}</div><div class="muted" style="font-size:12px">${g.lunch.checks} checks · ${fmt(g.lunch.sales)} sales</div></div>
      <div class="stat"><div class="k">Dinner tips</div><div class="v num">${fmt(g.dinner.tips)}</div><div class="muted" style="font-size:12px">${g.dinner.checks} checks · ${fmt(g.dinner.sales)} sales</div></div>
    </div>
    ${bestDays.length ? html`<div class="section-title">Best-performing days</div><div class="list">${bestDays.map((d, i) => html`<div class="li"><b style="width:20px">${i + 1}</b><div class="grow t">${d.k}</div><span class="amt num">${fmt(d.avg)} avg<br><small class="muted">${fmt(d.ph)}/h</small></span></div>`)}</div>` : ''}
    <div class="section-title">Cash accuracy</div>
    <div class="card pad">
      ${kv('Rounding differences', fmtSigned(g.roundingAdj))}
      ${kv('Unconfirmed excess cash', fmt(g.unconfirmedExcess), g.unconfirmedExcess ? 'warn' : '')}
      ${kv('Excess change returned', fmt(g.overChange), g.overChange ? 'neg' : '')}
      ${kv('Counted cash over/short', fmtSigned(g.cashDiscrepancy), g.cashDiscrepancy ? (g.cashDiscrepancy > 0 ? 'warn' : 'neg') : '')}
      ${kv('Unresolved discrepancies', String(unresolved), unresolved ? 'warn' : '')}
    </div>

    ${data.owing.length ? html`<div class="section-title">Outstanding card tips (all time)</div>
      <div class="list">${data.owing.map(s => html`<div class="li"><div class="grow"><div class="t">${fmtDate(s.shift.startedAt)}</div><div class="s">Earned ${fmt(s.cardTips)} · paid ${fmt(s.cardTipsPaid)}</div></div>
        <span class="amt num warn">${fmt(s.cardTipsOutstanding)}</span><button class="btn sm no-print" data-markpaid="${s.shift.id}" data-amt="${s.cardTipsOutstanding}">Mark paid</button></div>`)}</div>` : ''}

    <div class="section-title">Shifts in this period</div>
    ${data.list.length ? html`<div class="list">${[...data.list].reverse().map(s => html`<button class="li" data-shift="${s.shift.id}">
      <div class="grow"><div class="t">${fmtDate(s.shift.startedAt)} ${s.shift.status === 'active' ? html`<span class="pill ok">Active</span>` : ''}</div>
        <div class="s">${fmtTime(s.shift.startedAt)} – ${s.shift.endedAt ? fmtTime(s.shift.endedAt) : 'now'} · ${fmtDur(s.workedMs)} · ${s.checks} checks${s.final?.issues.length ? ' · ' + s.final.issues.length + ' issue(s)' : ''}</div></div>
      <span class="amt num pos">${fmt(s.netTips)}</span><span class="chev no-print">${icon('chev', 'sm')}</span></button>`)}</div>` : html`<div class="card pad muted">No shifts.</div>`}

    <div class="btnrow no-print" style="margin-top:16px">
      <button class="btn" data-act="print">${icon('print', 'sm')} Print / PDF</button>
      <button class="btn" data-act="csv">${icon('download', 'sm')} CSV</button>
    </div>
    <button class="btn block no-print" data-act="taxes" style="margin-top:10px">${icon('file', 'sm')} Tip Records & Taxes</button>
    <button class="btn ghost block no-print" data-act="goal" style="margin-top:6px">${icon('target', 'sm')} ${goal ? 'Change' : 'Set'} weekly earnings goal</button>`;
}

export function mount(root, rerender) {
  const reload = async () => { await load(); rerender(); };
  root.addEventListener('click', async e => {
    const t = e.target;
    const p = t.closest('[data-period]'); if (p) { R.period = p.dataset.period; R.offset = 0; return reload(); }
    const st = t.closest('[data-step]'); if (st && !st.disabled) { R.offset = Math.min(0, R.offset + +st.dataset.step); return reload(); }
    const sh = t.closest('[data-shift]'); if (sh) return openShiftSummary(sh.dataset.shift);
    const mp = t.closest('[data-markpaid]'); if (mp) return markPaid(mp.dataset.markpaid, +mp.dataset.amt, reload);
    switch (t.closest('[data-act]')?.dataset.act) {
      case 'print': window.print(); break;
      case 'taxes': openTaxRecords(new Date().getFullYear()); break;
      case 'csv': await exportCSV({ from: data.a, to: data.b }); break;
      case 'goal': {
        const v = await promptDialog({ title: 'Weekly earnings goal', label: 'Net tips goal per week (0 to turn off)', value: S.settings.weeklyGoal ? (S.settings.weeklyGoal / 100).toFixed(2) : '', ok: 'Save' });
        if (v === null) return; const c = Math.round(parseFloat(v.replace(/[$,]/g, '')) * 100);
        if (!Number.isFinite(c) || c < 0) return flash('Enter a valid amount.');
        await store.setSetting('weeklyGoal', c); return reload();
      }
    }
  });
  root.addEventListener('change', e => {
    if (e.target.matches('[data-from]')) { R.from = e.target.value; reload(); }
    if (e.target.matches('[data-to]')) { R.to = e.target.value; reload(); }
  });
}

function markPaid(shiftId, amount, done) {
  let via = 'payroll';
  const s = openSheet({
    title: 'Card tips paid', body: html`<div class="stack">${moneyInput('amount', 'Amount paid', amount)}
      <label class="field"><span>Paid how</span><select class="input" data-via>${Object.entries(PAYOUT_VIA).filter(([k]) => k !== 'settlement').map(([k, v]) => html`<option value="${k}" ${k === via ? 'selected' : ''}>${v}</option>`)}</select></label>
      <label class="field"><span>Note</span><input class="input" data-note maxlength="100" placeholder="e.g. paycheck 11/28"></label></div>`,
    foot: html`<button class="btn primary block">Save</button>`,
  });
  s.foot.addEventListener('click', async () => {
    const a = readMoney(s.body, 'amount');
    if (!a || Number.isNaN(a) || a <= 0) return flash('Enter an amount.');
    await store.addPayout({ shiftId, amount: a, via: s.body.querySelector('[data-via]').value, note: s.body.querySelector('[data-note]').value.trim().slice(0, 100), inApron: false });
    s.close(); flash('Payout recorded'); done();
  });
}

export async function openShiftSummary(id) {
  const { shift, summary: sm, incidents } = await store.summaryFor(id);
  if (!shift) return;
  const f = sm.final;
  const kv = (k, v, cls = '') => html`<div class="kv"><span class="k">${k}</span><span class="v num ${cls}">${v}</span></div>`;
  const s = openSheet({
    title: 'Shift ' + fmtDate(shift.startedAt), sub: `${fmtTime(shift.startedAt)} – ${shift.endedAt ? fmtTime(shift.endedAt) : 'now'} · ${fmtDur(sm.workedMs)}`,
    body: html`<div class="stack">
      <div class="card pad">
        ${kv('Total tips', fmt(sm.totalTips), 'pos')}${kv('Cash · card tips', `${fmt(sm.cashTips)} · ${fmt(sm.cardTips)}`)}
        ${kv('Tip-outs', fmt(sm.tipouts))}${kv('Net tips', fmt(sm.netTips))}
        ${kv('Sales (cash · card)', `${fmt(sm.cashSales)} · ${fmt(sm.cardSales)}`)}
        ${kv('Tables · checks', `${sm.tables} · ${sm.checks}`)}${kv('Avg tip %', sm.avgTipPct.toFixed(1) + '%')}
        ${kv('Expected owed to restaurant', fmt(sm.owed))}${kv('Expected physical cash', fmt(sm.expectedCash))}
        ${kv('Card tips outstanding', fmt(sm.cardTipsOutstanding), sm.cardTipsOutstanding ? 'warn' : '')}
      </div>
      ${f ? html`<div class="section-title">Settlement</div><div class="card pad">
        ${kv('Actually paid', f.actualPaid === null ? '—' : fmt(f.actualPaid))}${kv('Counted cash difference', f.cashDiscrepancy === null ? '—' : fmtSigned(f.cashDiscrepancy))}
        ${kv('Take-home cash', f.takeHome === null ? '—' : fmt(f.takeHome))}
        ${f.rows.length ? html`<table class="cmp" style="margin-top:8px"><thead><tr><th></th><th>Yours</th><th>Reported</th><th>Diff</th></tr></thead><tbody>
          ${f.rows.map(r => html`<tr><td>${r.label}</td><td>${fmt(r.tracked)}</td><td>${fmt(r.reported)}</td><td class="${r.diff ? 'warn' : 'pos'}">${r.diff ? fmtSigned(r.diff) : '✓'}</td></tr>`)}</tbody></table>` : ''}
        ${shift.settlement.notes ? html`<p style="margin:10px 0 0;font-size:14px">${shift.settlement.notes}</p>` : ''}</div>
        ${f.issues.length ? html`<div class="list">${f.issues.map(i => html`<div class="li">${icon('alert', 'sm')}<div class="grow"><div class="t">${i.label}</div><div class="s">${i.note}</div></div><span class="amt num">${fmtSigned(i.cents)}</span></div>`)}</div>` : ''}` : ''}
      ${incidents.length ? html`<div class="section-title">Incidents</div><div class="list">${incidents.map(i => html`<div class="li">${icon('flag', 'sm')}<div class="grow"><div class="t">${store.INCIDENT_TYPES[i.type]}</div><div class="s">${i.description}</div></div><span class="pill ${i.resolved ? 'ok' : 'warn'}">${i.resolved ? 'Resolved' : 'Open'}</span></div>`)}</div>` : ''}
      ${shift.status === 'closed' ? html`<div class="btnrow"><button class="btn sm" data-a="times">${icon('edit', 'sm')} Correct times</button><button class="btn sm" data-a="reopen">${icon('undo', 'sm')} Reopen shift</button></div>` : ''}
    </div>`,
  });
  s.body.addEventListener('click', async e => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'times') { s.close(); editShiftTimes(shift); }
    if (a === 'reopen') {
      if (S.shift) return flash('End the current shift first.');
      const reason = await promptDialog({ title: 'Reopen shift', label: 'Reason (the previous settlement is kept in history)', ok: 'Reopen' });
      if (!reason) return;
      await store.reopenShift(id, reason); s.close(); flash('Shift reopened'); location.hash = '#shift';
    }
  });
}


// ---------------- Tip Records & Taxes ----------------
export async function openTaxRecords(year) {
  const shifts = await db.all('shifts');
  const all = await summaries(shifts);
  const taxes = await db.all('taxes');
  const reported = taxes.filter(t => t.kind === 'reported');
  const w2 = taxes.find(t => t.id === 'w2_' + year) || {};
  const yr = taxes.find(t => t.id === 'yr_' + year) || {};
  const y = taxYear(all, reported, year);
  const years = [...new Set(all.map(s => new Date(s.shift.startedAt).getFullYear()).concat([new Date().getFullYear()]))].sort((a, b) => b - a);
  const mname = m => new Date(year, m - 1, 1).toLocaleDateString([], { month: 'short' });
  const w2rows = w2Compare(y.total, w2);
  const s = openSheet({
    full: true, title: 'Tip Records & Taxes', sub: String(year),
    body: html`<div class="stack">
      <div class="chips">${years.map(v => html`<button class="chip ${v === year ? 'on' : ''}" data-year="${v}">${v}</button>`)}</div>
      <div class="card pad">
        <div class="kv"><span class="k">Cash tips</span><span class="v num">${fmt(y.total.cashTips)}</span></div>
        <div class="kv"><span class="k">Card tips</span><span class="v num">${fmt(y.total.cardTips)}</span></div>
        <div class="kv"><span class="k">Tip-outs paid</span><span class="v num">${fmt(y.total.tipouts)}</span></div>
        <div class="kv total"><span class="k">Net retained tips</span><span class="v num">${fmt(y.total.netTips)}</span></div>
        <div class="kv"><span class="k">Tips received</span><span class="v num">${fmt(y.total.received)}</span></div>
        <div class="kv"><span class="k">Card tips still outstanding</span><span class="v num ${y.total.outstanding ? 'warn' : ''}">${fmt(y.total.outstanding)}</span></div>
        <div class="kv"><span class="k">Reported to employer</span><span class="v num">${fmt(y.total.reported)}</span></div>
        <div class="kv"><span class="k">Recorded but not reported</span><span class="v num ${y.total.unreported ? 'warn' : 'pos'}">${fmtSigned(y.total.unreported)}</span></div>
        <div class="kv"><span class="k">Hours worked</span><span class="v num">${y.total.hours.toFixed(1)}</span></div>
      </div>
      ${y.differs ? html`<div class="banner warn">${icon('alert', 'sm')}<div>Your recorded tips and the tips you reported differ in at least one month. Do not assume the restaurant reported your cash tips for you.</div></div>` : ''}
      <div class="section-title">By month <span class="muted" style="text-transform:none;letter-spacing:0;font-weight:500">tap to enter reported tips</span></div>
      <div class="card pad" style="overflow-x:auto"><table class="cmp"><thead><tr><th>Month</th><th>Net tips</th><th>Reported</th><th>Diff</th></tr></thead><tbody>
        ${y.months.filter(m => m.shifts || m.reported).map(m => html`<tr data-month="${m.period}" style="cursor:pointer"><td>${mname(m.month)}<div class="muted" style="font-size:11px">${m.shifts} shifts · ${m.hours.toFixed(1)} h</div></td><td>${fmt(m.netTips)}</td><td>${fmt(m.reported)}</td><td class="${m.unreported ? 'warn' : 'pos'}">${m.unreported ? fmtSigned(m.unreported) : '✓'}</td></tr>`)}
        ${y.months.some(m => m.shifts || m.reported) ? '' : html`<tr><td colspan="4" class="muted" style="text-align:center;padding:14px">No shifts recorded in ${year}.</td></tr>`}
      </tbody></table></div>
      <div class="section-title">W-2 comparison (optional) <button data-act="w2">${w2.ssTips != null ? 'Edit' : 'Enter W-2'}</button></div>
      ${w2rows.length ? html`<div class="card pad">${w2rows.map(r => html`<div class="kv"><span class="k" style="font-size:13.5px">${r.label}</span><span class="v num ${r.diff ? 'warn' : 'pos'}">${r.diff ? fmtSigned(r.diff) : 'Matches'}</span></div>`)}</div>` : html`<div class="card pad muted" style="font-size:13.5px">Enter box 1, 7 and 8 from your W-2 to compare them with your records.</div>`}
      <div class="section-title">Qualified tip deduction notes <button data-act="qtd">Edit</button></div>
      <div class="card pad" style="font-size:13.5px">${yr.notes ? html`<div style="white-space:pre-wrap">${yr.notes}</div>` : html`<span class="muted">Record this year's rules (limits, eligibility, sources) here. ShiftCash does not decide eligibility or calculate an official deduction.</span>`}
        <div class="kv" style="margin-top:8px"><span class="k">Reported tips this year (informational)</span><span class="v num">${fmt(y.total.reported)}</span></div></div>
      <div class="banner info">${icon('shield', 'sm')}<div>ShiftCash is a personal recordkeeping tool, not tax advice. Tax laws change and federal and state rules differ — confirm with a tax professional.</div></div>
      <div class="btnrow"><button class="btn" data-act="csv">${icon('download', 'sm')} Annual CSV</button><button class="btn" data-act="print">${icon('print', 'sm')} Print</button></div>
    </div>`,
  });
  const reopen = () => { s.close(); setTimeout(() => openTaxRecords(year), 280); };
  s.body.addEventListener('click', async e => {
    const yb = e.target.closest('[data-year]'); if (yb) { s.close(); return setTimeout(() => openTaxRecords(+yb.dataset.year), 280); }
    const mr = e.target.closest('[data-month]');
    if (mr) {
      const period = mr.dataset.month; const cur = reported.filter(r => r.period === period && !r.voided).reduce((a, r) => a + r.amount, 0);
      const v = await promptDialog({ title: 'Tips reported to employer', label: `Total you reported for ${period}`, value: (cur / 100).toFixed(2), ok: 'Save' });
      if (v === null) return; const c = Math.round(parseFloat(v.replace(/[$,]/g, '')) * 100);
      if (!Number.isFinite(c) || c < 0) return flash('Enter a valid amount.');
      const ops = reported.filter(r => r.period === period && !r.voided).map(r => ['taxes', { ...r, voided: true }]);
      ops.push(['taxes', { id: db.uid('t'), kind: 'reported', period, amount: c, at: Date.now() }]);
      ops.push(['audit', db.auditEntry('taxes', period, 'reported', cur, c, 'Reported tips updated')]);
      await db.putMany(ops); return reopen();
    }
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (act === 'w2') {
      const ss = openSheet({ title: `W-2 ${year}`, body: html`<div class="stack">${moneyInput('wages', 'Box 1 — wages, tips, other compensation', w2.wages ?? null)}${moneyInput('ssTips', 'Box 7 — social security tips', w2.ssTips ?? null)}${moneyInput('allocated', 'Box 8 — allocated tips', w2.allocated ?? null)}</div>`, foot: html`<button class="btn primary block">Save</button>` });
      ss.foot.addEventListener('click', async () => {
        const rec = { id: 'w2_' + year, kind: 'w2', year };
        for (const k of ['wages', 'ssTips', 'allocated']) { const v = readMoney(ss.body, k); if (Number.isNaN(v)) return flash('Check the amounts.'); if (v !== null) rec[k] = v; }
        await db.put('taxes', rec); ss.close(); reopen();
      });
    }
    if (act === 'qtd') {
      const v = await promptDialog({ title: `Deduction notes ${year}`, label: 'Your notes (rules, limits, sources)', value: yr.notes || '', required: false, multiline: true });
      if (v === null) return; await db.put('taxes', { id: 'yr_' + year, kind: 'year', year, notes: v.slice(0, 2000) }); reopen();
    }
    if (act === 'print') window.print();
    if (act === 'csv') {
      const m = c => (c / 100).toFixed(2);
      const rows = [['Month', 'Shifts', 'Hours', 'Cash tips', 'Card tips', 'Gross tips', 'Tip-outs', 'Net retained tips', 'Tips received', 'Card tips outstanding', 'Reported to employer', 'Not reported']];
      for (const x of y.months) rows.push([x.period, x.shifts, x.hours.toFixed(2), m(x.cashTips), m(x.cardTips), m(x.grossTips), m(x.tipouts), m(x.netTips), m(x.received), m(x.outstanding), m(x.reported), m(x.unreported)]);
      const t = y.total; rows.push(['TOTAL ' + year, t.shifts, t.hours.toFixed(2), m(t.cashTips), m(t.cardTips), m(t.grossTips), m(t.tipouts), m(t.netTips), m(t.received), m(t.outstanding), m(t.reported), m(t.unreported)]);
      const res = await saveFile(`shiftcash-tips-${year}.csv`, toCSV(rows), 'text/csv'); flash('Saved to ' + res.where);
    }
  });
}
