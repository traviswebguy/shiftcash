// Shared small form helpers for secondary screens (native decimal keyboard).
import { html } from '../ui.js';
import { toCents, plain } from '../money.js';

export function moneyInput(name, label, cents = null, { placeholder = '0.00', hint = '' } = {}) {
  return html`<label class="field"><span>${label}</span>
    <input class="input num" inputmode="decimal" autocomplete="off" data-money="${name}" value="${cents === null || cents === undefined ? '' : plain(cents)}" placeholder="${placeholder}">
    ${hint ? html`<small class="muted" style="display:block;margin:5px 2px 0;font-size:12px">${hint}</small>` : ''}</label>`;
}

/** Read a money input. Empty → fallback (default null). Invalid → NaN. */
export function readMoney(root, name, fallback = null) {
  const el = root.querySelector(`[data-money="${name}"]`);
  if (!el) return fallback;
  const v = el.value.trim();
  if (v === '') return fallback;
  return toCents(v);
}

export function readText(root, name, max = 500) {
  const el = root.querySelector(`[data-text="${name}"]`);
  return el ? el.value.trim().slice(0, max) : '';
}
