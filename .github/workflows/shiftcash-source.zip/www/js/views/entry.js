// ShiftCash — fast transaction entry (cash / card / split) with an on-screen keypad.
import { html, icon, openSheet, flash, confirmDialog, $ } from '../ui.js';
import { haptic } from '../native.js';
import { fmt, keypadAppend, keypadBackspace, cashPayment, cardPayment, roundedPayable, ROUNDING_METHODS, roundingChoices, safeRounding } from '../money.js';
import { checkState } from '../ledger.js';
import { S, saveNewCheck, addPayment, voidCheck, roundingFromSettings } from '../store.js';
import { uid } from '../db.js';
import { openStartShift } from './shift.js';

const DENOMS = [100, 500, 1000, 2000, 5000, 10000];

function newDraft(method, due = 0) {
  if (method === 'card') return { method: 'card', due, tip: null, tipLater: true, extraCashTip: 0, showExtra: false };
  return { method: 'cash', due, received: null, rounding: roundingFromSettings(), changeMode: 'calc', changeGiven: null, keptTip: 0, extraTip: 0, keepRemainder: false, tipMode: 'later' };
}

/** Turn a draft into the computed payment and the record to store. */
function evalDraft(d) {
  if (d.method === 'card') {
    const tip = d.tipLater ? null : (d.tip ?? 0);
    const c = cardPayment({ due: d.due, tip, extraCashTip: d.extraCashTip });
    return { c, rec: { method: 'card', due: d.due, tip, tipStatus: d.tipLater ? 'pending' : 'entered', extraCashTip: d.extraCashTip, receipt: d.receipt || '' } };
  }
  const rounded = roundedPayable(d.due, d.received ?? undefined, d.rounding);
  let received = d.changeMode === 'exact' || d.received === null ? rounded : d.received;
  // With change targeting, the payable depends on what was handed over.
  const roundedDue = roundedPayable(d.due, received, d.rounding);
  if (d.changeMode === 'exact' || d.received === null) received = roundedDue;
  const expected = Math.max(0, received - roundedDue);
  let changeGiven = expected, keptTip = 0;
  if (d.changeMode === 'keep') { changeGiven = 0; keptTip = expected; }
  else if (d.changeMode === 'custom') { changeGiven = d.changeGiven ?? 0; keptTip = d.keepRemainder ? Math.max(0, expected - changeGiven) : 0; }
  else if (d.changeMode === 'exact') { changeGiven = 0; }
  const extraTip = d.tipMode === 'now' ? d.extraTip : 0;
  const tipPending = d.tipMode === 'later' && d.changeMode !== 'keep';
  const input = { due: d.due, received, rounding: d.rounding, changeGiven, keptTip, extraTip, tipPending };
  return { c: cashPayment(input), rec: { method: 'cash', ...input } };
}

/**
 * Open the entry sheet.
 *   opts.check      – existing check: add a payment toward its balance
 *   opts.table / opts.visitId – prefill for "another check, same table"
 */
export function openEntry(opts = {}) {
  if (!S.shift) { openStartShift({ then: () => openEntry(opts) }); return; }
  const addTo = opts.check || null;
  const E = {
    table: addTo ? String(addTo.table) : (opts.table || ''),
    ticket: 0, method: opts.method || 'cash', visitId: opts.visitId || null, sameParty: !!opts.visitId,
    ticketNo: '', notes: '', discount: 0, comp: 0, moreOpen: false, segment: S.shift.segment,
    pays: [], active: 0, field: addTo ? 'pay.received' : (opts.table ? 'ticket' : 'table'),
    saving: false, token: uid('t'),
  };
  const balance = addTo ? checkState(addTo).balance : 0;
  E.pays = [newDraft(E.method, balance)];
  if (addTo && E.method === 'card') E.field = 'pay.tip';

  const netDue = () => addTo ? balance : Math.max(0, E.ticket - E.discount - E.comp);
  const syncSingle = () => { if (E.method !== 'split' && E.pays[0]) E.pays[0].due = netDue(); };
  const pay = () => E.pays[E.active];

  const sheet = openSheet({
    full: true,
    title: addTo ? `Add payment · Table ${addTo.table}` : 'New Transaction',
    sub: addTo ? `Balance ${fmt(balance)}` : `${S.shift.segment === 'lunch' ? 'Lunch' : 'Dinner'} · ${S.summary.checks} checks so far`,
    body: html``,
    after: html`<div class="keypad" id="kp">
      ${[1, 2, 3].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="bs" class="k-act" aria-label="Backspace">⌫</button>
      ${[4, 5, 6].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="next" class="k-act">Next</button>
      ${[7, 8, 9].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="save" class="k-save" id="kpSave">Save</button>
      <button data-k="clr" class="k-act">C</button><button data-k="0">0</button><button data-k="00">00</button>
    </div>`,
  });

  // ---------- rendering ----------
  const recentTables = () => {
    const seen = []; for (let i = S.checks.length - 1; i >= 0 && seen.length < 6; i--) { const t = String(S.checks[i].table); if (!seen.includes(t)) seen.push(t); }
    return seen;
  };
  const moneyField = (key, label, cents, { xl = false, placeholder = '0.00' } = {}) => html`
    <button class="money-field ${E.field === key ? 'active' : ''} ${xl ? 'xl' : ''}" data-field="${key}">
      <span class="lbl">${label}</span>
      <span class="val num ${cents === null ? 'placeholder' : ''}">${cents === null ? placeholder : fmt(cents)}</span>
    </button>`;

  function cashBlock(d, i, inSplit) {
    const { c } = evalDraft(d);
    const r = d.rounding;
    const roundLabel = r.method === 'manual' ? 'manual amount' : r.method === 'exact' ? 'no rounding' : r.method === 'down' ? 'cash discount' : 'rounded';
    const given = d.received !== null || d.changeMode === 'exact';
    const keep = d.changeMode === 'keep';
    let changeCard;
    if (!given) changeCard = html`<div class="change-card idle"><div class="lbl">Change to give back</div><div class="amt">Enter cash given</div></div>`;
    else if (keep) changeCard = html`<div class="change-card keep"><div class="lbl">Customer keeps the change</div><div class="amt num">${fmt(c.expectedChange)}</div><div class="sub">Recorded as their cash tip</div></div>`;
    else changeCard = html`<div class="change-card ${c.shortage ? 'bad' : ''}"><div class="lbl">${c.shortage ? 'Too much change' : 'Give back'}</div><div class="amt num">${fmt(c.changeGiven)}</div>
      ${d.changeMode === 'custom' && c.changeGiven !== c.expectedChange ? html`<div class="sub">Calculated change was ${fmt(c.expectedChange)}</div>` : ''}</div>`;
    return html`
      <div class="stack">
        ${inSplit ? moneyField('pay.due', 'Amount of this cash payment', d.due) : ''}
        <button class="row between pill" style="width:100%;min-height:40px;justify-content:space-between;border-radius:10px;font-size:13.5px" data-act="rounding">
          <span class="row" style="gap:6px;white-space:nowrap">${icon('receipt', 'xs')} Bill <b class="num">${fmt(c.due)}</b> → <b class="num">${fmt(c.roundedDue)}</b></span>
          <span style="white-space:nowrap">${c.roundingAdj ? (c.roundingAdj > 0 ? '+' : '−') + fmt(Math.abs(c.roundingAdj)) : roundLabel} ${icon('chevd', 'xs')}</span>
        </button>
        ${r.method === 'manual' ? moneyField('pay.manualDue', 'Manual payable amount', r.manualDue ?? null) : ''}
        ${moneyField('pay.received', 'Cash they gave you', d.received, { xl: true, placeholder: 'Tap bills or type' })}
        <div class="denoms">${DENOMS.map(v => html`<button data-denom="${v}">+$${v / 100}</button>`)}</div>
        ${changeCard}
        <div class="chips" style="flex-wrap:wrap">
          <button class="chip ${d.changeMode === 'exact' ? 'on' : ''}" data-cm="exact">Exact payment</button>
          <button class="chip ${d.changeMode === 'calc' && d.received !== null ? 'on' : ''}" data-cm="calc">Gave change</button>
          <button class="chip ${keep ? 'on' : ''}" data-cm="keep">Keep the change</button>
          <button class="chip ${d.changeMode === 'custom' ? 'on' : ''}" data-cm="custom">Custom change</button>
        </div>
        ${d.changeMode === 'custom' ? html`
          ${moneyField('pay.changeGiven', 'Change actually given back', d.changeGiven)}
          ${c.excess > 0 ? html`<label class="toggle"><span>Customer said the remaining ${fmt(c.excess)} is a tip</span>
            <span class="switch"><input type="checkbox" data-bind="keepRemainder" ${d.keepRemainder ? 'checked' : ''}><span></span></span></label>` : ''}` : ''}
        ${keep ? '' : html`
          <div class="field"><span>What they left on the table</span>
            <div class="seg">
              <button class="${d.tipMode === 'later' ? 'on' : ''}" data-tipmode="later">Enter at POS</button>
              <button class="${d.tipMode === 'none' ? 'on' : ''}" data-tipmode="none">No tip</button>
              <button class="${d.tipMode === 'now' ? 'on' : ''}" data-tipmode="now">Enter now</button>
            </div></div>
          ${d.tipMode === 'now' ? moneyField('pay.extraTip', 'Cash tip left on the table', d.extraTip) : ''}
          ${d.tipMode === 'later' ? html`<div class="muted" style="font-size:12.5px;margin-top:-4px">Saved to your <b>Enter tips</b> list on Home.</div>` : ''}`}
        ${c.warnings.filter(w => w.code !== 'tip_pending').map(w => html`<div class="banner ${w.code === 'unconfirmed' ? 'warn' : 'neg'}">${icon('alert', 'sm')}<div>${w.code === 'overchange' ? 'Possible cash shortage: ' + fmt(w.cents) + ' more change than needed.' : w.msg}${w.code === 'unconfirmed' ? ' It will not be counted as a tip unless the customer says so.' : ''}</div></div>`)}
        <details class="more">
          <summary class="row between" style="padding:4px 2px;color:var(--muted);font-weight:600;font-size:13.5px">Full cash breakdown ${icon('chevd', 'sm chev-rot')}</summary>
          <div class="breakdown" style="margin-top:8px">
            <div class="kv"><span class="k">Original ticket total</span><span class="v num">${fmt(c.due)}</span></div>
            <div class="kv"><span class="k">Rounded payable</span><span class="v num">${fmt(c.roundedDue)}</span></div>
            <div class="kv"><span class="k">Cash received</span><span class="v num">${fmt(c.received)}</span></div>
            <div class="kv"><span class="k">Expected change</span><span class="v num">${fmt(c.expectedChange)}</span></div>
            <div class="kv"><span class="k">Actual change returned</span><span class="v num">${fmt(c.changeGiven)}</span></div>
            <div class="kv"><span class="k">Rounding adjustment</span><span class="v num">${c.roundingAdj > 0 ? '+' : c.roundingAdj < 0 ? '−' : ''}${fmt(Math.abs(c.roundingAdj))}</span></div>
            <div class="kv"><span class="k">Confirmed cash tip</span><span class="v num pos">${c.tipPending ? 'Enter at POS' : fmt(c.cashTip)}</span></div>
            <div class="kv"><span class="k">Unconfirmed excess cash</span><span class="v num ${c.unconfirmed ? 'warn' : ''}">${fmt(c.unconfirmed)}</span></div>
            <div class="kv"><span class="k">Cash shortage</span><span class="v num ${c.shortage ? 'neg' : ''}">${c.shortage ? '−' : ''}${fmt(c.shortage)}</span></div>
          </div>
        </details>
      </div>`;
  }

  function cardBlock(d, inSplit) {
    const { c } = evalDraft(d);
    const pcts = [15, 18, 20, 22];
    return html`
      <div class="stack">
        ${inSplit ? moneyField('pay.due', 'Amount on this card', d.due) : ''}
        ${moneyField('pay.tip', 'Card tip', d.tipLater ? null : d.tip, { xl: true, placeholder: d.tipLater ? 'Enter at POS' : '0.00' })}
        <div class="chips">
          <button class="chip ${d.tip === 0 && !d.tipLater ? 'on' : ''}" data-act="no-tip">No Tip</button>
          <button class="chip ${d.tipLater ? 'on' : ''}" data-act="tip-later">Enter at POS</button>
          ${pcts.map(p => html`<button class="chip soft" data-tip-pct="${p}">${p}% · ${fmt(Math.round(d.due * p / 100))}</button>`)}
          <button class="chip ${d.showExtra ? 'on' : 'soft'}" data-act="extra-tip">${icon('plus', 'xs')} Cash Tip</button>
        </div>
        ${d.showExtra ? moneyField('pay.extraCashTip', 'Additional cash tip', d.extraCashTip) : ''}
        <label class="field"><span>Receipt reference (optional — never card numbers)</span>
          <input class="input" data-bind="receipt" maxlength="40" autocomplete="off" value="${d.receipt || ''}" placeholder="e.g. last 4 of auth code"></label>
        <div class="breakdown">
          <div class="kv"><span class="k">Ticket</span><span class="v num">${fmt(c.due)}</span></div>
          <div class="kv"><span class="k">Card tip</span><span class="v num pos">${d.tipLater ? 'Enter later' : fmt(c.tip)}</span></div>
          <div class="kv total"><span class="k">Final card payment</span><span class="v num">${fmt(c.charge)}</span></div>
          ${c.extraCashTip ? html`<div class="kv"><span class="k">Cash tip (separate)</span><span class="v num pos">${fmt(c.extraCashTip)}</span></div>` : ''}
          <div class="kv"><span class="k">Tip %</span><span class="v num">${c.due ? (c.tip / c.due * 100).toFixed(1) + '%' : '—'}</span></div>
        </div>
      </div>`;
  }

  function splitBlock() {
    const applied = E.pays.reduce((a, d) => a + d.due, 0);
    const remaining = netDue() - applied;
    return html`
      <div class="stack">
        <div class="list">
          ${E.pays.map((d, i) => { const { c } = evalDraft(d); return html`
            <button class="li" data-pay="${i}" style="${i === E.active ? 'background:var(--brand-tint)' : ''}">
              ${icon(d.method === 'cash' ? 'cash' : 'card')}
              <div class="grow"><div class="t">${d.method === 'cash' ? 'Cash' : 'Card'} ${i + 1}</div>
                <div class="s">${c.tipPending || c.tipStatus === 'pending' ? 'Tip later' : 'Tip ' + fmt(c.cashTip + (c.tip || 0))}${d.method === 'cash' && c.roundingAdj ? ' · rounding ' + fmt(c.roundingAdj) : ''}</div></div>
              <span class="amt num">${fmt(d.due)}</span>
              <span class="pill" data-swap="${i}" role="button" style="height:30px">${d.method === 'cash' ? 'Make card' : 'Make cash'}</span>
              ${E.pays.length > 1 ? html`<span class="iconbtn" data-del-pay="${i}" role="button" aria-label="Remove payment">${icon('close', 'sm')}</span>` : ''}
            </button>`; })}
        </div>
        <div class="row between"><span class="muted">Remaining on check</span><b class="num ${remaining < 0 ? 'neg' : remaining > 0 ? 'warn' : 'pos'}">${fmt(remaining)}</b></div>
        <div class="btnrow">
          <button class="btn sm" data-add-pay="card">${icon('card', 'sm')} Add card</button>
          <button class="btn sm" data-add-pay="cash">${icon('cash', 'sm')} Add cash</button>
        </div>
        <div class="section-title" style="margin-top:8px">${pay().method === 'cash' ? 'Cash' : 'Card'} ${E.active + 1}</div>
        ${pay().method === 'cash' ? cashBlock(pay(), E.active, true) : cardBlock(pay(), true)}
      </div>`;
  }

  function render() {
    syncSingle();
    const favs = S.settings.favoriteTables || [];
    const recent = recentTables().filter(t => !favs.includes(t));
    const lastSame = !addTo && E.table ? [...S.checks].reverse().find(c => String(c.table) === E.table && !c.voided) : null;
    sheet.update(html`
      <div class="stack">
        ${E.lastSaved ? html`<div class="banner ok" style="align-items:center">${icon('check', 'sm')}<div class="grow"><b>${E.lastSaved.text}</b></div>
          <button class="btn sm" data-act="undo-last">Undo</button><button class="btn sm" data-act="same-table">Same table</button></div>` : ''}
        ${addTo ? html`<div class="banner info">${icon('receipt', 'sm')}<div>Ticket ${fmt(addTo.ticketCents)} · already paid ${fmt(checkState(addTo).applied)} · <b>balance ${fmt(balance)}</b></div></div>` : html`
        <div class="grid2" style="grid-template-columns: 0.8fr 1.2fr">
          <button class="money-field ${E.field === 'table' ? 'active' : ''}" data-field="table">
            <span class="lbl">Table #</span><span class="val num ${E.table ? '' : 'placeholder'}">${E.table || '—'}</span></button>
          ${moneyField('ticket', 'Ticket total', E.ticket || null)}
        </div>
        <div class="chips">
          ${favs.map(t => html`<button class="chip ${E.table === t ? 'on' : ''}" data-table="${t}">${t}</button>`)}
          ${recent.length ? html`<span class="faint" style="align-self:center;font-size:12px;flex:none">Recent</span>` : ''}
          ${recent.map(t => html`<button class="chip soft ${E.table === t ? 'on' : ''}" data-table="${t}">${t}</button>`)}
        </div>
        ${lastSame ? html`<label class="toggle" style="padding:2px 2px"><span class="muted" style="font-size:13.5px">Same party as Table ${E.table} at ${new Date(lastSame.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} (separate check)</span>
          <span class="switch"><input type="checkbox" data-bind="sameParty" ${E.sameParty ? 'checked' : ''}><span></span></span></label>` : ''}`}
        <div class="seg big">
          <button class="${E.method === 'cash' ? 'on' : ''}" data-method="cash">${icon('cash')}Cash</button>
          <button class="${E.method === 'card' ? 'on' : ''}" data-method="card">${icon('card')}Card</button>
          <button class="${E.method === 'split' ? 'on' : ''}" data-method="split">${icon('split')}Split</button>
        </div>
        ${E.method === 'split' ? splitBlock() : E.method === 'cash' ? cashBlock(pay(), 0, false) : cardBlock(pay(), false)}
        ${addTo ? '' : html`
        <details class="more" ${E.moreOpen ? 'open' : ''} data-more>
          <summary class="row between" style="padding:6px 2px;color:var(--muted);font-weight:600;font-size:14px">Ticket #, notes, discounts ${icon('chevd', 'sm chev-rot')}</summary>
          <div class="stack" style="margin-top:10px">
            <div class="grid2">
              <label class="field"><span>Ticket # (optional)</span><input class="input" data-bind="ticketNo" maxlength="20" value="${E.ticketNo}" inputmode="numeric" autocomplete="off"></label>
              <label class="field"><span>Segment</span><select class="input" data-bind="segment"><option value="lunch" ${E.segment === 'lunch' ? 'selected' : ''}>Lunch</option><option value="dinner" ${E.segment === 'dinner' ? 'selected' : ''}>Dinner</option></select></label>
            </div>
            <div class="grid2">${moneyField('discount', 'Discount', E.discount || null)}${moneyField('comp', 'Comp', E.comp || null)}</div>
            <label class="field"><span>Notes (optional)</span><input class="input" data-bind="notes" maxlength="200" value="${E.notes}" autocomplete="off"></label>
          </div>
        </details>`}
      </div>`);
    const v = validate();
    const btn = $('#kpSave', sheet.el);
    btn.disabled = !v.ok || E.saving;
    btn.textContent = E.saving ? '…' : 'Save';
    btn.setAttribute('aria-label', 'Save transaction');
  }

  function validate() {
    if (!addTo && !E.table) return { ok: false, msg: 'Enter a table number' };
    if (!addTo && !E.ticket) return { ok: false, msg: 'Enter the ticket total' };
    for (const d of E.pays) { if (d.due <= 0 && E.method === 'split') return { ok: false, msg: 'Each payment needs an amount' }; }
    return { ok: true };
  }

  // ---------- keypad ----------
  const fieldOrder = () => {
    const f = addTo ? [] : ['table', 'ticket'];
    if (E.method === 'split') f.push('pay.due');
    if (pay().method === 'cash') f.push('pay.received'); else f.push('pay.tip');
    return f;
  };
  function getField(k) {
    const d = pay();
    switch (k) {
      case 'ticket': return E.ticket; case 'discount': return E.discount; case 'comp': return E.comp;
      case 'pay.manualDue': return d.rounding.manualDue ?? 0;
      default: if (k.startsWith('pay.')) return d[k.slice(4)] ?? 0;
    }
    return 0;
  }
  function setField(k, v) {
    const d = pay();
    switch (k) {
      case 'ticket': case 'discount': case 'comp':
        E[k] = v;
        if (E.method === 'split' && E.pays.length) { const n = netDue(); const others = E.pays.slice(0, -1).reduce((a, x) => a + x.due, 0); E.pays[E.pays.length - 1].due = Math.max(0, n - others); }
        break;
      case 'pay.manualDue': d.rounding = safeRounding({ ...d.rounding, manualDue: v }, !!S.settings.allowRoundUp, d.due); break;
      case 'pay.received': d.received = v; if (d.changeMode === 'exact') d.changeMode = 'calc'; break;
      case 'pay.due': d.due = v; rebalance(); break;
      default: if (k.startsWith('pay.')) { d[k.slice(4)] = v; if (k === 'pay.tip') d.tipLater = false; }
    }
  }
  /** In split mode the last payment absorbs whatever is left, so the check total is never counted twice. */
  function rebalance() {
    if (E.method !== 'split' || E.pays.length < 2 || E.active === E.pays.length - 1) return;
    const others = E.pays.slice(0, -1).reduce((a, d) => a + d.due, 0);
    E.pays[E.pays.length - 1].due = Math.max(0, netDue() - others);
  }
  function key(k) {
    if (S.settings.haptics) haptic(6);
    if (k === 'save') return save();
    if (k === 'next') { const o = fieldOrder(); const i = o.indexOf(E.field); E.field = o[Math.min(o.length - 1, i + 1)] || o[0]; return render(); }
    if (E.field === 'table') {
      if (k === 'bs') E.table = E.table.slice(0, -1);
      else if (k === 'clr') E.table = '';
      else if (E.table.length < 5) E.table = (E.table + k).replace(/^0+(?=\d)/, '');
      E.sameParty = false; E.visitId = null;
      return render();
    }
    let v = getField(E.field) || 0;
    if (k === 'bs') v = keypadBackspace(v);
    else if (k === 'clr') v = 0;
    else if (k === '00') v = keypadAppend(keypadAppend(v, 0), 0);
    else v = keypadAppend(v, +k);
    if (E.field === 'pay.received' && k === 'clr') { pay().received = null; return render(); }
    if (E.field === 'pay.tip' && k === 'clr') { pay().tip = null; return render(); }
    setField(E.field, v);
    render();
  }

  // ---------- save ----------
  async function save() {
    if (E.saving) return;
    const v = validate(); if (!v.ok) { flash(v.msg); return; }
    syncSingle();
    const evals = E.pays.map(evalDraft);
    const under = evals.find(x => x.c.method === 'cash' && x.c.underpaid > 0);
    if (under) { flash(`Cash received is ${fmt(under.c.underpaid)} short of the payable amount. Adjust the amount, or use Split for a partial payment.`, [], 6000); return; }
    const applied = evals.reduce((a, x) => a + x.c.due, 0);
    const due = netDue();
    if (applied > due) { flash(`Payments (${fmt(applied)}) exceed the amount due (${fmt(due)}).`); return; }
    const token = E.token;
    E.saving = true; render();
    try {
      const over = evals.find(x => x.c.shortage > 0);
      if (over && !(await confirmDialog({ title: 'Too much change returned', message: `You returned ${fmt(over.c.shortage)} more change than expected. This will be recorded as a cash shortage. Save anyway?`, ok: 'Save', danger: true }))) return;
      if (applied < due && S.settings.confirmPartial !== false && !(await confirmDialog({ title: 'Partial payment', message: `${fmt(due - applied)} will remain outstanding on this check. You can add the rest later from Tables.`, ok: 'Save partial' }))) return;
      if (!addTo) {
        const dup = S.checks.find(c => !c.voided && String(c.table) === E.table && c.ticketCents === E.ticket && Date.now() - c.createdAt < 120000);
        if (dup && S.settings.confirmDuplicate !== false && !(await confirmDialog({ title: 'Possible duplicate', message: `Table ${E.table} with a ${fmt(E.ticket)} ticket was saved ${Math.round((Date.now() - dup.createdAt) / 1000)} seconds ago. Save another?`, ok: 'Save again' }))) return;
      }
      if (token !== E.token) return; // already submitted
      E.token = uid('t');
      const payments = evals.map(x => ({ id: uid('p'), createdAt: Date.now(), ...x.rec }));
      let saved;
      if (addTo) {
        for (const p of payments) saved = await addPayment(addTo.id, p);
        flash(`Payment added to Table ${addTo.table}`);
        sheet.close();
        opts.onSaved?.(saved);
        return;
      }
      const lastSame = E.sameParty ? [...S.checks].reverse().find(c => String(c.table) === E.table && !c.voided) : null;
      saved = await saveNewCheck({
        shiftId: S.shift.id, visitId: E.visitId || lastSame?.visitId || uid('v'), table: E.table, ticketNo: E.ticketNo.trim(),
        ticketCents: E.ticket, discountCents: E.discount, compCents: E.comp, notes: E.notes.trim(),
        segment: E.segment, payments,
      });
      const tips = evals.reduce((a, x) => a + (x.c.tip || 0) + x.c.cashTip, 0);
      const later = evals.some(x => x.c.tipPending || x.c.tipStatus === 'pending');
      E.lastSaved = { id: saved.id, table: saved.table, visitId: saved.visitId, text: `Saved Table ${saved.table} · ${fmt(saved.ticketCents)} · ${later ? 'tip later' : 'tip ' + fmt(tips)}` };
      clearTimeout(E.savedTimer); E.savedTimer = setTimeout(() => { E.lastSaved = null; if (!sheet.closed) render(); }, 8000);
      if (S.settings.afterSave === 'home') flash(E.lastSaved.text, [{ label: 'Undo', run: async () => { await voidCheck(saved.id, 'Undone immediately after entry'); flash('Entry voided (kept in history)'); } }], 6000);
      if (S.settings.afterSave === 'home') { sheet.close(); if (location.hash !== '#home') location.hash = '#home'; return; }
      reset();
    } finally {
      E.saving = false; render();
    }
  }

  function reset(pre = {}) {
    Object.assign(E, { segment: S.shift.segment, table: pre.table ? String(pre.table) : '', ticket: 0, visitId: pre.visitId || null, sameParty: !!pre.visitId, ticketNo: '', notes: '', discount: 0, comp: 0, active: 0, field: pre.table ? 'ticket' : 'table' });
    E.method = E.method === 'split' ? 'cash' : E.method;
    E.pays = [newDraft(E.method, 0)];
    sheet.el.querySelector('.sheet-head .sub').textContent = `${S.shift.segment === 'lunch' ? 'Lunch' : 'Dinner'} · ${S.summary.checks} checks so far`;
    sheet.body.scrollTop = 0;
    render();
  }

  // ---------- events ----------
  $('#kp', sheet.el).addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (b) key(b.dataset.k); });
  sheet.body.addEventListener('click', async e => {
    const t = e.target;
    const f = t.closest('[data-field]'); if (f) { E.field = f.dataset.field; if (document.activeElement?.blur) document.activeElement.blur(); return render(); }
    const tb = t.closest('[data-table]'); if (tb) { E.table = tb.dataset.table; E.field = 'ticket'; E.sameParty = false; E.visitId = null; return render(); }
    const m = t.closest('[data-method]');
    if (m) {
      const method = m.dataset.method; if (method === E.method) return;
      E.method = method; E.active = 0;
      if (method === 'split') { const n = netDue(); E.pays = [newDraft('card', n - Math.floor(n / 2)), newDraft('card', Math.floor(n / 2))]; }
      else E.pays = [newDraft(method, netDue())];
      E.field = method === 'card' ? 'pay.tip' : method === 'cash' ? (E.ticket || addTo ? 'pay.received' : E.field) : 'pay.tip';
      return render();
    }
    const dn = t.closest('[data-denom]'); if (dn) { const d = pay(); d.received = (d.received || 0) + +dn.dataset.denom; if (d.changeMode === 'exact') d.changeMode = 'calc'; E.field = 'pay.received'; if (S.settings.haptics) haptic(); return render(); }
    const cm = t.closest('[data-cm]');
    if (cm) {
      const d = pay(); d.changeMode = cm.dataset.cm;
      if (d.changeMode === 'exact') d.received = null;
      if (d.changeMode === 'custom') { E.field = 'pay.changeGiven'; d.changeGiven = d.changeGiven ?? 0; }
      return render();
    }
    const tp = t.closest('[data-tip-pct]'); if (tp) { const d = pay(); d.tip = Math.round(d.due * +tp.dataset.tipPct / 100); return render(); }
    const sw = t.closest('[data-swap]');
    if (sw) { e.stopPropagation(); const i = +sw.dataset.swap; const d = E.pays[i]; E.pays[i] = newDraft(d.method === 'cash' ? 'card' : 'cash', d.due); E.active = i; E.field = E.pays[i].method === 'cash' ? 'pay.received' : 'pay.tip'; return render(); }
    const del = t.closest('[data-del-pay]'); if (del) { e.stopPropagation(); E.pays.splice(+del.dataset.delPay, 1); E.active = Math.min(E.active, E.pays.length - 1); const others = E.pays.slice(0, -1).reduce((a, x) => a + x.due, 0); E.pays[E.pays.length - 1].due = Math.max(0, netDue() - others); return render(); }
    const pi = t.closest('[data-pay]'); if (pi) { E.active = +pi.dataset.pay; E.field = pay().method === 'cash' ? 'pay.received' : 'pay.tip'; return render(); }
    const ap = t.closest('[data-add-pay]');
    if (ap) {
      let due = Math.max(0, netDue() - E.pays.reduce((a, d) => a + d.due, 0));
      if (!due && E.pays.length) { const last = E.pays[E.pays.length - 1]; due = Math.floor(last.due / 2); last.due -= due; }
      E.pays.push(newDraft(ap.dataset.addPay, due)); E.active = E.pays.length - 1; E.field = 'pay.due'; return render();
    }

    const act = t.closest('[data-act]')?.dataset.act;
    if (act === 'no-tip') { const d = pay(); if (d.method === 'card') { d.tip = 0; d.tipLater = false; d.extraCashTip = 0; d.showExtra = false; } else { d.keptTip = 0; d.extraTip = 0; d.tipMode = 'none'; d.keepRemainder = false; if (d.changeMode === 'keep') d.changeMode = 'calc'; } return render(); }
    if (act === 'extra-tip') { const d = pay(); d.showExtra = !d.showExtra; E.field = d.showExtra ? (d.method === 'card' ? 'pay.extraCashTip' : 'pay.extraTip') : fieldOrder().at(-1); if (!d.showExtra) { d.extraTip = 0; d.extraCashTip = 0; } return render(); }
    const tm = t.closest('[data-tipmode]');
    if (tm) { const d = pay(); d.tipMode = tm.dataset.tipmode; if (d.tipMode === 'now') E.field = 'pay.extraTip'; else if (E.field === 'pay.extraTip') E.field = 'pay.received'; return render(); }
    if (act === 'tip-later') { const d = pay(); d.tipLater = true; d.tip = null; return render(); }
    if (act === 'rounding') return roundingSheet(pay(), render);
    if (act === 'undo-last' && E.lastSaved) { const ls = E.lastSaved; E.lastSaved = null; await voidCheck(ls.id, 'Undone immediately after entry'); render(); return flash(`Table ${ls.table} entry voided (kept in history)`); }
    if (act === 'same-table' && E.lastSaved) { const ls = E.lastSaved; E.lastSaved = null; return reset({ table: ls.table, visitId: ls.visitId }); }
    const more = t.closest('[data-more] > summary'); if (more) { setTimeout(() => { E.moreOpen = sheet.body.querySelector('[data-more]')?.open; }, 0); }
  });
  sheet.body.addEventListener('input', e => {
    const b = e.target.dataset.bind; if (!b) return;
    if (b === 'receipt') pay().receipt = e.target.value;
    else if (b === 'ticketNo' || b === 'notes') E[b] = e.target.value;
  });
  sheet.body.addEventListener('change', e => {
    const b = e.target.dataset.bind;
    if (b === 'sameParty') { E.sameParty = e.target.checked; E.visitId = null; render(); }
    if (b === 'keepRemainder') { pay().keepRemainder = e.target.checked; render(); }
    if (b === 'segment') E.segment = e.target.value === 'lunch' ? 'lunch' : 'dinner';
  });
  render();
}

function roundingSheet(d, done) {
  const r = { ...d.rounding };
  const s = openSheet({ title: 'Rounding for this payment', body: html``, foot: html`<button class="btn primary block" data-ok>Apply</button>` });
  const draw = () => s.update(html`
    <div class="stack">
      <div class="list">${Object.entries(roundingChoices(!!S.settings.allowRoundUp)).map(([k, v]) => html`<button class="li" data-m="${k}"><span class="grow t">${v}</span>${r.method === k ? icon('check') : ''}</button>`)}</div>
      ${S.settings.allowRoundUp && ['nearest', 'up', 'down'].includes(r.method) ? html`
        <div class="seg"><button class="${r.target !== 'change' ? 'on' : ''}" data-tg="ticket">Round ticket</button><button class="${r.target === 'change' ? 'on' : ''}" data-tg="change">Round change</button></div>` : ''}
      ${r.method === 'nearest' ? html`<div class="seg"><button class="${r.half !== 'down' ? 'on' : ''}" data-h="up">$.50 rounds up</button><button class="${r.half === 'down' ? 'on' : ''}" data-h="down">$.50 rounds down</button></div>` : ''}
      ${r.method === 'manual' ? html`<p class="muted" style="font-size:13.5px;margin:0">After applying, enter the payable amount on the keypad. The original ticket total is kept unchanged.</p>` : ''}
      <p class="muted" style="font-size:12.5px;margin:0">Rounding differences are tracked separately and are never counted as tips.</p>
    </div>`);
  s.body.addEventListener('click', e => {
    const m = e.target.closest('[data-m]'); if (m) { r.method = m.dataset.m; if (r.method === 'manual' && r.manualDue == null) r.manualDue = d.due; draw(); }
    const tg = e.target.closest('[data-tg]'); if (tg) { r.target = tg.dataset.tg; draw(); }
    const h = e.target.closest('[data-h]'); if (h) { r.half = h.dataset.h; draw(); }
  });
  s.foot.addEventListener('click', () => { d.rounding = safeRounding(r, !!S.settings.allowRoundUp, d.due); s.close(); done(); });
  draw();
}
