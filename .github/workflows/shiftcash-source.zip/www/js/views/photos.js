// ShiftCash — receipt / report photos: capture, crop, redact, compress, store locally.
import { html, icon, openSheet, flash, confirmDialog } from '../ui.js';
import * as store from '../store.js';
import * as db from '../db.js';

const MAX_EDGE = 1600;
const QUALITY = 0.72;

export function photoStrip(ids = [], addable = false) {
  return html`<div class="photos">
    ${(ids || []).map(id => html`<img data-photo-id="${id}" alt="Attached photo" loading="lazy">`)}
    ${addable ? html`<button class="add" data-add-photo aria-label="Add photo">${icon('camera')}</button>` : ''}
  </div>`;
}

// Hydrate any <img data-photo-id> that appears in the DOM.
const urls = new Map();
async function hydrate(img) {
  const id = img.dataset.photoId; if (!id || img.src) return;
  if (!urls.has(id)) {
    const p = await store.getPhoto(id);
    if (!p?.blob) { img.alt = 'Photo unavailable'; return; }
    urls.set(id, URL.createObjectURL(p.blob));
  }
  img.src = urls.get(id);
  img.addEventListener('click', () => viewPhoto(id), { once: true });
}
new MutationObserver(muts => {
  for (const m of muts) for (const n of m.addedNodes) {
    if (n.nodeType !== 1) continue;
    if (n.matches?.('img[data-photo-id]')) hydrate(n);
    n.querySelectorAll?.('img[data-photo-id]').forEach(hydrate);
  }
}).observe(document.documentElement, { childList: true, subtree: true });

function viewPhoto(id) {
  const s = openSheet({
    title: 'Photo', body: html`<img data-photo-id="${id}" style="width:100%;border-radius:12px" alt="Photo">`,
    foot: html`<button class="btn danger block" data-del>Delete this photo</button>`,
  });
  s.foot.addEventListener('click', async () => {
    if (!(await confirmDialog({ title: 'Delete photo?', message: 'The photo will be permanently removed from this device. Records that referenced it are kept.', ok: 'Delete', danger: true }))) return;
    await db.del('photos', id); urls.delete(id);
    await db.put('audit', db.auditEntry('photo', id, 'delete', null, null, 'Deleted by user'));
    s.close(); flash('Photo deleted');
    document.querySelectorAll(`img[data-photo-id="${CSS.escape(id)}"]`).forEach(i => i.remove());
  });
}

/** Pick/capture an image, let the user crop/redact, compress, save. Resolves to photo id or null. */
export function photoPicker({ kind = 'receipt', ref = null } = {}) {
  return new Promise(resolve => {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*'; input.setAttribute('capture', 'environment');
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return resolve(null);
      if (!/^image\//.test(file.type) || file.size > 40 * 1024 * 1024) { flash('Please choose an image file.'); return resolve(null); }
      try { resolve(await editor(file, kind, ref)); } catch (e) { flash('Could not read that image.'); resolve(null); }
    };
    input.click();
  });
}

async function loadImage(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = 'async';
    await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
    return img;
  } finally { setTimeout(() => URL.revokeObjectURL(url), 1000); }
}

function editor(file, kind, ref) {
  return new Promise(async (resolve, reject) => {
    let img;
    try { img = await loadImage(file); } catch (e) { return reject(e); }
    const scale = Math.min(1, MAX_EDGE / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(img.naturalWidth * scale); canvas.height = Math.round(img.naturalHeight * scale);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const undo = [];
    let mode = 'redact', start = null, rect = null, base = null, done = false;

    const s = openSheet({
      full: true, title: 'Edit photo', sub: 'Crop or black out customer details before saving',
      body: html`<div class="stack">
        <div class="seg"><button class="on" data-mode="redact">${icon('redact', 'sm')} Redact</button><button data-mode="crop">${icon('crop', 'sm')} Crop</button></div>
        <div class="editor-wrap" id="ed"></div>
        <div class="btnrow"><button class="btn sm" data-undo>${icon('undo', 'sm')} Undo</button><button class="btn sm" data-apply-crop disabled>Apply crop</button></div>
        <p class="muted" style="font-size:12.5px;margin:0">Drag on the photo. Redaction is burned into the saved image. Never photograph full card numbers.</p></div>`,
      foot: html`<button class="btn primary block" data-save>Save photo</button>`,
      onClose: () => { if (!done) resolve(null); },
    });
    s.body.querySelector('#ed').appendChild(canvas);
    const pt = e => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * canvas.width / r.width, y: (e.clientY - r.top) * canvas.height / r.height }; };
    const norm = (a, b) => ({ x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(a.x - b.x), h: Math.abs(a.y - b.y) });
    canvas.addEventListener('pointerdown', e => { canvas.setPointerCapture(e.pointerId); start = pt(e); base = ctx.getImageData(0, 0, canvas.width, canvas.height); });
    canvas.addEventListener('pointermove', e => {
      if (!start) return;
      rect = norm(start, pt(e));
      ctx.putImageData(base, 0, 0);
      if (mode === 'redact') { ctx.fillStyle = '#000'; ctx.fillRect(rect.x, rect.y, rect.w, rect.h); }
      else { ctx.strokeStyle = '#3BE07F'; ctx.lineWidth = Math.max(3, canvas.width / 200); ctx.setLineDash([12, 8]); ctx.strokeRect(rect.x, rect.y, rect.w, rect.h); ctx.setLineDash([]); }
    });
    canvas.addEventListener('pointerup', () => {
      if (!start) return;
      if (rect && rect.w > 4 && rect.h > 4) {
        if (mode === 'redact') { undo.push(base); if (undo.length > 6) undo.shift(); rect = null; }
        else s.body.querySelector('[data-apply-crop]').disabled = false;
      } else ctx.putImageData(base, 0, 0);
      start = null;
    });
    s.body.addEventListener('click', e => {
      const m = e.target.closest('[data-mode]');
      if (m) { if (base && mode === 'crop' && rect) ctx.putImageData(base, 0, 0); mode = m.dataset.mode; rect = null; s.body.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b === m)); s.body.querySelector('[data-apply-crop]').disabled = true; }
      if (e.target.closest('[data-undo]') && undo.length) {
        const prev = undo.pop(); canvas.width = prev.width; canvas.height = prev.height; ctx.putImageData(prev, 0, 0); rect = null;
      }
      if (e.target.closest('[data-apply-crop]') && rect && base) {
        undo.push(base);
        const r = { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.w), h: Math.round(rect.h) };
        const tmp = document.createElement('canvas'); tmp.width = base.width; tmp.height = base.height; tmp.getContext('2d').putImageData(base, 0, 0);
        canvas.width = r.w; canvas.height = r.h; ctx.drawImage(tmp, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);
        rect = null; e.target.closest('[data-apply-crop]').disabled = true;
      }
    });
    s.foot.addEventListener('click', async () => {
      if (mode === 'crop' && rect && base) ctx.putImageData(base, 0, 0); // discard un-applied crop outline
      const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', QUALITY));
      if (!blob) { flash('Could not compress image.'); return; }
      const id = await store.savePhoto(blob, ref, { kind, w: canvas.width, h: canvas.height });
      done = true; s.close(); flash(`Photo saved (${Math.round(blob.size / 1024)} KB)`);
      resolve(id);
    });
  });
}
