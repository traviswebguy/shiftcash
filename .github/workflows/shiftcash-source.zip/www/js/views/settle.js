// ShiftCash — guided end-of-shift reconciliation with the restaurant.
import { html, icon, openSheet, flash, confirmDialog, toLocalInput, fromLocalInput } from '../ui.js';
import { fmt, fmtSigned, toCents, plain } from '../money.js';
import { summarizeShift, finalSummary, compareReported, describeDiff, explainDiff } from '../ledger.js';
import * as store from '../store.js';
import { S } from '../store.js';
import { openCashCounter } from './shift.js';
import { photoStrip, photoPicker } from './photos.js';

const POLICY_COLLECT = { original: 'Restaurant collects original cash ticket totals', rounded: 'Restaurant collects rounded cash totals' };
const POLICY_CARD = { deduct: 'Card tips deducted from money owed', separate: 'Card tips paid separately (cash, nightly)', payroll: 'Card tips paid through payroll', later: 'Card tips paid at a later date' };
const REPORT_FIELDS = [['cashSales', 'Cash sales'], ['cardSales', 'Card sales'], ['totalSales', 'Total sales'], ['cardTips', 'Card tips'], ['tipouts', 'Tip-outs'], ['settlement', 'Settlement amount'], ['other', 'Other adjustments']];

export function openSettle() {
  if (!S.shift) return;
  const sh = S.shift;
  const st = {
    tab: 'review',
    policy: { collect: sh.policy?.collect || S.settings.policyCollect, cardTips: sh.policy?.cardTips || S.settings.policyCardTips, adjustments: sh.policy?.adjustments || S.settings.policyAdjustments || [] },
    adjustments: [], reported: {}, countedCash: null, countedAfter: null, paidToRestaurant: null, receivedFromRestaurant: null,
    cardTipsCredited: null, cardTipsCash: null, notes: '', photoIds: [], endedAt: sh.endedAt || Date.now(), counts: null,
  };
  const calc = () => summarizeShift({ shift: { ...sh, endedAt: st.endedAt, policy: st.policy, settlement: { adjustments: st.adjustments } }, checks: S.checks, moves: S.moves, payouts: S.payouts });
  const defaults = s => {
    const unpaid = s.cardTipsOutstanding;
    if (st.cardTipsCredited === null) st.cardTipsCredited = st.policy.cardTips === 'deduct' ? unpaid : 0;
    if (st.cardTipsCash === null) st.cardTipsCash = st.policy.cardTips === 'separate' ? unpaid : 0;
  };
  const settlementRec = () => ({
    policy: st.policy, adjustments: st.adjustments, reported: st.reported,
    countedCash: st.countedCash, countedAfter: st.countedAfter,
    paidToRestaurant: st.paidToRestaurant, receivedFromRestaurant: st.receivedFromRestaurant,
    cardTipsCredited: st.policy.cardTips === 'deduct' ? st.cardTipsCredited | 0 : 0, cardTipsVia: 'settlement',
    cardTipsCash: st.policy.cardTips === 'deduct' ? 0 : st.cardTipsCash | 0,
    notes: st.notes, photoIds: st.photoIds, cashCount: st.counts,
  });

  const s = openSheet({ full: true, title: 'Shift Summary', sub: 'Reconcile & close', body: html``, foot: html`` });

  function tabs() {
    return html`<div class="seg" style="margin-bottom:12px">
      ${[['review', 'This Shift'], ['report', 'Restaurant'], ['cash', 'Cash'], ['summary', 'Summary']].map(([k, v]) => html`<button class="${st.tab === k ? 'on' : ''}" data-tab="${k}">${v}</button>`)}</div>`;
  }
  const kv = (k, v, cls = '') => html`<div class="kv"><span class="k">${k}</span><span class="v num ${cls}">${v}</span></div>`;

  function review(sm) {
    return html`<div class="stack">
      <div class="card pad">
        ${kv('Total ticket sales', fmt(sm.totalSales))}
        ${kv('Cash sales', fmt(sm.cashSales))}
        ${kv('Card sales', fmt(sm.cardSales))}
        ${kv('Cash tips', fmt(sm.cashTips))}
        ${kv('Card tips', fmt(sm.cardTips))}
        ${kv('Total tips earned', fmt(sm.totalTips))}
        ${kv('Tip-outs', fmt(sm.tipouts))}
        ${kv('Tables / Checks', `${sm.tables} / ${sm.checks}`)}
        ${kv('Rounding adjustments', fmtSigned(sm.roundingAdj))}
        <div class="kv"><span class="k">Shift end</span><span class="v"><input class="input" style="height:38px;font-size:14px" type="datetime-local" data-end value="${toLocalInput(st.endedAt)}"></span></div>
        ${kv('Hours worked', (sm.hours).toFixed(2) + ' h')}
      </div>
      <div class="section-title">Settlement policy</div>
      <div class="card pad stack">
        <label class="field"><span>Cash collected by restaurant</span><select class="input" data-pol="collect">${Object.entries(POLICY_COLLECT).map(([k, v]) => html`<option value="${k}" ${st.policy.collect === k ? 'selected' : ''}>${v}</option>`)}</select></label>
        <label class="field"><span>Card tips</span><select class="input" data-pol="cardTips">${Object.entries(POLICY_CARD).map(([k, v]) => html`<option value="${k}" ${st.policy.cardTips === k ? 'selected' : ''}>${v}</option>`)}</select></label>
        <div class="field"><span>Custom adjustments to amount owed</span>
          ${[...(st.policy.adjustments || []).map(a => ({ ...a, standing: true })), ...st.adjustments].map((a, i) => html`<div class="kv"><span class="k">${a.label}${a.standing ? ' (default)' : ''}</span><span class="v num">${fmtSigned(a.cents)} ${a.standing ? '' : html`<button class="pill" data-deladj="${i - (st.policy.adjustments || []).length}">Remove</button>`}</span></div>`)}
          <div class="grid2" style="margin-top:6px;grid-template-columns:1.3fr 1fr auto"><input class="input" data-adj-label placeholder="Label" maxlength="40"><input class="input num" data-adj-amt inputmode="decimal" placeholder="± 0.00"><button class="btn sm" data-addadj>Add</button></div>
          <small class="muted" style="font-size:12px">Positive amounts increase what you owe; negative amounts reduce it.</small></div>
      </div>
      <div class="card pad" style="background:var(--brand-tint);border-color:var(--brand-tint-2)">
        <div class="kv"><span class="k">Cash ticket totals collected</span><span class="v num">${fmt((st.policy.collect === 'rounded' ? sm.cashDueRounded : sm.cashDueOriginal) - sm.refundsCash)}</span></div>
        ${st.policy.cardTips === 'deduct' ? kv('Card tips deducted', '−' + fmt(Math.max(0, sm.cardTips - (sm.cardTipsPaid - sm.cardTipsBySettlement)))) : ''}
        ${sm.tipoutsDeducted ? kv('Tip-outs paid by restaurant', '+' + fmt(sm.tipoutsDeducted)) : ''}
        ${sm.drops ? kv('Already paid during shift', '−' + fmt(sm.drops)) : ''}
        <div class="kv total"><span class="k">${sm.owed >= 0 ? 'Amount to pay restaurant' : 'Restaurant owes you'}</span><span class="v num">${fmt(Math.abs(sm.owed))}</span></div>
        <div class="kv"><span class="k">Expected physical cash</span><span class="v num">${fmt(sm.expectedCash)}</span></div>
        <div class="kv"><span class="k">Expected take-home cash</span><span class="v num pos">${fmt(sm.expectedTakeHome + (st.policy.cardTips === 'separate' ? (st.cardTipsCash | 0) : 0))}</span></div>
      </div>
    </div>`;
  }

  function report(sm) {
    const rows = compareReported(sm, st.reported);
    return html`<div class="stack">
      <p class="muted" style="margin:0;font-size:13.5px">Enter the figures from the restaurant's POS checkout report. Leave blank anything not shown.</p>
      <div class="card pad"><div class="grid2">
        ${REPORT_FIELDS.map(([k, label]) => html`<label class="field"><span>${label}</span><input class="input num" inputmode="decimal" data-rep="${k}" value="${Number.isSafeInteger(st.reported[k]) ? plain(st.reported[k]) : ''}" placeholder="—"></label>`)}
      </div></div>
      <div class="card pad">
        <table class="cmp"><thead><tr><th></th><th>Yours</th><th>Reported</th><th>Diff</th></tr></thead><tbody>
          ${rows.length ? rows.map(r => html`<tr><td>${r.label}<div class="muted" style="font-size:11.5px;font-weight:500">${describeDiff(r)}</div>
            ${r.diff ? explainDiff(r, S.checks, sm).map(h => html`<div class="warn" style="font-size:11.5px;font-weight:500">• ${h.text}</div>`) : ''}</td><td class="num">${fmt(r.tracked)}</td><td class="num">${fmt(r.reported)}</td>
            <td class="num ${r.diff ? (r.diff > 0 ? 'warn' : 'neg') : 'pos'}">${r.diff ? fmtSigned(r.diff) : '✓'}</td></tr>`) : html`<tr><td colspan="4" class="muted" style="text-align:center;padding:16px">Enter reported figures to compare.</td></tr>`}
        </tbody></table>
      </div>
      <div class="field"><span>Checkout report photo (optional)</span>${photoStrip(st.photoIds, true)}</div>
    </div>`;
  }

  function cash(sm) {
    const credited = st.policy.cardTips === 'deduct';
    const separate = st.policy.cardTips === 'separate';
    return html`<div class="stack">
      <div class="card pad">
        ${kv('Expected physical cash', fmt(sm.expectedCash))}
        <div class="kv"><span class="k">Counted cash (before paying)</span><span class="v"><button class="btn sm" data-act="count">${icon('coins', 'sm')} ${st.countedCash === null ? 'Count' : fmt(st.countedCash)}</button></span></div>
        <label class="field" style="margin-top:6px"><span>…or type counted total</span><input class="input num" inputmode="decimal" data-m="countedCash" value="${st.countedCash === null ? '' : plain(st.countedCash)}" placeholder="0.00"></label>
        ${st.countedCash !== null ? kv('Cash difference', st.countedCash === sm.expectedCash ? 'Balanced' : fmtSigned(st.countedCash - sm.expectedCash), st.countedCash === sm.expectedCash ? 'pos' : 'neg') : ''}
      </div>
      <div class="card pad stack">
        <div class="grid2">
          <label class="field"><span>I paid the restaurant</span><input class="input num" inputmode="decimal" data-m="paidToRestaurant" value="${st.paidToRestaurant === null ? '' : plain(st.paidToRestaurant)}" placeholder="${sm.owed > 0 ? plain(sm.owed) : '0.00'}"></label>
          <label class="field"><span>Restaurant paid me</span><input class="input num" inputmode="decimal" data-m="receivedFromRestaurant" value="${st.receivedFromRestaurant === null ? '' : plain(st.receivedFromRestaurant)}" placeholder="${sm.owed < 0 ? plain(-sm.owed) : '0.00'}"></label>
        </div>
        <button class="btn sm" data-act="paid-expected">Use expected ${fmt(Math.abs(sm.owed))}</button>
        ${credited ? html`<label class="field"><span>Card tips credited (deducted from what you owe)</span><input class="input num" inputmode="decimal" data-m="cardTipsCredited" value="${plain(st.cardTipsCredited | 0)}"></label>` : ''}
        ${separate ? html`<label class="field"><span>Card tips handed to you tonight (cash)</span><input class="input num" inputmode="decimal" data-m="cardTipsCash" value="${plain(st.cardTipsCash | 0)}"></label>` : ''}
        ${!credited && !separate ? html`<div class="banner info">${icon('calendar', 'sm')}<div>Card tips (${fmt(sm.cardTipsOutstanding)}) will stay <b>outstanding</b> until you mark them paid in Reports.</div></div>` : ''}
      </div>
      <div class="card pad">
        <label class="field"><span>Cash left after settling (optional count)</span><input class="input num" inputmode="decimal" data-m="countedAfter" value="${st.countedAfter === null ? '' : plain(st.countedAfter)}" placeholder="Expected ${plain(finalSummary(sm, settlementRec()).expectedAfter)}"></label>
      </div>
      <label class="field"><span>Reconciliation notes</span><textarea class="input" data-notes maxlength="1000" placeholder="Corrections, explanations, who you spoke with…">${st.notes}</textarea></label>
    </div>`;
  }

  function summary(sm) {
    const f = finalSummary(sm, settlementRec());
    return html`<div class="stack">
      <div class="card pad">
        ${kv('What you earned (tips)', fmt(f.earned), 'pos')}
        ${kv('Net tips after tip-outs', fmt(f.netTips))}
        ${kv('What you owe (calculated)', fmt(f.owesExpected))}
        ${f.owesReported !== null ? kv('What the restaurant says you owe', fmt(f.owesReported)) : ''}
        ${kv('What you actually paid', f.paidToRestaurant === null && f.receivedFromRestaurant === null ? 'Not entered' : fmt(f.paidToRestaurant || 0))}
        ${f.receivedFromRestaurant ? kv('Restaurant paid you', fmt(f.receivedFromRestaurant)) : ''}
        ${kv('Tip-outs', fmt(f.tipouts))}
        ${kv('Tips actually received', fmt(f.received))}
        ${kv('Personal starting cash returned', fmt(f.startingCashReturned))}
        ${kv('Outstanding card tips', fmt(f.cardTipsOutstanding), f.cardTipsOutstanding ? 'warn' : '')}
        <div class="kv total"><span class="k">Take-home cash</span><span class="v num">${f.takeHome === null ? fmt(f.expectedTakeHome) + ' (expected)' : fmt(f.takeHome)}</span></div>
        ${f.netTakeHomeIncome !== null ? kv('Take-home minus your starting cash', fmt(f.netTakeHomeIncome)) : ''}
        <div class="kv"><span class="k">Settlement status</span><span class="v ${f.status === 'balanced' ? 'pos' : 'warn'}">${f.status === 'balanced' ? 'Balanced' : 'Unresolved differences'}</span></div>
      </div>
      <div class="section-title">Unresolved discrepancies (${f.issues.length})</div>
      ${f.issues.length ? html`<div class="list">${f.issues.map(i => html`<div class="li">${icon('alert', 'sm')}<div class="grow"><div class="t">${i.label}</div><div class="s">${i.note}</div></div><span class="amt num ${i.cents < 0 ? 'neg' : 'warn'}">${fmtSigned(i.cents)}</span></div>`)}</div>
        <p class="muted" style="font-size:12.5px;margin:4px 2px 0">Differences are recorded as-is and never forced to balance. They may come from entry mistakes, rounding, timing or POS errors — not necessarily wrongdoing.</p>`
        : html`<div class="banner ok">${icon('check', 'sm')}<div>Everything you entered reconciles.</div></div>`}
    </div>`;
  }

  function draw() {
    const sm = calc(); defaults(sm);
    const views = { review, report, cash, summary };
    s.update(html`${tabs()}${views[st.tab](sm)}`);
    s.setFoot(st.tab === 'summary'
      ? html`<button class="btn primary lg block" data-close-shift>${icon('check', 'sm')} Close Shift</button>`
      : html`<button class="btn primary lg block" data-next>Continue</button>`);
  }

  function readInputs() {
    const end = s.body.querySelector('[data-end]'); if (end) { const t = fromLocalInput(end.value); if (t && t > sh.startedAt) st.endedAt = t; }
    s.body.querySelectorAll('[data-pol]').forEach(el => { st.policy = { ...st.policy, [el.dataset.pol]: el.value }; });
    s.body.querySelectorAll('[data-rep]').forEach(el => { const v = el.value.trim(); const c = toCents(v); if (v === '') delete st.reported[el.dataset.rep]; else if (!Number.isNaN(c)) st.reported[el.dataset.rep] = c; });
    s.body.querySelectorAll('[data-m]').forEach(el => { const v = el.value.trim(); const c = toCents(v); if (v === '') { if (['countedCash', 'countedAfter', 'paidToRestaurant', 'receivedFromRestaurant'].includes(el.dataset.m)) st[el.dataset.m] = null; else st[el.dataset.m] = 0; } else if (!Number.isNaN(c) && c >= 0) st[el.dataset.m] = c; });
    const n = s.body.querySelector('[data-notes]'); if (n) st.notes = n.value.slice(0, 1000);
  }

  s.body.addEventListener('change', e => {
    if (e.target.dataset.pol) { const was = st.policy.cardTips; readInputs(); if (was !== st.policy.cardTips) { st.cardTipsCredited = null; st.cardTipsCash = null; } draw(); }
    else if (e.target.matches('[data-rep],[data-m],[data-end]')) { readInputs(); draw(); }
  });
  s.body.addEventListener('click', async e => {
    const t = e.target;
    const tab = t.closest('[data-tab]'); if (tab) { readInputs(); st.tab = tab.dataset.tab; draw(); s.body.scrollTop = 0; return; }
    if (t.closest('[data-addadj]')) {
      const label = s.body.querySelector('[data-adj-label]').value.trim().slice(0, 40); const cents = toCents(s.body.querySelector('[data-adj-amt]').value);
      if (!label || Number.isNaN(cents) || !cents) return flash('Enter a label and an amount.');
      readInputs(); st.adjustments.push({ label, cents }); draw(); return;
    }
    const da = t.closest('[data-deladj]'); if (da) { st.adjustments.splice(+da.dataset.deladj, 1); draw(); return; }
    if (t.closest('[data-add-photo]')) { readInputs(); const id = await photoPicker({ kind: 'checkout', ref: { type: 'shift', id: sh.id } }); if (id) { st.photoIds.push(id); draw(); } return; }
    const act = t.closest('[data-act]')?.dataset.act;
    if (act === 'count') { readInputs(); openCashCounter({ expected: calc().expectedCash, saveLabel: 'Use this count', onSave: (c, note, counts) => { st.countedCash = c; st.counts = counts; draw(); } }); }
    if (act === 'paid-expected') { readInputs(); const o = calc().owed; st.paidToRestaurant = o > 0 ? o : 0; st.receivedFromRestaurant = o < 0 ? -o : 0; draw(); }
  });
  s.foot.addEventListener('click', async e => {
    readInputs();
    if (e.target.closest('[data-next]')) { const order = ['review', 'report', 'cash', 'summary']; st.tab = order[order.indexOf(st.tab) + 1]; draw(); s.body.scrollTop = 0; return; }
    if (e.target.closest('[data-close-shift]')) {
      const sm = calc(); const rec = settlementRec(); const f = finalSummary(sm, rec);
      if (store.onBreak()) { flash('End your break before closing the shift.'); return; }
      const ok = await confirmDialog({ title: 'Close this shift?', message: f.issues.length ? `${f.issues.length} discrepanc${f.issues.length === 1 ? 'y' : 'ies'} will be saved as unresolved. You can review the shift later in Reports.` : 'All figures reconcile. The shift will be saved to your history.', ok: 'Close shift' });
      if (!ok) return;
      rec.unresolved = f.issues.length;
      rec.snapshot = { totalTips: sm.totalTips, netTips: sm.netTips, owed: sm.owed, expectedCash: sm.expectedCash, totalSales: sm.totalSales };
      await store.closeShift(rec, st.endedAt);
      s.close(); flash('Shift closed and saved'); location.hash = '#reports';
    }
  });
  draw();
}
