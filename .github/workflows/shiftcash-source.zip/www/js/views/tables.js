// ShiftCash — transaction history (Tables tab) and the check detail view.
import { html, icon, openSheet, flash, promptDialog, confirmDialog, fmtTime, fmtDate, dayKey } from '../ui.js';
import { fmt, fmtSigned, computePayment, toCents } from '../money.js';
import { checkState } from '../ledger.js';
import * as store from '../store.js';
import { S } from '../store.js';
import * as db from '../db.js';
import { openEntry } from './entry.js';
import { moneyInput, readMoney } from './forms.js';
import { photoStrip, photoPicker } from './photos.js';
import { openIncident } from './shift.js';

const F = { scope: 'shift', filter: 'all', q: '' };
let allChecks = null, shiftsById = {};

export function title() { return { title: 'Tables', sub: F.scope === 'shift' ? "This shift's transactions" : 'All transaction history', search: true }; }

export async function load() {
  if (F.scope === 'all' || !S.shift) {
    allChecks = (await db.all('checks')).sort((a, b) => b.createdAt - a.createdAt);
    shiftsById = Object.fromEntries((await db.all('shifts')).map(s => [s.id, s]));
  }
}

function isAdjustment(c, st) {
  return !!(c.discountCents || c.compCents || st.refunds || (c.history || []).some(h => h.action === 'edit' || h.action === 'edit-payment' || h.action === 'void-payment')
    || st.payments.some(p => p.c.method === 'cash' && p.c.roundingAdj));
}
function matches(c, st) {
  switch (F.filter) {
    case 'cash': return !c.voided && st.kind === 'cash';
    case 'card': return !c.voided && st.kind === 'card';
    case 'split': return !c.voided && st.kind === 'split';
    case 'disc': return !c.voided && st.flags.length > 0;
    case 'void': return !!c.voided || (c.payments || []).some(p => p.voided);
    case 'adj': return isAdjustment(c, st);
    default: return true;
  }
}

export function txRow(c) {
  const st = checkState(c);
  const tip = st.payments.reduce((a, p) => a + (p.c.tip || 0) + (p.c.cashTip || 0), 0);
  const kind = { cash: 'Cash', card: 'Card', split: 'Split', open: 'Unpaid' }[st.kind];
  return html`<button class="li txrow" data-check="${c.id}">
    <span class="tbl-badge">${c.table}</span>
    <div class="grow ${c.voided ? 'void' : ''}"><div class="t num">${fmt(c.ticketCents)} <span class="muted" style="font-weight:500;font-size:13px">· ${kind}</span></div>
      <div class="s">${fmtTime(c.createdAt)}${c.ticketNo ? ' · #' + c.ticketNo : ''}${c.notes ? ' · ' + c.notes : ''}</div>
      ${c.voided || st.flags.length ? html`<div class="flags">${c.voided ? html`<span class="pill neg">Void</span>` : ''}
        ${st.flags.includes('unconfirmed') ? html`<span class="pill warn">Unconfirmed cash</span>` : ''}
        ${st.flags.includes('overchange') ? html`<span class="pill neg">Over-change</span>` : ''}
        ${st.flags.includes('balance') ? html`<span class="pill warn">Balance ${fmt(st.balance)}</span>` : ''}
        ${st.flags.includes('walkout') ? html`<span class="pill neg">Walkout</span>` : ''}
        ${st.flags.includes('tip_pending') ? html`<span class="pill info">Tip at POS</span>` : ''}
        ${st.flags.includes('tip_disputed') ? html`<span class="pill warn">Tip disputed</span>` : ''}
        ${st.refunds ? html`<span class="pill info">Refund</span>` : ''}</div>` : ''}</div>
    <span class="amt num pos ${c.voided ? 'void' : ''}">${st.flags.includes('tip_pending') && !tip ? '—' : fmt(tip)}</span>
    <span class="chev">${icon('chev', 'sm')}</span></button>`;
}

export function render() {
  const source = F.scope === 'shift' && S.shift ? [...S.checks].reverse() : (allChecks || []);
  const q = F.q.trim().toLowerCase();
  const states = new Map(source.map(c => [c.id, checkState(c)]));
  const searched = source.filter(c => !q || String(c.table).toLowerCase() === q || [c.table, c.ticketNo, c.notes, (c.ticketCents / 100).toFixed(2)].some(v => String(v || '').toLowerCase().includes(q)));
  const counts = { all: searched.length };
  for (const k of ['cash', 'card', 'split', 'disc', 'void', 'adj']) { const o = F.filter; F.filter = k; counts[k] = searched.filter(c => matches(c, states.get(c.id))).length; F.filter = o; }
  const list = searched.filter(c => matches(c, states.get(c.id)));
  const groups = [];
  for (const c of list) {
    const key = F.scope === 'shift' ? 'shift' : dayKey(c.createdAt) + '|' + c.shiftId;
    let g = groups.find(x => x.key === key);
    if (!g) groups.push(g = { key, label: F.scope === 'shift' ? '' : `${fmtDate(c.createdAt)} · shift ${shiftsById[c.shiftId] ? fmtTime(shiftsById[c.shiftId].startedAt) : ''}`, items: [] });
    g.items.push(c);
  }
  const live = list.filter(c => !c.voided);
  const totSales = live.reduce((a, c) => a + states.get(c.id).applied - states.get(c.id).refunds, 0);
  const totTips = live.reduce((a, c) => a + states.get(c.id).payments.reduce((x, p) => x + (p.c.tip || 0) + (p.c.cashTip || 0), 0), 0);
  const chip = (k, label) => html`<button class="chip ${F.filter === k ? 'on' : ''}" data-filter="${k}">${label} <span class="n">${counts[k]}</span></button>`;
  return html`
    ${S.shift ? html`<div class="seg" style="margin-bottom:10px"><button class="${F.scope === 'shift' ? 'on' : ''}" data-scope="shift">This shift</button><button class="${F.scope === 'all' ? 'on' : ''}" data-scope="all">All history</button></div>` : ''}
    <div class="search"><svg class="i sm"><use href="#i-search"/></svg><input class="input" type="search" placeholder="Search table, ticket #, amount, note" value="${F.q}" data-q maxlength="40"></div>
    <div class="chips" style="margin-top:10px">${chip('all', 'All')}${chip('cash', 'Cash')}${chip('card', 'Card')}${chip('split', 'Split')}${chip('disc', 'Discrepancy')}${chip('void', 'Voided')}${chip('adj', 'Adjusted')}</div>
    ${list.length ? groups.map(g => html`${g.label ? html`<div class="group-h"><span>${g.label}</span><span>${g.items.length}</span></div>` : html`<div style="height:10px"></div>`}
      <div class="list">${g.items.slice(0, 300).map(txRow)}</div>`) : html`<div class="card empty" style="margin-top:10px">${icon('search')}<div>No transactions match.</div></div>`}
    ${list.length ? html`<div class="row between muted" style="font-size:13px;padding:12px 4px">
      <span>Checks: ${live.length}</span><span>Sales: ${fmt(totSales)}</span><span>Tips: ${fmt(totTips)}</span></div>` : ''}`;
}

export function mount(root, rerender) {
  root.addEventListener('click', async e => {
    const c = e.target.closest('[data-check]'); if (c) return openCheckDetail(c.dataset.check);
    const f = e.target.closest('[data-filter]'); if (f) { F.filter = f.dataset.filter; return rerender(); }
    const sc = e.target.closest('[data-scope]'); if (sc) { F.scope = sc.dataset.scope; await load(); return rerender(); }
  });
  let t;
  root.addEventListener('input', e => {
    if (!e.target.matches('[data-q]')) return;
    F.q = e.target.value; clearTimeout(t);
    t = setTimeout(() => { const pos = e.target.selectionStart; rerender(); const i = document.querySelector('[data-q]'); if (i) { i.focus(); i.setSelectionRange(pos, pos); } }, 200);
  });
}

// ---------- check detail ----------
export async function openCheckDetail(id) {
  let c = await db.get('checks', id); if (!c) return;
  const s = openSheet({ title: `Table ${c.table}`, sub: `${fmtDate(c.createdAt)} · ${fmtTime(c.createdAt)}`, body: html`` });
  const active = () => S.shift && S.shift.id === c.shiftId;
  const draw = () => {
    const st = checkState(c);
    s.update(html`<div class="stack">
      ${c.voided ? html`<div class="banner neg">${icon('alert', 'sm')}<div><b>Voided.</b> ${c.voidReason || ''}</div></div>` : ''}
      ${c.walkout ? html`<div class="banner warn">${icon('alert', 'sm')}<div><b>Walkout.</b> ${fmt(st.balance)} unpaid. It is not counted as a sale or as missing cash.</div></div>` : ''}
      <div class="card pad">
        <div class="kv"><span class="k">Original ticket</span><span class="v num">${fmt(c.ticketCents)}</span></div>
        ${c.discountCents ? html`<div class="kv"><span class="k">Discount</span><span class="v num">−${fmt(c.discountCents)}</span></div>` : ''}
        ${c.compCents ? html`<div class="kv"><span class="k">Comp</span><span class="v num">−${fmt(c.compCents)}</span></div>` : ''}
        <div class="kv"><span class="k">Amount due</span><span class="v num">${fmt(st.netDue)}</span></div>
        <div class="kv"><span class="k">Paid</span><span class="v num">${fmt(st.applied)}</span></div>
        ${st.refunds ? html`<div class="kv"><span class="k">Refunded</span><span class="v num neg">−${fmt(st.refunds)}</span></div>` : ''}
        <div class="kv total"><span class="k">Balance</span><span class="v num ${st.balance > 0 ? 'warn' : ''}">${fmt(st.balance)}</span></div>
        <div class="kv"><span class="k">Ticket # · Segment</span><span class="v">${c.ticketNo || '—'} · ${c.segment === 'lunch' ? 'Lunch' : 'Dinner'}</span></div>
        ${c.notes ? html`<div class="kv"><span class="k">Notes</span><span class="v" style="font-weight:500">${c.notes}</span></div>` : ''}
      </div>
      <div class="section-title">Payments</div>
      ${(c.payments || []).map(p => paymentCard(p))}
      ${!c.voided ? html`<div class="grid2">
        ${st.balance > 0 ? html`<button class="btn sm" data-a="add-pay">${icon('plus', 'sm')} Add payment</button>` : ''}
        <button class="btn sm" data-a="refund">${icon('undo', 'sm')} Refund</button>
        <button class="btn sm" data-a="edit">${icon('edit', 'sm')} Correct</button>
        <button class="btn sm" data-a="incident">${icon('flag', 'sm')} Incident</button>
        ${st.balance > 0 && !c.walkout ? html`<button class="btn sm danger" data-a="walkout">${icon('alert', 'sm')} Walkout</button>` : ''}
      </div>` : ''}
      <div class="field"><span>Photos</span>${photoStrip(c.photoIds, true)}</div>
      ${(c.history || []).length ? html`<div class="section-title">Change history</div>
        <div class="list">${[...c.history].reverse().map(h => html`<div class="li"><div class="grow"><div class="t">${h.action.replace('-', ' ')}</div>
          <div class="s">${fmtDate(h.at)} ${fmtTime(h.at)} · ${h.reason || ''}</div>
          ${h.before && h.action === 'edit' ? html`<div class="s faint">Before: table ${h.before.table}, ticket ${fmt(h.before.ticketCents)}${h.before.discountCents ? ', discount ' + fmt(h.before.discountCents) : ''}${h.before.notes ? ', note "' + h.before.notes + '"' : ''}</div>` : ''}</div></div>`)}</div>` : ''}
      <div class="btnrow">${c.voided
        ? html`<button class="btn" data-a="unvoid">Restore check</button>`
        : html`<button class="btn danger" data-a="void">Void check</button>`}</div>
      <p class="faint" style="font-size:11.5px;margin:0">History is a local record kept on this device. It is not tamper-proof.</p>
    </div>`);
  };
  const paymentCard = p => {
    const x = computePayment(p);
    if (!x) return '';
    const rows = [];
    if (x.method === 'cash') {
      rows.push(['Original amount', fmt(x.due)], ['Rounded payable', fmt(x.roundedDue)], ['Cash received', fmt(x.received)], ['Expected change', fmt(x.expectedChange)],
        ['Change returned', fmt(x.changeGiven)], ['Rounding adjustment', fmtSigned(x.roundingAdj)], ['Confirmed cash tip', x.tipPending ? 'Enter at POS' : fmt(x.cashTip)]);
      if (x.unconfirmed) rows.push(['Unconfirmed excess', fmt(x.unconfirmed)]);
      if (x.shortage) rows.push(['Cash shortage', '−' + fmt(x.shortage)]);
    } else if (x.method === 'card') {
      rows.push(['Amount', fmt(x.due)], ['Card tip', x.tipStatus === 'pending' ? 'Not entered yet' : fmt(x.tip)], ['Tip status', { pending: 'Waiting for receipt', entered: 'Entered (not yet received)', confirmed: 'Confirmed on receipt/POS', disputed: 'Disputed' }[x.tipStatus]], ['Final card payment', fmt(x.charge)]);
      if (x.extraCashTip) rows.push(['Additional cash tip', fmt(x.extraCashTip)]);
      if (p.receipt) rows.push(['Receipt ref', p.receipt]);
    } else rows.push(['Refund via ' + x.via, '−' + fmt(x.amount)]);
    return html`<div class="card pad ${p.voided ? 'void' : ''}">
      <div class="row between"><b class="row">${icon(x.method === 'card' ? 'card' : x.method === 'cash' ? 'cash' : 'undo', 'sm')} ${x.method === 'refund' ? 'Refund' : x.method === 'cash' ? 'Cash' : 'Card'}</b>
        <span class="muted" style="font-size:12.5px">${p.createdAt ? fmtTime(p.createdAt) : ''}${p.voided ? ' · voided' : ''}</span></div>
      <div class="breakdown" style="border:0;padding:4px 0 0">${rows.map(([k, v]) => html`<div class="kv"><span class="k">${k}</span><span class="v num">${v}</span></div>`)}</div>
      ${!p.voided && !c.voided ? html`<div class="btnrow" style="margin-top:8px">
        ${x.method === 'cash' && x.unconfirmed ? html`<button class="btn sm" data-confirm-tip="${p.id}">Confirm ${fmt(x.unconfirmed)} as tip</button>` : ''}
        ${x.method !== 'refund' ? html`<button class="btn sm" data-tip-edit="${p.id}">${x.tipStatus === 'pending' || x.tipPending ? 'Enter tip' : 'Add/adjust tip'}</button>` : ''}
        ${x.method === 'card' && x.tipStatus !== 'pending' ? html`<button class="btn sm" data-tip-status="${p.id}">Tip status</button>` : ''}
        <button class="btn sm danger" data-void-pay="${p.id}">Void</button></div>` : ''}
    </div>`;
  };
  const refresh = async () => { c = await db.get('checks', id); draw(); };

  s.body.addEventListener('click', async e => {
    const t = e.target;
    if (t.closest('[data-add-photo]')) { const pid = await photoPicker({ kind: 'receipt', ref: { type: 'check', id } }); if (pid) { await store.addCheckPhoto(id, pid); await refresh(); } return; }
    const ct = t.closest('[data-confirm-tip]');
    if (ct) {
      const p = c.payments.find(x => x.id === ct.dataset.confirmTip); const x = computePayment(p);
      await store.patchPayment(id, p.id, { keptTip: (p.keptTip | 0) + x.unconfirmed }, 'Customer confirmed kept change as tip'); await refresh(); flash('Confirmed as tip'); return;
    }
    const te = t.closest('[data-tip-edit]'); if (te) return editTip(c, c.payments.find(x => x.id === te.dataset.tipEdit), refresh);
    const ts = t.closest('[data-tip-status]');
    if (ts) {
      const p = c.payments.find(x => x.id === ts.dataset.tipStatus);
      const ss = openSheet({ title: 'Card tip status', body: html`<div class="list">${[['entered', 'Entered — not yet confirmed'], ['confirmed', 'Confirmed on signed receipt / POS'], ['disputed', 'Disputed / possibly wrong']].map(([k, v]) => html`<button class="li" data-st="${k}"><span class="grow t">${v}</span>${(p.tipStatus || 'entered') === k ? icon('check') : ''}</button>`)}</div>
        <p class="muted" style="font-size:12.5px">Whether the tip has been <b>paid</b> to you is tracked separately (settlement, payroll or cash payouts).</p>` });
      ss.body.addEventListener('click', async ev => { const b = ev.target.closest('[data-st]'); if (!b) return; await store.patchPayment(id, p.id, { tipStatus: b.dataset.st }, 'Tip status: ' + b.dataset.st); ss.close(); await refresh(); });
      return;
    }
    const vp = t.closest('[data-void-pay]');
    if (vp) { const reason = await promptDialog({ title: 'Void payment', label: 'Reason (kept in history)', ok: 'Void payment' }); if (reason) { await store.voidPayment(id, vp.dataset.voidPay, reason); await refresh(); } return; }
    switch (t.closest('[data-a]')?.dataset.a) {
      case 'add-pay': if (!active()) return flash('Payments can only be added to checks in the active shift.'); s.close(); openEntry({ check: c }); break;
      case 'refund': refund(c, refresh); break;
      case 'edit': editCheck(c, refresh); break;
      case 'incident': openIncident(null, { table: c.table, checkId: c.id }); break;
      case 'walkout': {
        const reason = await promptDialog({ title: 'Customer walkout', label: 'What happened? (optional details)', required: false, ok: 'Mark walkout' });
        if (reason === null) return;
        const bal = checkState(c).balance;
        await store.editCheck(id, { walkout: true }, 'Walkout' + (reason ? ': ' + reason : ''));
        await store.saveIncident({ type: 'walkout', table: c.table, checkId: c.id, amount: bal, description: reason || 'Customer left without paying', shiftId: c.shiftId });
        await refresh(); flash('Marked as walkout and logged as an incident'); break;
      }
      case 'void': { const reason = await promptDialog({ title: 'Void check', label: 'Reason (the check stays in history)', ok: 'Void check' }); if (reason) { await store.voidCheck(id, reason); await refresh(); flash('Check voided'); } break; }
      case 'unvoid': { const reason = await promptDialog({ title: 'Restore check', label: 'Reason', ok: 'Restore' }); if (reason) { await store.unvoidCheck(id, reason); await refresh(); } break; }
    }
  });
  draw();
}

function editCheck(c, done) {
  const s = openSheet({
    title: 'Correct check', body: html`<div class="stack">
      <label class="field"><span>Table #</span><input class="input" data-f="table" maxlength="6" value="${c.table}"></label>
      ${moneyInput('ticket', 'Ticket total', c.ticketCents)}
      <div class="grid2">${moneyInput('discount', 'Discount', c.discountCents || null)}${moneyInput('comp', 'Comp', c.compCents || null)}</div>
      <label class="field"><span>Ticket #</span><input class="input" data-f="ticketNo" maxlength="20" value="${c.ticketNo || ''}"></label>
      <label class="field"><span>Segment</span><select class="input" data-f="segment"><option value="lunch" ${c.segment === 'lunch' ? 'selected' : ''}>Lunch</option><option value="dinner" ${c.segment !== 'lunch' ? 'selected' : ''}>Dinner</option></select></label>
      <label class="field"><span>Notes</span><input class="input" data-f="notes" maxlength="200" value="${c.notes || ''}"></label>
      <p class="muted" style="font-size:12.5px;margin:0">To change a payment, void it and add a corrected one. Previous values are always kept.</p></div>`,
    foot: html`<button class="btn primary block">Save correction</button>`,
  });
  s.foot.addEventListener('click', async () => {
    const f = k => s.body.querySelector(`[data-f="${k}"]`).value.trim();
    const ticketCents = readMoney(s.body, 'ticket'), discountCents = readMoney(s.body, 'discount', 0), compCents = readMoney(s.body, 'comp', 0);
    if ([ticketCents, discountCents, compCents].some(v => v === null || Number.isNaN(v) || v < 0) || !f('table')) return flash('Check the values entered.');
    const reason = await promptDialog({ title: 'Reason for correction', label: 'Why is this being changed?', placeholder: 'e.g. typed wrong ticket total' });
    if (!reason) return;
    await store.editCheck(c.id, { table: f('table').slice(0, 6), ticketCents, discountCents, compCents, ticketNo: f('ticketNo'), segment: f('segment') === 'lunch' ? 'lunch' : 'dinner', notes: f('notes') }, reason);
    s.close(); flash('Correction saved'); done();
  });
}

function refund(c, done) {
  let via = 'cash';
  const s = openSheet({
    title: 'Record refund', body: html`<div class="stack">${moneyInput('amount', 'Refund amount', null)}
      <div class="seg"><button class="on" data-via="cash">Cash from my apron</button><button data-via="card">Back to card</button></div></div>`,
    foot: html`<button class="btn primary block">Save refund</button>`,
  });
  s.body.addEventListener('click', e => { const b = e.target.closest('[data-via]'); if (b) { via = b.dataset.via; s.body.querySelectorAll('[data-via]').forEach(x => x.classList.toggle('on', x === b)); } });
  s.foot.addEventListener('click', async () => {
    const amount = readMoney(s.body, 'amount');
    if (!amount || Number.isNaN(amount) || amount <= 0) return flash('Enter an amount.');
    const reason = await promptDialog({ title: 'Refund reason', label: 'Reason', ok: 'Save' }); if (!reason) return;
    await store.addPayment(c.id, { method: 'refund', via, amount }, 'Refund: ' + reason);
    s.close(); flash('Refund recorded'); done();
  });
}

function editTip(c, p, done) {
  const isCash = p.method === 'cash';
  const s = openSheet({
    title: isCash ? 'Cash tip' : 'Card tip', body: html`<div class="stack">
      ${isCash ? moneyInput('extra', 'Additional cash tip left after change', p.extraTip || 0) : moneyInput('tip', 'Card tip', p.tip ?? null)}
      ${!isCash ? moneyInput('extra', 'Additional cash tip', p.extraCashTip || 0) : ''}
      <p class="muted" style="font-size:12.5px;margin:0">The payment itself is not counted again — only the tip changes.</p></div>`,
    foot: html`<button class="btn primary block">Save</button>`,
  });
  s.foot.addEventListener('click', async () => {
    const extra = readMoney(s.body, 'extra', 0), tip = isCash ? null : readMoney(s.body, 'tip', null);
    if (!isCash && tip === null) return flash('Enter the card tip (0 for no tip).');
    if (Number.isNaN(extra) || extra < 0 || (tip !== null && (Number.isNaN(tip) || tip < 0))) return flash('Check the amounts.');
    const patch = isCash ? { extraTip: extra, tipPending: false } : { tip, extraCashTip: extra, tipStatus: p.tipStatus === 'pending' || !p.tipStatus ? 'entered' : p.tipStatus };
    await store.patchPayment(c.id, p.id, patch, 'Tip updated'); s.close(); flash('Tip updated'); done();
  });
}

export { toCents };
