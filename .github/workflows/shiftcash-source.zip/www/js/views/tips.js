// ShiftCash — "Enter tips" queue: tables saved with "Enter at POS" get their tip here, one after another.
import { html, icon, openSheet, flash, fmtTime, $ } from '../ui.js';
import { fmt, keypadAppend, keypadBackspace, computePayment } from '../money.js';
import { S, patchPayment } from '../store.js';
import { haptic } from '../native.js';

/** Every payment in the active shift that is still waiting for its tip. */
export function pendingTips(checks = S.checks) {
  const out = [];
  for (const c of checks) {
    if (c.voided) continue;
    for (const p of c.payments || []) {
      if (p.voided) continue;
      const x = computePayment(p); if (!x) continue;
      if ((x.method === 'cash' && x.tipPending) || (x.method === 'card' && x.tipStatus === 'pending')) out.push({ check: c, pay: p, x });
    }
  }
  return out.sort((a, b) => (a.pay.createdAt || a.check.createdAt) - (b.pay.createdAt || b.check.createdAt));
}

export function openTipQueue(startKey = null) {
  let list = pendingTips();
  if (!list.length) { flash('No tips waiting to be entered.'); return; }
  let idx = Math.max(0, startKey ? list.findIndex(i => i.pay.id === startKey) : 0);
  let cents = 0, saving = false, done = 0;
  const s = openSheet({
    full: true, title: 'Enter tips', sub: 'From the POS / table', body: html``,
    after: html`<div class="keypad" id="tkp">
      ${[1, 2, 3].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="bs" class="k-act" aria-label="Backspace">⌫</button>
      ${[4, 5, 6].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="none" class="k-act">No tip</button>
      ${[7, 8, 9].map(n => html`<button data-k="${n}">${n}</button>`)}<button data-k="save" class="k-save" id="tkSave">Save tip</button>
      <button data-k="clr" class="k-act">C</button><button data-k="0">0</button><button data-k="00">00</button>
    </div>`,
  });

  const draw = () => {
    if (!list.length) {
      s.update(html`<div class="stack" style="text-align:center;padding-top:30px">
        <div class="change-card keep"><div class="lbl">All caught up</div><div class="amt">${done} tip${done === 1 ? '' : 's'} entered</div><div class="sub">Your totals are updated.</div></div>
        <button class="btn primary lg block" data-sheet-close>Done</button></div>`);
      $('#tkp', s.el).classList.add('hidden');
      return;
    }
    const cur = list[idx];
    const { check: c, x } = cur;
    const isCash = x.method === 'cash';
    s.update(html`<div class="stack">
      <div class="card pad">
        <div class="row between"><div class="row"><span class="tbl-badge">${c.table}</span><div><b>${isCash ? 'Cash' : 'Card'} · bill ${fmt(c.ticketCents)}</b>
          <div class="muted" style="font-size:12.5px">${fmtTime(cur.pay.createdAt || c.createdAt)}${isCash ? ` · paid ${fmt(x.received)}, change ${fmt(x.changeGiven)}` : ` · card ${fmt(x.due)}`}</div></div></div>
          <span class="pill">${idx + 1} of ${list.length}</span></div>
      </div>
      <div class="money-field xl active"><span class="lbl">${isCash ? 'Cash they left on the table' : 'Tip written on the card slip'}</span><span class="val num">${fmt(cents)}</span></div>
      ${!isCash && x.due ? html`<div class="muted" style="font-size:13px;text-align:center">${(cents / x.due * 100).toFixed(1)}% of ${fmt(x.due)} · card total ${fmt(x.due + cents)}</div>` : ''}
      ${list.length > 1 ? html`<div class="section-title">Waiting</div>
        <div class="list">${list.map((i, n) => html`<button class="li" data-go="${n}" style="${n === idx ? 'background:var(--brand-tint)' : ''}"><span class="tbl-badge">${i.check.table}</span>
          <div class="grow"><div class="t">${i.x.method === 'cash' ? 'Cash' : 'Card'} · ${fmt(i.check.ticketCents)}</div><div class="s">${fmtTime(i.pay.createdAt || i.check.createdAt)}</div></div></button>`)}</div>` : ''}
    </div>`);
    $('#tkSave', s.el).textContent = saving ? '…' : 'Save tip';
  };

  async function save(amount) {
    if (saving || !list.length) return;
    saving = true; draw();
    const { check: c, pay: p, x } = list[idx];
    try {
      const patch = x.method === 'cash' ? { extraTip: amount, tipPending: false } : { tip: amount, tipStatus: 'entered' };
      await patchPayment(c.id, p.id, patch, amount ? 'Tip entered at POS' : 'No tip (entered at POS)');
      done++;
      flash(`Table ${c.table}: ${amount ? 'tip ' + fmt(amount) : 'no tip'} saved`);
    } finally {
      saving = false;
      list = pendingTips(); idx = Math.min(idx, Math.max(0, list.length - 1)); cents = 0; draw();
    }
  }

  $('#tkp', s.el).addEventListener('click', e => {
    const k = e.target.closest('[data-k]')?.dataset.k; if (!k) return;
    if (S.settings.haptics) haptic(6);
    if (k === 'save') return save(cents);
    if (k === 'none') return save(0);
    if (k === 'bs') cents = keypadBackspace(cents);
    else if (k === 'clr') cents = 0;
    else if (k === '00') cents = keypadAppend(keypadAppend(cents, 0), 0);
    else cents = keypadAppend(cents, +k);
    draw();
  });
  s.body.addEventListener('click', e => { const g = e.target.closest('[data-go]'); if (g) { idx = +g.dataset.go; cents = 0; draw(); } });
  draw();
}
