// ShiftCash — Shift management, cash ledger, cash counting and incidents.
import { html, icon, openSheet, flash, promptDialog, confirmDialog, fmtTime, fmtDur, fmtDate, toLocalInput, fromLocalInput } from '../ui.js';
import { fmt } from '../money.js';
import { MOVE_TYPES, DENOMINATIONS, countCash, tipoutAmount } from '../ledger.js';
import * as store from '../store.js';
import { S } from '../store.js';
import * as db from '../db.js';
import { moneyInput, readMoney, readText } from './forms.js';
import { openSettle } from './settle.js';
import { openShiftSummary, confirmDelete } from './reports.js';
import { photoPicker, photoStrip } from './photos.js';
import { pendingTips, openTipQueue } from './tips.js';

export function title() {
  return { title: 'Shift', sub: S.shift ? `Since ${fmtTime(S.shift.startedAt)} · ${fmtDate(S.shift.startedAt)}` : 'Start, track & reconcile' };
}

let history = [];
export async function load() {
  history = (await db.all('shifts')).filter(s => s.status === 'closed').sort((a, b) => b.startedAt - a.startedAt).slice(0, 15);
}

export function render() {
  const sh = S.shift, s = S.summary;
  if (!sh) {
    return html`
      <div class="card pad stack">
        <div style="font-size:18px;font-weight:700">Start a new shift</div>
        ${moneyInput('startingCash', 'Starting personal cash (your own money in the apron)', S.settings.startingBank || 0)}
        ${moneyInput('wage', 'Hourly wage (optional)', S.settings.hourlyWage || null)}
        <div class="seg" data-seg><button class="${store.segmentFor() === 'lunch' ? 'on' : ''}" data-segv="lunch">Lunch</button><button class="${store.segmentFor() === 'dinner' ? 'on' : ''}" data-segv="dinner">Dinner</button></div>
        <button class="btn primary lg block" data-act="start">${icon('play', 'sm')} Start Shift</button>
      </div>
      ${historyList()}`;
  }
  const paused = store.onBreak();
  return html`
    <div class="card pad">
      <div class="row between"><b style="font-size:16px">${paused ? 'On break' : 'Working'}</b><b class="num">${fmtDur(s.workedMs)} worked</b></div>
      <div class="kv" style="margin-top:8px"><span class="k">Started</span><span class="v">${fmtTime(sh.startedAt)} <button class="pill" data-act="edit-times">${icon('edit', 'xs')} Edit</button></span></div>
      <div class="kv"><span class="k">Breaks</span><span class="v">${sh.breaks.length} · ${fmtDur(s.breakMs)}</span></div>
      <div class="kv"><span class="k">Hourly wage</span><span class="v">${sh.hourlyWage ? fmt(sh.hourlyWage) : '—'}</span></div>
      <div class="seg" style="margin-top:10px"><button class="${sh.segment === 'lunch' ? 'on' : ''}" data-act="seg-lunch">Lunch</button><button class="${sh.segment === 'dinner' ? 'on' : ''}" data-act="seg-dinner">Dinner</button></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn sm" data-act="break">${icon(paused ? 'play' : 'coffee', 'sm')} ${paused ? 'End break' : 'Unpaid break'}</button>
        ${paused ? '' : html`<button class="btn sm" data-act="paid-break">${icon('coffee', 'sm')} Paid break</button>`}
      </div>
    </div>

    <div class="section-title">Cash on hand</div>
    <div class="card pad">
      <div class="row between"><span class="muted">Expected physical cash</span><b class="num" style="font-size:26px">${fmt(s.expectedCash)}</b></div>
      <div class="row between" style="margin-top:4px"><span class="muted">Earned income (net tips)</span><b class="num pos">${fmt(s.netTips)}</b></div>
      <div style="margin-top:10px">
        ${kv('Starting personal cash', s.startingCash)}
        ${kv('Cash payments received', s.cashReceived)}
        ${kv('Change returned', -s.changeGiven)}
        ${kv('Additional cash tips', s.cashTipsExtra)}
        ${s.refundsCash ? kv('Cash refunds', -s.refundsCash) : ''}
        ${s.tipoutsCash ? kv('Tip-outs paid in cash', -s.tipoutsCash) : ''}
        ${s.withdrawn ? kv('Removed from apron', -s.withdrawn) : ''}
        ${s.added ? kv('Added to apron', s.added) : ''}
        ${s.drops ? kv('Paid to restaurant', -s.drops) : ''}
        ${s.cardTipsPaidCashInApron ? kv('Card tips received in cash', s.cardTipsPaidCashInApron) : ''}
        ${s.otherIn || s.otherOut ? kv('Other movements', s.otherIn - s.otherOut) : ''}
        <div class="kv sub"><span class="k">Includes rounding adjustments</span><span class="v num">${fmt(s.roundingAdj)}</span></div>
      </div>
      <div class="grid3" style="margin-top:12px">
        <button class="btn sm" data-move="tipout">Tip-out</button>
        <button class="btn sm" data-move="withdraw">Remove</button>
        <button class="btn sm" data-move="add">Add cash</button>
        <button class="btn sm" data-move="drop">Pay rest.</button>
        <button class="btn sm" data-act="cardtip-cash">Card tips $</button>
        <button class="btn sm" data-move="other">Other</button>
      </div>
      ${(S.settings.tipoutRules || []).length ? html`<div class="chips" style="margin-top:10px;flex-wrap:wrap">${S.settings.tipoutRules.map(r => html`<button class="chip soft" data-rule="${r.id}">Tip-out ${r.name}: ${fmt(tipoutAmount(r, s))}</button>`)}</div>` : ''}
      <button class="btn block" style="margin-top:10px" data-act="count">${icon('coins', 'sm')} Count cash (mid-shift check)</button>
    </div>

    ${S.moves.length || (sh.counts || []).length || S.payouts.length ? html`
      <div class="section-title">Cash ledger</div>
      <div class="list">
        ${S.moves.map(m => html`<button class="li" data-move-id="${m.id}">
          <div class="grow ${m.voided ? 'void' : ''}"><div class="t">${MOVE_TYPES[m.type]?.label || m.type}${m.type === 'tipout' && m.via === 'deducted' ? ' (deducted by restaurant)' : ''}</div><div class="s">${fmtTime(m.createdAt)}${m.note ? ' · ' + m.note : ''}${m.voided ? ' · voided: ' + m.voidReason : ''}</div></div>
          <span class="amt num ${m.voided ? 'void' : ''}">${MOVE_TYPES[m.type]?.sign < 0 ? '−' : '+'}${fmt(m.amount)}</span></button>`)}
        ${S.payouts.map(p => html`<div class="li"><div class="grow ${p.voided ? 'void' : ''}"><div class="t">Card tips paid · ${p.via}</div><div class="s">${fmtTime(p.at)}${p.note ? ' · ' + p.note : ''}</div></div><span class="amt num">${fmt(p.amount)}</span></div>`)}
        ${(sh.counts || []).map(c => html`<div class="li">${icon('coins', 'sm')}<div class="grow"><div class="t">Cash count</div><div class="s">${fmtTime(c.at)} · expected ${fmt(c.expected)}${c.note ? ' · ' + c.note : ''}</div></div>
          <span class="amt num ${c.counted - c.expected ? (c.counted > c.expected ? 'pos' : 'neg') : ''}">${fmt(c.counted)}<br><small>${c.counted === c.expected ? 'balanced' : (c.counted > c.expected ? '+' : '−') + fmt(Math.abs(c.counted - c.expected))}</small></span></div>`)}
      </div>` : ''}

    <div class="section-title">Incidents <button data-act="incident">+ Log incident</button></div>
    ${S.incidents.length ? html`<div class="list">${S.incidents.map(i => incidentRow(i))}</div>` : html`<div class="card pad muted" style="font-size:14px">No incidents. Log disputed payments, walkouts, wrong change or missing tips here.</div>`}

    ${pendingTips().length ? html`<button class="btn lg block" style="margin-top:18px" data-act="tips">${icon('cash', 'sm')} Enter ${pendingTips().length} waiting tip${pendingTips().length > 1 ? 's' : ''} first</button>` : ''}
    <button class="btn primary lg block" style="margin-top:${pendingTips().length ? 10 : 18}px" data-act="settle">${icon('scale', 'sm')} End Shift & Settle</button>
    <button class="btn ghost block danger" style="margin-top:6px;color:var(--neg)" data-act="delete-shift">Delete this shift (test / mistake)</button>
    ${historyList()}`;
}

function kv(k, cents) { return html`<div class="kv"><span class="k">${k}</span><span class="v num">${cents < 0 ? '−' + fmt(-cents) : fmt(cents)}</span></div>`; }

export function incidentRow(i) {
  return html`<button class="li" data-incident="${i.id}">${icon('flag', 'sm')}
    <div class="grow"><div class="t">${store.INCIDENT_TYPES[i.type] || 'Issue'}${i.table ? ' · Table ' + i.table : ''}</div><div class="s">${fmtTime(i.createdAt)} · ${i.description || ''}</div></div>
    ${i.amount ? html`<span class="amt num">${fmt(i.amount)}</span>` : ''}<span class="pill ${i.resolved ? 'ok' : 'warn'}">${i.resolved ? 'Resolved' : 'Open'}</span></button>`;
}

function historyList() {
  if (!history.length) return '';
  return html`<div class="section-title">Previous shifts</div>
    <div class="list">${history.map(h => html`<button class="li" data-shift="${h.id}">${icon('calendar', 'sm')}
      <div class="grow"><div class="t">${fmtDate(h.startedAt)}</div><div class="s">${fmtTime(h.startedAt)} – ${fmtTime(h.endedAt)}${h.settlement?.unresolved ? ' · ' + h.settlement.unresolved + ' open issue(s)' : ''}</div></div>${icon('chev', 'sm chev')}</button>`)}</div>`;
}

export function mount(root) {
  let seg = store.segmentFor();
  root.addEventListener('click', async e => {
    const t = e.target;
    const sv = t.closest('[data-segv]'); if (sv) { seg = sv.dataset.segv; root.querySelectorAll('[data-segv]').forEach(b => b.classList.toggle('on', b === sv)); return; }
    const mv = t.closest('[data-move]'); if (mv) return openMove(mv.dataset.move);
    const rl = t.closest('[data-rule]');
    if (rl) {
      const r = S.settings.tipoutRules.find(x => x.id === rl.dataset.rule); if (!r) return;
      const amount = tipoutAmount(r, S.summary);
      if (!amount) return flash('Nothing to tip out yet.');
      const basis = r.mode === 'fixed' ? 'fixed' : `${(r.bp / 100).toFixed(2)}% of ${r.mode === 'pct_sales' ? 'sales ' + fmt(S.summary.totalSales) : 'tips ' + fmt(S.summary.totalTips)}`;
      if (!(await confirmDialog({ title: `Tip-out to ${r.name}`, message: `${fmt(amount)} (${basis}), ${r.via === 'deducted' ? 'deducted by the restaurant' : 'paid from your cash'}.`, ok: 'Record tip-out' }))) return;
      await store.addMove({ type: 'tipout', amount, via: r.via === 'deducted' ? 'deducted' : 'cash', note: `${r.name} · ${basis}`, rule: { mode: r.mode, bp: r.bp, cents: r.cents } });
      return flash('Tip-out recorded');
    }
    const mid = t.closest('[data-move-id]'); if (mid) return moveActions(mid.dataset.moveId);
    const inc = t.closest('[data-incident]'); if (inc) return openIncident(S.incidents.find(i => i.id === inc.dataset.incident));
    const shf = t.closest('[data-shift]'); if (shf) return openShiftSummary(shf.dataset.shift);
    switch (t.closest('[data-act]')?.dataset.act) {
      case 'start': {
        const startingCash = readMoney(root, 'startingCash', 0), wage = readMoney(root, 'wage', 0);
        if (Number.isNaN(startingCash) || Number.isNaN(wage) || startingCash < 0) return flash('Check the amounts entered.');
        await store.startShift({ startingCash, hourlyWage: wage, segment: seg });
        flash('Shift started'); location.hash = '#home'; break;
      }
      case 'break': await store.toggleBreak(false); break;
      case 'paid-break': await store.toggleBreak(true); break;
      case 'seg-lunch': await store.setSegment('lunch'); break;
      case 'seg-dinner': await store.setSegment('dinner'); break;
      case 'edit-times': editShiftTimes(S.shift); break;
      case 'count': openCashCounter({ expected: S.summary.expectedCash, onSave: async (c, note) => { const r = await store.recordCount(c, note); flash(r.counted === r.expected ? 'Cash balanced' : `Recorded: ${r.counted > r.expected ? 'over' : 'short'} ${fmt(Math.abs(r.counted - r.expected))}`); } }); break;
      case 'cardtip-cash': openCardTipCash(); break;
      case 'incident': openIncident(); break;
      case 'settle': openSettle(); break;
      case 'tips': openTipQueue(); break;
      case 'delete-shift': if (await confirmDelete(S.shift.id)) flash('Shift deleted'); break;
    }
  });
}

// ---------- start shift ----------
export function openStartShift({ then } = {}) {
  let seg = store.segmentFor();
  const s = openSheet({
    title: 'Start shift',
    body: html`<div class="stack">
      ${moneyInput('startingCash', 'Starting personal cash', S.settings.startingBank || 0, { hint: 'Your own money in the apron (for making change). Returned to you at checkout.' })}
      ${moneyInput('wage', 'Hourly wage (optional)', S.settings.hourlyWage || null)}
      <div class="seg"><button data-segv="lunch" class="${seg === 'lunch' ? 'on' : ''}">Lunch</button><button data-segv="dinner" class="${seg === 'dinner' ? 'on' : ''}">Dinner</button></div></div>`,
    foot: html`<button class="btn primary lg block" data-go>${icon('play', 'sm')} Start Shift</button>`,
  });
  s.body.addEventListener('click', e => { const b = e.target.closest('[data-segv]'); if (b) { seg = b.dataset.segv; s.body.querySelectorAll('[data-segv]').forEach(x => x.classList.toggle('on', x === b)); } });
  s.foot.addEventListener('click', async () => {
    const startingCash = readMoney(s.body, 'startingCash', 0), wage = readMoney(s.body, 'wage', 0);
    if (Number.isNaN(startingCash) || Number.isNaN(wage) || startingCash < 0) return flash('Check the amounts entered.');
    await store.startShift({ startingCash, hourlyWage: wage, segment: seg });
    s.close(); flash('Shift started');
    then?.();
  });
}

// ---------- edit shift times / breaks / starting cash ----------
export function editShiftTimes(sh) {
  const breaks = (sh.breaks || []).map(b => ({ ...b }));
  const s = openSheet({
    title: 'Correct shift details',
    body: html``,
    foot: html`<button class="btn primary block" data-save>Save corrections</button>`,
  });
  const draw = () => s.update(html`<div class="stack">
    <label class="field"><span>Shift start</span><input class="input" type="datetime-local" data-dt="start" value="${toLocalInput(sh.startedAt)}"></label>
    ${sh.status === 'closed' || sh.endedAt ? html`<label class="field"><span>Shift end</span><input class="input" type="datetime-local" data-dt="end" value="${toLocalInput(sh.endedAt || Date.now())}"></label>` : ''}
    ${moneyInput('startingCash', 'Starting personal cash', sh.startingCash | 0)}
    ${moneyInput('wage', 'Hourly wage', sh.hourlyWage || null)}
    <div class="section-title" style="margin-top:6px">Breaks <button data-addbreak>+ Add break</button></div>
    ${breaks.map((b, i) => html`<div class="card pad stack">
      <div class="grid2"><label class="field"><span>Start</span><input class="input" type="datetime-local" data-b="${i}" data-bf="start" value="${toLocalInput(b.start)}"></label>
      <label class="field"><span>End</span><input class="input" type="datetime-local" data-b="${i}" data-bf="end" value="${b.end ? toLocalInput(b.end) : ''}"></label></div>
      <label class="toggle"><span>Paid break</span><span class="switch"><input type="checkbox" data-b="${i}" data-bf="paid" ${b.paid ? 'checked' : ''}><span></span></span></label></div>`)}
    <p class="muted" style="font-size:12.5px;margin:0">Shifts that cross midnight are handled automatically — just pick the correct date for the end time.</p></div>`);
  draw();
  s.body.addEventListener('change', e => {
    const i = e.target.dataset.b; if (i === undefined) return;
    const f = e.target.dataset.bf;
    breaks[+i][f] = f === 'paid' ? e.target.checked : fromLocalInput(e.target.value);
  });
  s.body.addEventListener('click', e => { if (e.target.closest('[data-addbreak]')) { breaks.push({ start: sh.startedAt, end: sh.startedAt + 30 * 60000, paid: false }); draw(); } });
  s.foot.addEventListener('click', async () => {
    const start = fromLocalInput(s.body.querySelector('[data-dt="start"]').value);
    const endEl = s.body.querySelector('[data-dt="end"]');
    const end = endEl ? fromLocalInput(endEl.value) : sh.endedAt;
    const startingCash = readMoney(s.body, 'startingCash', 0), wage = readMoney(s.body, 'wage', 0);
    if (!start || (endEl && (!end || end <= start))) return flash('End time must be after the start time.');
    if ([startingCash, wage].some(Number.isNaN)) return flash('Check the amounts entered.');
    if (breaks.some(b => !b.start || (b.end && b.end < b.start))) return flash('Each break needs a valid start and end.');
    const reason = await promptDialog({ title: 'Reason for correction', label: 'Why are you changing these values?', placeholder: 'e.g. forgot to start shift on time' });
    if (!reason) return;
    await store.updateShift(sh.id, { startedAt: start, endedAt: end ?? null, startingCash, hourlyWage: wage, breaks }, reason);
    s.close(); flash('Shift corrected — previous values kept in history');
  });
}

// ---------- cash movements ----------
function openMove(type) {
  const isOther = type === 'other';
  let mtype = isOther ? 'other_out' : type;
  let via = 'cash';
  const labels = { tipout: 'Record tip-out', withdraw: 'Remove cash from apron', add: 'Add cash to apron', drop: 'Pay cash to restaurant (mid-shift)', other: 'Other cash movement' };
  const s = openSheet({ title: labels[type], body: html``, foot: html`<button class="btn primary block" data-save>Save</button>` });
  const draw = () => s.update(html`<div class="stack">
    ${moneyInput('amount', 'Amount', null)}
    ${type === 'tipout' ? html`<label class="field"><span>Paid to</span><input class="input" data-text="to" maxlength="60" placeholder="Busser, bar, host…"></label>
      <div class="seg"><button class="${via === 'cash' ? 'on' : ''}" data-via="cash">Paid from my cash</button><button class="${via === 'deducted' ? 'on' : ''}" data-via="deducted">Deducted by restaurant</button></div>` : ''}
    ${isOther ? html`<div class="seg"><button class="${mtype === 'other_in' ? 'on' : ''}" data-mt="other_in">Cash in</button><button class="${mtype === 'other_out' ? 'on' : ''}" data-mt="other_out">Cash out</button></div>` : ''}
    <label class="field"><span>Note (optional)</span><input class="input" data-text="note" maxlength="120"></label></div>`);
  draw();
  s.body.addEventListener('click', e => {
    const v = e.target.closest('[data-via]'); if (v) { via = v.dataset.via; s.body.querySelectorAll('[data-via]').forEach(b => b.classList.toggle('on', b === v)); }
    const m = e.target.closest('[data-mt]'); if (m) { mtype = m.dataset.mt; s.body.querySelectorAll('[data-mt]').forEach(b => b.classList.toggle('on', b === m)); }
  });
  s.foot.addEventListener('click', async () => {
    const amount = readMoney(s.body, 'amount');
    if (!amount || Number.isNaN(amount) || amount <= 0) return flash('Enter an amount.');
    const to = readText(s.body, 'to', 60), note = readText(s.body, 'note', 120);
    await store.addMove({ type: mtype, amount, via: type === 'tipout' ? via : undefined, note: [to, note].filter(Boolean).join(' · ') });
    s.close(); flash('Saved to cash ledger');
  });
}

async function moveActions(id) {
  const m = S.moves.find(x => x.id === id); if (!m || m.voided) return;
  const reason = await promptDialog({ title: 'Void this entry?', label: 'Reason (the entry stays in history)', ok: 'Void entry' });
  if (reason) { await store.voidMove(id, reason); flash('Entry voided'); }
}

function openCardTipCash() {
  const s = openSheet({
    title: 'Card tips received in cash',
    body: html`<div class="stack">${moneyInput('amount', 'Amount received', S.summary.cardTipsOutstanding)}
      <p class="muted" style="font-size:13px;margin:0">Use this when the restaurant hands you your card tips in cash during or at the end of the shift. It reduces unpaid card tips and adds to your cash on hand.</p></div>`,
    foot: html`<button class="btn primary block">Save</button>`,
  });
  s.foot.addEventListener('click', async () => {
    const amount = readMoney(s.body, 'amount');
    if (!amount || Number.isNaN(amount) || amount <= 0) return flash('Enter an amount.');
    await store.addPayout({ shiftId: S.shift.id, amount, via: 'cash', inApron: true, note: 'Received in cash' });
    s.close(); flash('Card tip payout recorded');
  });
}

// ---------- cash counter ----------
export function openCashCounter({ expected = null, onSave, title = 'Count cash', saveLabel = 'Save count' }) {
  const counts = {};
  const label = d => d >= 100 ? `$${d / 100}` : `${d}¢`;
  const s = openSheet({ title, body: html``, foot: html`<button class="btn primary block" data-save>${saveLabel}</button>` });
  const draw = () => {
    const total = countCash(counts);
    s.update(html`<div class="stack">
      <div class="card pad"><div class="row between"><span class="muted">Counted</span><b class="num" style="font-size:26px">${fmt(total)}</b></div>
        ${expected !== null ? html`<div class="row between" style="margin-top:4px"><span class="muted">Expected</span><span class="num">${fmt(expected)}</span></div>
        <div class="row between" style="margin-top:4px"><span class="muted">Difference</span><b class="num ${total - expected > 0 ? 'pos' : total - expected < 0 ? 'neg' : ''}">${total === expected ? 'Balanced' : (total > expected ? '+' : '−') + fmt(Math.abs(total - expected))}</b></div>` : ''}</div>
      <div class="list">${DENOMINATIONS.map(d => html`<div class="li" style="padding:8px 12px">
        <b style="width:52px">${label(d)}</b>
        <button class="iconbtn" data-dec="${d}" aria-label="Less">${icon('minus', 'sm')}</button>
        <input class="input num" style="width:70px;height:42px;text-align:center" inputmode="numeric" data-cnt="${d}" value="${counts[d] || ''}" placeholder="0">
        <button class="iconbtn" data-inc="${d}" aria-label="More">${icon('plus', 'sm')}</button>
        <span class="grow amt num">${fmt(d * (counts[d] || 0))}</span></div>`)}</div>
      <label class="field"><span>Note (optional)</span><input class="input" data-text="note" maxlength="120"></label></div>`);
  };
  draw();
  s.body.addEventListener('click', e => {
    const inc = e.target.closest('[data-inc]'), dec = e.target.closest('[data-dec]');
    if (inc) { counts[inc.dataset.inc] = (counts[inc.dataset.inc] || 0) + 1; draw(); }
    if (dec) { counts[dec.dataset.dec] = Math.max(0, (counts[dec.dataset.dec] || 0) - 1); draw(); }
  });
  s.body.addEventListener('change', e => { const d = e.target.dataset.cnt; if (d) { counts[d] = Math.max(0, Math.min(9999, parseInt(e.target.value, 10) || 0)); draw(); } });
  s.foot.addEventListener('click', async () => { const note = readText(s.body, 'note', 120); await onSave(countCash(counts), note, { ...counts }); s.close(); });
}

// ---------- incidents ----------
export function openIncident(existing = null, { table = '', checkId = null } = {}) {
  const inc = existing ? { ...existing } : { type: 'other', table, checkId, description: '', amount: 0, photoIds: [], resolved: false };
  const s = openSheet({ title: existing ? 'Incident' : 'Log incident', body: html``, foot: html`<button class="btn primary block" data-save>Save</button>` });
  const draw = () => s.update(html`<div class="stack">
    <label class="field"><span>Type</span><select class="input" data-f="type">${Object.entries(store.INCIDENT_TYPES).map(([k, v]) => html`<option value="${k}" ${inc.type === k ? 'selected' : ''}>${v}</option>`)}</select></label>
    <div class="grid2"><label class="field"><span>Table (optional)</span><input class="input" data-f="table" maxlength="6" value="${inc.table || ''}" inputmode="numeric"></label>
    ${moneyInput('amount', 'Amount involved', inc.amount || null)}</div>
    <label class="field"><span>What happened</span><textarea class="input" data-f="description" maxlength="1000">${inc.description || ''}</textarea></label>
    <label class="field"><span>Resolution notes</span><textarea class="input" data-f="resolution" maxlength="1000">${inc.resolution || ''}</textarea></label>
    <label class="toggle"><span>Resolved</span><span class="switch"><input type="checkbox" data-f="resolved" ${inc.resolved ? 'checked' : ''}><span></span></span></label>
    <div class="field"><span>Photos</span>${photoStrip(inc.photoIds, true)}</div>
    <p class="muted" style="font-size:12px;margin:0">Describe facts only. ShiftCash never assumes wrongdoing — differences can come from many honest mistakes.</p></div>`);
  draw();
  const sync = () => {
    s.body.querySelectorAll('[data-f]').forEach(el => { inc[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value.trim(); });
  };
  s.body.addEventListener('click', async e => {
    if (e.target.closest('[data-add-photo]')) { sync(); const id = await photoPicker({ kind: 'incident' }); if (id) { inc.photoIds = [...(inc.photoIds || []), id]; draw(); } }
  });
  s.foot.addEventListener('click', async () => {
    sync();
    const amount = readMoney(s.body, 'amount', 0);
    if (Number.isNaN(amount)) return flash('Check the amount.');
    if (!inc.description) return flash('Describe what happened.');
    inc.amount = amount; inc.table = String(inc.table || '').slice(0, 6);
    await store.saveIncident(inc);
    s.close(); flash('Incident saved');
  });
}
