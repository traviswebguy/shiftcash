// ShiftCash — application shell: startup, router, top bar, service worker, lifecycle.
import { html, icon, setHTML, $, $$, flash, closeAllSheets, topSheet } from './ui.js';
import { setCurrency } from './money.js';
import * as db from './db.js';
import * as store from './store.js';
import { S } from './store.js';
import { lock, watchVisibility, isLocked } from './lock.js';
import { isNative, onLifecycle, exitApp } from './native.js';
import * as home from './views/home.js';
import * as tables from './views/tables.js';
import * as shift from './views/shift.js';
import * as reports from './views/reports.js';
import * as settings from './views/settings.js';
import * as simple from './views/simple.js';
import { openEntry } from './views/entry.js';

// '#setup' (not '#settings', which some hosts such as claude.ai reserve)
const VIEWS = { simple, home, tables, shift, reports, setup: settings };
let current = null;
let renderQueued = false;

function routeName() {
  const r = location.hash.replace('#', '');
  return VIEWS[r] ? r : null;
}

function renderTop(v) {
  const t = v.title();
  setHTML($('#topbar'), html`
    ${t.logo ? html`<div class="logo">${icon('logo')}</div>` : (current !== 'home' ? html`<a class="iconbtn" href="#home" aria-label="Home">${icon('back')}</a>` : '')}
    <div class="grow"><h1>${t.title}</h1><div class="sub">${t.sub || ''}</div></div>
    ${!navigator.onLine ? html`<span class="pill" style="background:rgba(255,255,255,.12);color:#fff;border:0">${icon('offline', 'xs')} Offline</span>` : ''}
    ${current === 'home' ? html`<button class="pill" data-act="go-simple" style="background:rgba(255,255,255,.14);color:#fff;border:0;height:34px;padding:0 12px;font-size:13px">Simple view</button>` : ''}`);
  document.body.classList.toggle('simple-mode', current === 'simple');
}

export function render() {
  const v = VIEWS[current];
  if (!v) return;
  renderTop(v);
  const main = $('#view');
  const container = document.createElement('div');
  setHTML(container, v.render());
  v.mount?.(container, rerender);
  const y = main.scrollTop;
  main.replaceChildren(container);
  main.scrollTop = y;
  $$('#nav [data-tab]').forEach(a => a.classList.toggle('on', a.dataset.tab === current));
}
function rerender() { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); }

const defaultRoute = () => (S.settings.uiMode === 'full' ? (S.settings.homeScreen || 'home') : 'simple');
async function go() {
  const name = routeName() || defaultRoute();
  if (!routeName()) { history.replaceState(null, '', '#' + name); }
  const changed = name !== current;
  current = name;
  if (VIEWS[name].load) await VIEWS[name].load();
  render();
  if (changed) window.scrollTo(0, 0);
}

function registerSW() {
  if (isNative() || !('serviceWorker' in navigator) || location.protocol === 'file:') return;
  navigator.serviceWorker.register('sw.js').then(reg => {
    reg.addEventListener('updatefound', () => {
      const w = reg.installing;
      w?.addEventListener('statechange', () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) {
          flash('A ShiftCash update is ready. Your records are kept.', [{ label: 'Update', run: () => w.postMessage('skipWaiting') }], 15000);
        }
      });
    });
  }).catch(e => console.warn('SW registration failed', e));
  // Reload only when an UPDATE takes over (the user tapped "Update"), never on the very first install.
  const hadController = !!navigator.serviceWorker.controller;
  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (hadController && !reloading) { reloading = true; location.reload(); } });
}

async function start() {
  try {
    await db.initStorage();
    await store.init();
  } catch (e) {
    console.error(e);
    setHTML($('#view'), html`<div class="card pad stack" style="margin-top:20px"><b>ShiftCash could not open its storage.</b>
      <div class="muted">${String(e && e.message || e)}</div>
      <div class="muted" style="font-size:13px">Private/incognito browsing or blocked site data can prevent storage. Your existing records have not been changed.</div>
      <button class="btn primary" id="retry">Try again</button></div>`);
    $('#retry')?.addEventListener('click', () => location.reload());
    return;
  }
  settings.applyTheme();
  setCurrency(S.settings.currency || 'USD');
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', settings.applyTheme);

  // Ask the browser to keep our data (best effort; Android app storage is already private & persistent).
  if (!isNative()) db.requestPersist();

  store.subscribe(() => { if (current) rerender(); });
  window.addEventListener('hashchange', () => { closeAllSheets(); go(); });
  window.addEventListener('online', rerender);
  window.addEventListener('offline', rerender);
  document.addEventListener('click', async e => {
    if (e.target.closest('[data-act="new-tx"]')) { e.preventDefault(); openEntry(); }
    if (e.target.closest('[data-act="go-simple"]')) { await store.setSetting('uiMode', 'simple'); location.hash = '#simple'; }
  });

  // Keep the shift timer fresh without reloading data.
  setInterval(() => { if (S.shift && !topSheet() && (current === 'home' || current === 'shift' || current === 'simple')) { store.recompute(); rerender(); } }, 30000);

  watchVisibility();
  onLifecycle({
    resume: async () => { await store.reload(); },
    back: () => { const s = topSheet(); if (s) s.close(); else if (current !== defaultRoute()) location.hash = '#' + defaultRoute(); else exitApp(); },
  });

  if (S.settings.pinHash) await lock();
  if (S.settings.uiMode !== 'full' && routeName() !== 'simple') history.replaceState(null, '', '#simple');
  await go();
  registerSW();
  if (S.shift) {
    const age = Date.now() - S.shift.startedAt;
    if (age > 20 * 3600000) flash('Your shift has been open for over 20 hours. Did you forget to end it?', [{ label: 'Review', run: () => { location.hash = '#shift'; } }], 8000);
  }
  window.__shiftcashReady = true;
}

start();
