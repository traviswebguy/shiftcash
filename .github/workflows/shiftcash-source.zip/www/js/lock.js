// ShiftCash — optional local privacy PIN.
// LIMITATIONS (also shown in Settings): the PIN only hides the app's screens. Data in IndexedDB is NOT encrypted;
// anyone with access to the unlocked device, browser developer tools or a device backup can still read it.
import { html, setHTML } from './ui.js';
import { S, setSetting } from './store.js';

const ITER = 150000;
async function derive(pin, saltB64) {
  const salt = Uint8Array.from(atob(saltB64), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: ITER, hash: 'SHA-256' }, key, 256);
  return btoa(String.fromCharCode(...new Uint8Array(bits)));
}
export const pinSupported = () => !!(window.crypto && crypto.subtle);

export async function setPin(pin) {
  const salt = btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(16))));
  await setSetting('pinSalt', salt);
  await setSetting('pinHash', await derive(pin, salt));
}
export async function clearPin() { await setSetting('pinHash', ''); await setSetting('pinSalt', ''); }
async function verify(pin) { return (await derive(pin, S.settings.pinSalt)) === S.settings.pinHash; }

let locked = false, hiddenAt = 0, fails = 0, waitUntil = 0;
export function isLocked() { return locked; }

export function lock() {
  if (!S.settings.pinHash || locked) return Promise.resolve();
  locked = true;
  return new Promise(resolve => {
    let pin = '';
    const el = document.createElement('div');
    el.className = 'lock';
    const draw = (err = '') => setHTML(el, html`
      <svg class="i lg"><use href="#i-lock"/></svg>
      <div style="font-size:20px;font-weight:700">ShiftCash is locked</div>
      <div class="dots">${[0, 1, 2, 3, 4, 5].slice(0, Math.max(4, pin.length)).map(i => html`<span class="${i < pin.length ? 'f' : ''}"></span>`)}</div>
      <div class="err">${err}</div>
      <div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => html`<button data-n="${n}">${n}</button>`)}<button data-n="del" style="font-size:16px">Delete</button><button data-n="0">0</button><button data-n="ok" style="font-size:16px">Enter</button></div>`);
    draw();
    el.addEventListener('click', async e => {
      const b = e.target.closest('[data-n]'); if (!b) return;
      const n = b.dataset.n;
      if (n === 'del') pin = pin.slice(0, -1);
      else if (n === 'ok' || pin.length >= 5) {
        if (n !== 'ok' && n !== 'del') pin += n;
        if (Date.now() < waitUntil) return draw(`Too many attempts. Wait ${Math.ceil((waitUntil - Date.now()) / 1000)}s.`);
        if (pin.length < 4) return draw('Enter at least 4 digits');
        if (await verify(pin)) { locked = false; fails = 0; el.remove(); resolve(); return; }
        fails++; pin = '';
        if (fails >= 5) waitUntil = Date.now() + Math.min(300, 15 * 2 ** (fails - 5)) * 1000;
        return draw('Incorrect PIN');
      } else pin += n;
      draw();
    });
    document.body.appendChild(el);
  });
}

export function watchVisibility() {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) hiddenAt = Date.now();
    else if (S.settings.pinHash && hiddenAt && Date.now() - hiddenAt > (S.settings.pinLockMinutes ?? 5) * 60000) lock();
  });
}
