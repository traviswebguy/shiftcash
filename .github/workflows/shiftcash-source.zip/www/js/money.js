// ShiftCash — money & rounding engine.
// Every monetary value in ShiftCash is an integer number of cents.
// No floating point arithmetic is ever applied to stored amounts.

export const MAX_CENTS = 100_000_000_00; // $100M safety ceiling

export function isCents(v) {
  return Number.isSafeInteger(v) && Math.abs(v) <= MAX_CENTS;
}

/** Parse user text ("12", "12.5", "$1,234.56") into integer cents. Returns NaN if invalid. */
export function toCents(input) {
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return NaN;
    return Math.round(input * 100);
  }
  if (typeof input !== 'string') return NaN;
  let s = input.trim().replace(/[$,\s]/g, '');
  if (s === '') return NaN;
  let neg = false;
  if (s.startsWith('-')) { neg = true; s = s.slice(1); }
  if (!/^\d{0,9}(\.\d{0,2})?$/.test(s) || s === '.') return NaN;
  const [whole, frac = ''] = s.split('.');
  const cents = parseInt(whole || '0', 10) * 100 + parseInt((frac + '00').slice(0, 2), 10);
  return neg ? -cents : cents;
}

/** Keypad-style entry: digits typed shift in from the right (e.g. "4","8","0","0" → 4800 = $48.00). */
export function keypadAppend(cents, digit) {
  const next = cents * 10 + digit;
  return next > 99_999_99 ? cents : next;
}
export function keypadBackspace(cents) { return Math.trunc(cents / 10); }

let fmtCache = null;
export function setCurrency(code = 'USD', locale = undefined) {
  try {
    fmtCache = new Intl.NumberFormat(locale, { style: 'currency', currency: code, minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } catch {
    fmtCache = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
  }
}
export function fmt(cents) {
  if (!fmtCache) setCurrency();
  if (!Number.isFinite(cents)) return '—';
  // Format from an exact decimal string so no binary float rounding leaks in.
  return fmtCache.format(cents / 100);
}
export function fmtSigned(cents) {
  if (cents > 0) return '+' + fmt(cents);
  if (cents < 0) return '−' + fmt(-cents);
  return fmt(0);
}
export function plain(cents) { // "48.00" for inputs
  const neg = cents < 0; const a = Math.abs(cents);
  return (neg ? '-' : '') + Math.trunc(a / 100) + '.' + String(a % 100).padStart(2, '0');
}

/**
 * Round an amount of cents to a whole dollar.
 * mode: 'nearest' | 'up' | 'down'
 * half: how exactly .50 is treated in 'nearest' mode: 'up' (default) or 'down'.
 * Negative amounts are rounded symmetrically (by magnitude).
 */
export function roundDollar(cents, mode = 'nearest', half = 'up') {
  if (cents < 0) return -roundDollar(-cents, mode === 'up' ? 'up' : mode === 'down' ? 'down' : mode, half);
  const rem = cents % 100;
  const base = cents - rem;
  if (rem === 0) return cents;
  if (mode === 'up') return base + 100;
  if (mode === 'down') return base;
  if (rem > 50) return base + 100;
  if (rem < 50) return base;
  return half === 'down' ? base : base + 100;
}

export const ROUNDING_METHODS = {
  nearest: 'Nearest whole dollar',
  up: 'Always round up',
  down: 'Always round down',
  exact: 'Exact change (no rounding)',
  manual: 'Manual override',
};
/** Methods that can never increase what the customer pays (used when round-up is disabled). */
export const NO_ROUND_UP_METHODS = { down: 'Always round down (cash discount)', exact: 'Exact change (no rounding)', manual: 'Manual override' };
export function roundingChoices(allowRoundUp) { return allowRoundUp ? ROUNDING_METHODS : NO_ROUND_UP_METHODS; }
/** Make a rounding config safe when round-up is disabled: ticket target, never up/nearest, manual never above the ticket. */
export function safeRounding(r = {}, allowRoundUp = false, due = null) {
  if (allowRoundUp) return r;
  const out = { ...r, target: 'ticket' };
  if (out.method === 'up' || out.method === 'nearest' || !out.method) out.method = 'down';
  if (out.method === 'manual' && due !== null && Number.isSafeInteger(out.manualDue) && out.manualDue > due) out.manualDue = due;
  return out;
}

export const ROUNDING_TARGETS = { ticket: 'Round the ticket total', change: 'Round the change amount' };

/**
 * Compute the amount the customer actually pays in cash (the "rounded payable").
 *   rounding = { method, target, half, manualDue }
 * Ticket target: roundedDue = round(due).
 * Change target: change = round(received − due), roundedDue = received − change.
 * If the customer hands over less than the ticket, change targeting is not possible
 * and the ticket is rounded instead.
 */
export function roundedPayable(due, received, rounding = {}) {
  const method = rounding.method || 'nearest';
  const half = rounding.half || 'up';
  if (method === 'exact') return due;
  if (method === 'manual') {
    return isCents(rounding.manualDue) && rounding.manualDue >= 0 ? rounding.manualDue : due;
  }
  if (rounding.target === 'change' && isCents(received) && received >= due) {
    const change = roundDollar(received - due, method, half);
    return received - change;
  }
  return roundDollar(due, method, half);
}

/**
 * Full cash-payment breakdown.
 * input: { due, received, rounding, changeGiven, keptTip, extraTip }
 *   due         – part of the ticket this cash covers (original value, never modified)
 *   received    – cash handed over by the customer
 *   changeGiven – change actually returned (null/undefined → expected change)
 *   keptTip     – portion of the un-returned change the customer CONFIRMED as a tip
 *   extraTip    – additional cash tip left after change was returned
 */
export function cashPayment(input) {
  const due = int(input.due);
  const roundedDue = roundedPayable(due, input.received, input.rounding);
  const received = isCents(input.received) ? input.received : roundedDue;
  const expectedChange = Math.max(0, received - roundedDue);
  const changeGiven = isCents(input.changeGiven) ? Math.max(0, input.changeGiven) : expectedChange;
  const excess = Math.max(0, expectedChange - changeGiven);       // customer let server keep this
  const shortage = Math.max(0, changeGiven - expectedChange);     // server returned too much
  const keptTip = Math.min(Math.max(0, int(input.keptTip)), excess);
  const unconfirmed = excess - keptTip;
  const extraTip = Math.max(0, int(input.extraTip));
  const underpaid = Math.max(0, roundedDue - received);
  const tipPending = !!input.tipPending;            // "what they left on the table" will be entered later at the POS
  const warnings = [];
  if (tipPending) warnings.push({ code: 'tip_pending', cents: 0, msg: 'Tip left on the table not entered yet.' });
  if (underpaid > 0) warnings.push({ code: 'underpaid', cents: underpaid, msg: `Cash received is ${fmt(underpaid)} less than the amount due.` });
  if (shortage > 0) warnings.push({ code: 'overchange', cents: shortage, msg: `Too much change returned: ${fmt(shortage)} more than expected.` });
  if (unconfirmed > 0) warnings.push({ code: 'unconfirmed', cents: unconfirmed, msg: `${fmt(unconfirmed)} extra cash kept but not confirmed as a tip.` });
  return {
    method: 'cash',
    due, roundedDue, roundingAdj: roundedDue - due,
    received, expectedChange, changeGiven, excess, shortage,
    keptTip, unconfirmed, extraTip, underpaid, tipPending,
    cashTip: keptTip + extraTip,
    cashIn: received - changeGiven + extraTip,          // net physical cash added to the apron
    collected: received - changeGiven,                   // cash retained from the payment itself
    warnings,
  };
}

/**
 * Card payment: never rounded.
 * input: { due, tip, extraCashTip, tipStatus }
 *   tip null/undefined → tip not entered yet (waiting for the signed receipt): status "pending", counts as $0 until entered.
 *   tipStatus: 'pending' | 'entered' | 'confirmed' | 'disputed'. Entering a tip never means it has been received.
 */
export function cardPayment(input) {
  const due = int(input.due);
  const pending = input.tip === null || input.tip === undefined || input.tipStatus === 'pending';
  const tip = pending ? 0 : Math.max(0, int(input.tip));
  const extraCashTip = Math.max(0, int(input.extraCashTip));
  const tipStatus = pending ? 'pending' : (['confirmed', 'disputed'].includes(input.tipStatus) ? input.tipStatus : 'entered');
  const warnings = [];
  if (pending) warnings.push({ code: 'tip_pending', cents: 0, msg: 'Card tip not entered yet (waiting for signed receipt).' });
  if (tipStatus === 'disputed') warnings.push({ code: 'tip_disputed', cents: tip, msg: `Card tip of ${fmt(tip)} is marked disputed.` });
  return {
    method: 'card', due, tip, extraCashTip, tipStatus,
    charge: due + tip,
    cashTip: extraCashTip,
    cashIn: extraCashTip,
    warnings,
  };
}

/** Basis points helpers for percentages (300 bp = 3.00%). Half-cent rounds up. */
export function pctOf(cents, bp) { return Math.floor((cents * bp + 5000) / 10000); }

/** Refund: input { amount, via: 'cash'|'card' } — reduces sales; cash refunds leave the apron. */
export function refundPayment(input) {
  const amount = Math.max(0, int(input.amount));
  const via = input.via === 'card' ? 'card' : 'cash';
  return { method: 'refund', via, amount, due: -amount, cashIn: via === 'cash' ? -amount : 0, cashTip: 0, warnings: [] };
}

export function computePayment(p) {
  if (!p) return null;
  if (p.method === 'cash') return cashPayment(p);
  if (p.method === 'card') return cardPayment(p);
  if (p.method === 'refund') return refundPayment(p);
  return null;
}

export function pct(part, whole) {
  if (!whole) return 0;
  return Math.round((part / whole) * 1000) / 10; // one decimal place, display-only
}

function int(v) { return isCents(v) ? v : 0; }
