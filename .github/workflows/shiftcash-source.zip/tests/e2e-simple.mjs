// End-to-end browser test of the built PWA (dist/web) in headless Chromium.
// Covers: first load, start shift, cash + card + split entry, persistence after reload,
// offline reopen via the service worker, settlement and closing a shift.
// Run: node scripts/build-web.mjs && node tests/e2e.mjs   (needs the "playwright" package + Chromium)
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
let pw;
try { pw = require('playwright'); } catch { pw = require(join(process.env.NODE_PATH || '', 'playwright')); }
const root = new URL('../dist/web/', import.meta.url).pathname;
const shots = new URL('../dist/screenshots/', import.meta.url).pathname;
await mkdir(shots, { recursive: true });
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff': 'font/woff', '.json': 'application/json' };
const server = createServer(async (req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  try { const b = await readFile(join(root, p)); res.writeHead(200, { 'content-type': types[extname(p)] || 'application/octet-stream' }); res.end(b); }
  catch { res.writeHead(404); res.end('nf'); }
}).listen(0);
const URL0 = `http://localhost:${server.address().port}/`;

const results = []; const errors = [];
const step = async (name, fn) => { try { await fn(); results.push(['✓', name]); } catch (e) { results.push(['✗', name + ' → ' + e.message.split('\n').slice(0,3).join(' ')]); await page.screenshot({ path: shots + 'FAIL-' + results.length + '.png', timeout: 20000 }).catch(()=>{}); } };
const browser = await pw.chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
page.setDefaultTimeout(15000);
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
const ready = () => page.waitForFunction(() => window.__shiftcashReady === true, null, { timeout: 15000 });
const key = async seq => { for (const k of seq) await page.click(`#kp [data-k="${k}"]`); };
const text = sel => page.locator(sel).innerText();
const shot = n => page.screenshot({ path: shots + n + '.png', timeout: 20000 });
const expectText = async (sel, needle) => { const t = await text(sel); if (!t.toLowerCase().includes(needle.toLowerCase())) throw new Error(`"${needle}" not found in ${sel}: ${t.slice(0, 300).replace(/\n/g, ' | ')}`); };

await step('Opens in Simple mode with one big button', async () => {
  await page.goto(URL0); await ready();
  await expectText('#view', 'New table'); await expectText('#view', 'No open tables');
  const nav = await page.locator('#nav').isVisible(); if (nav) throw new Error('bottom nav should be hidden');
  await shot('s01-simple-home');
});
await step('New table (cash): 12 → $42.65 → Cash → gave $60 → give back $18', async () => {
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');
  await shot('s02-table');
  for (const k of ['1', '2', 'ok', '4', '2', '6', '5']) await page.click(`#skp [data-k="${k}"]`);
  await shot('s03-bill');
  await page.click('#skp [data-k="ok"]');
  await expectText('.sheet', 'How are they paying'); await shot('s04-method');
  await page.click('.sheet [data-method="cash"]');
  await page.click('.sheet [data-denom="5000"]'); await page.click('.sheet [data-denom="1000"]');
  await expectText('.sheet .change-card', '$18.00'); await shot('s05-change');
  await page.click('#skOk'); await page.waitForTimeout(500);
  await expectText('#view', 'Waiting for tip'); await expectText('#view', 'gave back $18.00');
});
await step('Not enough cash is blocked', async () => {
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');
  for (const k of ['5', 'ok', '3', '0', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-method="cash"]'); await page.click('.sheet [data-denom="2000"]');
  await expectText('.sheet .change-card', 'short');
  if (!(await page.locator('#skOk').isDisabled())) throw new Error('save should be disabled');
  await page.click('.sheet [data-denom="1000"]'); await expectText('.sheet .change-card', '$0.00');
  await page.click('#skOk'); await page.waitForTimeout(500);
});
await step('New table (card) saves in one tap after the bill', async () => {
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');
  for (const k of ['1', '4', 'ok', '3', '2', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-method="card"]'); await page.waitForTimeout(500);
  await expectText('#view', 'Card');
  await shot('s06-waiting');
});
await step('Split: $90 bill → card $40 + cash $50 (gave $60, give back $10)', async () => {
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');
  for (const k of ['2', '1', 'ok', '9', '0', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-method="split"]'); await expectText('.sheet', 'Still to pay');
  await page.click('.sheet [data-part="card"]');
  for (const k of ['4', '0', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-part="cash"]'); await page.click('#skp [data-k="ok"]');   // keep "rest of bill" $50
  await page.click('.sheet [data-denom="5000"]'); await page.click('.sheet [data-denom="1000"]');
  await expectText('.sheet .change-card', '$10.00'); await page.click('#skp [data-k="ok"]');
  await expectText('.sheet', 'All paid'); await shot('s05b-split');
  await page.click('.sheet [data-savesplit]'); await page.waitForTimeout(500);
});
await step('Big party: two separate checks at table 30 grouped together', async () => {
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');
  for (const k of ['3', '0', 'ok', '2', '5', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-method="card"]'); await page.waitForTimeout(500);
  await page.click('[data-act="new"]'); await page.waitForSelector('#skp');           // same table number again
  for (const k of ['3', '0']) await page.click(`#skp [data-k="${k}"]`);
  await expectText('.sheet', 'already has open checks'); await page.click('#skp [data-k="ok"]');
  await expectText('.sheet', 'How much is this check');
  for (const k of ['1', '8', '0', '0', 'ok']) await page.click(`#skp [data-k="${k}"]`);
  await page.click('.sheet [data-method="card"]'); await page.waitForTimeout(500);
  await expectText('#view', '2 checks open'); await shot('s06b-party');
});
await step('Close tables by entering tips (each check and split part separately)', async () => {
  const n0 = await page.locator('#view [data-close]').count();
  if (n0 !== 7) throw new Error('expected 7 open payments (3 single + 2 split parts + 2 party checks), got ' + n0);
  const tips = ['500', '600', null, '400', '300', '200', '100'];   // null = No tip
  for (const t of tips) {
    await page.locator('#view [data-close]').first().click(); await page.waitForSelector('#skp');
    if (t === null) await page.click('.sheet [data-notip]');
    else { for (const k of t) await page.click(`#skp [data-k="${k}"]`); await page.click('#skOk'); }
    await page.waitForTimeout(450);
  }
  await expectText('.simple-hero', '$21.00'); await expectText('#view', 'No open tables');
  await shot('s08-closed');
});
await step('Survives closing the app (reload)', async () => {
  await page.reload(); await ready(); await expectText('.simple-hero', '$21.00'); await expectText('#view', 'Closed');
});
await step('End of night: tips $21, 5 tables · 6 checks, pay restaurant $115 (cash $122 − card tips $7)', async () => {
  await page.click('[data-act="end"]'); await page.waitForTimeout(400);
  await expectText('.sheet', '$21.00'); await expectText('.sheet', '$115.00'); await expectText('.sheet', '5 · 6');
  await shot('s09-end');
  await page.click('.sheet [data-finish]'); await page.waitForTimeout(600);
  await expectText('#view', 'New table');
});

await browser.close(); server.close();
for (const [s, n] of results) console.log(`  ${s} ${n}`);
const failed = results.filter(r => r[0] === '✗').length;
if (errors.length) { console.log('\nBrowser errors:'); errors.forEach(e => console.log('  ' + e)); }
console.log(`\n${results.length - failed}/${results.length} simple-mode checks passed${errors.length ? `, ${errors.length} console error(s)` : ''}`);
process.exit(failed || errors.length ? 1 : 0);
