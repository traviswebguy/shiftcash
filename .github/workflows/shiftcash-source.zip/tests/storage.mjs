// Tests the Android SQLite storage layer (www/js/sqlite-store.js) against a real SQLite engine
// (Node's built-in node:sqlite), plus encrypted backups and integrity checks.
// The Capacitor plugin itself only runs on a device; this verifies all SQL, atomicity and persistence logic.
// Run: node --no-warnings tests/storage.mjs
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SqliteStore } from '../www/js/sqlite-store.js';
import { sealBackup, openBackup, isEncrypted } from '../www/js/crypto.js';
import { checkIntegrity, migrateRecord, SCHEMA_VERSION } from '../www/js/schema.js';
import { summarizeShift } from '../www/js/ledger.js';

globalThis.btoa ??= s => Buffer.from(s, 'binary').toString('base64');
globalThis.atob ??= s => Buffer.from(s, 'base64').toString('binary');

/** Same interface the Capacitor connection exposes (exec / query / executeSet). */
function nodeConn(file) {
  const db = new DatabaseSync(file);
  return {
    db,
    exec: async sql => db.exec(sql),
    query: async (sql, values = []) => db.prepare(sql).all(...values),
    executeSet: async set => {
      db.exec('BEGIN');
      try { for (const { statement, values } of set) db.prepare(statement).run(...values); db.exec('COMMIT'); }
      catch (e) { db.exec('ROLLBACK'); throw e; }
    },
  };
}

const results = [];
const t = async (name, fn) => { try { await fn(); results.push([true, name]); } catch (e) { results.push([false, name + ' → ' + e.message]); } };
const eq = (a, b, m = '') => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };

const dir = mkdtempSync(join(tmpdir(), 'shiftcash-'));
const file = join(dir, 'shiftcash.db');
const shift = { id: 's1', status: 'active', startedAt: Date.now() - 3600000, startingCash: 5000, breaks: [] };
const check = { id: 'c1', shiftId: 's1', visitId: 'v1', table: '12', ticketCents: 4265, payments: [{ id: 'p1', method: 'cash', due: 4265, received: 6000, rounding: { method: 'nearest', target: 'ticket', half: 'up' }, changeGiven: 1700, keptTip: 0, extraTip: 0 }] };

await t('Create schema and save related records atomically', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  await st.putMany([['shifts', shift], ['checks', check], ['audit', { id: 'a1', entity: 'check', entityId: 'c1', action: 'create', at: Date.now() }]]);
  eq((await st.get('checks', 'c1')).ticketCents, 4265);
  eq((await st.byIndex('checks', 'shiftId', 's1')).length, 1);
  eq((await st.byIndex('audit', 'entityId', 'c1')).length, 1);
});
await t('Interrupted / failing write is rolled back completely', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  let threw = false;
  try { await st.putMany([['checks', { ...check, id: 'c2' }], ['checks', { table: 'no id' }]]); } catch { threw = true; }
  eq(threw, true, 'second record should fail');
  eq(await st.get('checks', 'c2'), undefined, 'first record of failed transaction must not exist');
});
await t('Active shift and records survive closing and reopening the database (app restart)', async () => {
  const st = await new SqliteStore(nodeConn(file)).init(); // fresh connection, same file
  const s = await st.get('shifts', 's1');
  eq(s.status, 'active');
  const sum = summarizeShift({ shift: s, checks: await st.byIndex('checks', 'shiftId', 's1') });
  eq(sum.cashSales, 4265); eq(sum.expectedCash, 5000 + 4300); eq(sum.roundingAdj, 35);
});
await t('Integer cents are stored exactly (no floating point drift)', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  const many = Array.from({ length: 200 }, (_, i) => ['moves', { id: 'm' + i, shiftId: 's1', type: 'add', amount: 10 + (i % 7), createdAt: i }]);
  await st.putMany(many);
  const moves = await st.byIndex('moves', 'shiftId', 's1');
  eq(moves.reduce((a, m) => a + m.amount, 0), many.reduce((a, [, m]) => a + m.amount, 0));
  eq(moves.every(m => Number.isInteger(m.amount)), true);
});
await t('Meta values (schema version) persist', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  await st.setMeta('schemaVersion', SCHEMA_VERSION);
  eq(await new SqliteStore(nodeConn(file)).init().then(s => s.getMeta('schemaVersion')), SCHEMA_VERSION);
});
await t('Database migration upgrades stored v1 records in one transaction', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  await st.putMany([['checks', { id: 'old1', shiftId: 's1', table: '3', ticketCents: 1000, createdAt: new Date(2025, 0, 1, 19).getTime(), payments: [{ method: 'card', due: 1000, tip: 200 }] }]]);
  const ops = (await st.all('checks')).map(r => ['checks', migrateRecord('checks', r, 1)]);
  await st.putMany(ops);
  const m = await st.get('checks', 'old1');
  eq(m.visitId, 'old1'); eq(m.segment, 'dinner'); eq(m.payments[0].tipStatus, 'entered');
});
await t('SQLite integrity check passes and detects unreadable rows', async () => {
  const conn = nodeConn(file); const st = await new SqliteStore(conn).init();
  eq(await st.integrity(), []);
  conn.db.prepare("INSERT INTO records (store,id,updated_at,data) VALUES ('checks','bad',0,'{not json')").run();
  const p = await st.integrity(); eq(p.length, 1);
  conn.db.prepare("DELETE FROM records WHERE id='bad'").run();
});
await t('Restore "replace" swaps stores atomically', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  await st.replaceStores(['checks'], [['checks', { ...check, id: 'r1' }]]);
  eq((await st.all('checks')).map(c => c.id), ['r1']);
  eq((await st.get('shifts', 's1')).id, 's1', 'other stores untouched');
});
await t('Accounting integrity check flags orphans and duplicate active shifts', async () => {
  const problems = checkIntegrity({ shifts: [shift, { ...shift, id: 's2' }], checks: [{ ...check, shiftId: 'nope' }], moves: [], payouts: [], settings: [], incidents: [], photos: [], audit: [], taxes: [] });
  eq(problems.length, 2);
});
await t('Backup: checksum verified, tampering detected', async () => {
  const data = { shifts: [shift], checks: [check] };
  const text = await sealBackup(data);
  const ok = await openBackup(text); eq(ok.checksumVerified, true); eq(ok.data.checks[0].ticketCents, 4265);
  const tampered = text.replace('4265', '4266');
  let threw = false; try { await openBackup(tampered); } catch (e) { threw = /integrity/i.test(e.message); } eq(threw, true);
});
await t('Backup keeps corrected checks with nested change history', async () => {
  let c = JSON.parse(JSON.stringify(check));
  for (let i = 0; i < 4; i++) c = { ...c, history: [...(c.history || []), { at: i, action: 'edit', reason: 'fix', before: JSON.parse(JSON.stringify(c)) }] };
  const res = await openBackup(await sealBackup({ shifts: [shift], checks: [c] }));
  eq(res.data.checks[0].history.length, 4);
});
await t('Deleting a shift removes its records together (atomic delete)', async () => {
  const st = await new SqliteStore(nodeConn(file)).init();
  await st.putMany([['shifts', { ...shift, id: 'del1' }], ['checks', { ...check, id: 'dc1', shiftId: 'del1' }], ['moves', { id: 'dm1', shiftId: 'del1', type: 'add', amount: 100 }]]);
  await st.delMany([['shifts', 'del1'], ['checks', 'dc1'], ['moves', 'dm1']]);
  eq(await st.get('shifts', 'del1'), undefined); eq(await st.get('checks', 'dc1'), undefined); eq(await st.get('moves', 'dm1'), undefined);
  eq((await st.get('shifts', 's1')).id, 's1', 'other shifts untouched');
});
await t('Encrypted backup round trip; wrong password rejected', async () => {
  const text = await sealBackup({ shifts: [shift], checks: [check] }, 'correct horse');
  eq(isEncrypted(text), true); eq(text.includes('4265'), false, 'amounts must not be readable');
  eq((await openBackup(text, 'correct horse')).data.shifts[0].id, 's1');
  let threw = false; try { await openBackup(text, 'wrong'); } catch { threw = true; } eq(threw, true);
});

rmSync(dir, { recursive: true, force: true });
for (const [ok, n] of results) console.log(`  ${ok ? '✓' : '✗'} ${n}`);
const failed = results.filter(r => !r[0]).length;
console.log(`\n${results.length - failed}/${results.length} storage & backup tests passed`);
process.exit(failed ? 1 : 0);
