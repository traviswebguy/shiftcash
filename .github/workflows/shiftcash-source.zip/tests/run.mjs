// Run: node tests/run.mjs
import { runCases } from '../www/js/testcases.js';
const res = runCases();
let fail = 0;
for (const r of res) {
  console.log(`${r.ok ? '  ✓' : '  ✗'} ${r.name}${r.ok ? '' : '\n      → ' + r.error}`);
  if (!r.ok) fail++;
}
console.log(`\n${res.length - fail}/${res.length} accounting tests passed`);
process.exit(fail ? 1 : 0);
