// End-to-end browser test of the built PWA (dist/web) in headless Chromium.
// Covers: first load, start shift, cash + card + split entry, persistence after reload,
// offline reopen via the service worker, settlement and closing a shift.
// Run: node scripts/build-web.mjs && node tests/e2e.mjs   (needs the "playwright" package + Chromium)
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
let pw;
try { pw = require('playwright'); } catch { pw = require(join(process.env.NODE_PATH || '', 'playwright')); }
const root = new URL('../dist/web/', import.meta.url).pathname;
const shots = new URL('../dist/screenshots/', import.meta.url).pathname;
await mkdir(shots, { recursive: true });
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff': 'font/woff', '.json': 'application/json' };
const server = createServer(async (req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  try { const b = await readFile(join(root, p)); res.writeHead(200, { 'content-type': types[extname(p)] || 'application/octet-stream' }); res.end(b); }
  catch { res.writeHead(404); res.end('nf'); }
}).listen(0);
const URL0 = `http://localhost:${server.address().port}/`;

const results = []; const errors = [];
const step = async (name, fn) => { try { await fn(); results.push(['✓', name]); } catch (e) { results.push(['✗', name + ' → ' + e.message.split('\n').slice(0,3).join(' ')]); await page.screenshot({ path: shots + 'FAIL-' + results.length + '.png', timeout: 20000 }).catch(()=>{}); } };
const browser = await pw.chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
page.setDefaultTimeout(15000);
page.on('pageerror', e => errors.push('pageerror: ' + e.message));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
const ready = () => page.waitForFunction(() => window.__shiftcashReady === true, null, { timeout: 15000 });
const key = async seq => { for (const k of seq) await page.click(`#kp [data-k="${k}"]`); };
const text = sel => page.locator(sel).innerText();
const shot = n => page.screenshot({ path: shots + n + '.png', timeout: 20000 });
const expectText = async (sel, needle) => { const t = await text(sel); if (!t.toLowerCase().includes(needle.toLowerCase())) throw new Error(`"${needle}" not found in ${sel}: ${t.slice(0, 300).replace(/\n/g, ' | ')}`); };

await step('App loads with empty database', async () => {
  await page.goto(URL0); await ready();
  await expectText('#view', 'New table');                  // opens in Simple mode
  await page.click('[data-act="details"]'); await page.waitForTimeout(400);
  await expectText('#view', 'No active shift'); await shot('01-home-empty');
});
await step('Start shift with $50 starting cash', async () => {
  await page.click('[data-act="start"]');
  await page.fill('.sheet [data-money="startingCash"]', '50');
  await page.click('.sheet [data-go]');
  await page.waitForSelector('.hero'); await expectText('.hero', '$0.00');
});
await step('Cash: $42.65 ticket, $60 given → rounds DOWN to $42, $18 change (cash discount)', async () => {
  await page.click('.fab'); await page.waitForSelector('#kp');
  await key(['1', '2', 'next', '4', '2', '6', '5']);
  await page.click('.sheet [data-denom="5000"]'); await page.click('.sheet [data-denom="1000"]');
  await page.click('.sheet [data-cm="calc"]');
  await expectText('.sheet [data-act="rounding"]', '$42.00'); await expectText('.sheet [data-act="rounding"]', '−$0.65'); await expectText('.sheet .change-card', '$18.00');
  await page.click('.sheet [data-act="rounding"]'); await page.waitForTimeout(300);
  const opts = await page.locator('.sheet:last-of-type .list').innerText(); if (/round up|Nearest/i.test(opts)) throw new Error('round-up offered: ' + opts);
  await page.click('.sheet:last-of-type [data-sheet-close]'); await page.waitForTimeout(300);
  await shot('02-cash-entry');
  await page.click('#kpSave'); await page.waitForTimeout(400);
});
await step('Card: $32.00 ticket, $6.00 tip, entered on the same open screen', async () => {
  await key(['1', '4', 'next', '3', '2', '0', '0']);
  await page.click('.sheet [data-method="card"]');
  await key(['6', '0', '0']);
  await expectText('.sheet .breakdown', '$38.00');
  await shot('03-card-entry');
  await page.click('#kpSave'); await page.waitForTimeout(400);
});
await step('Split: $90 ticket — $45 card ($9 tip) + $45 cash', async () => {
  await key(['2', '1', 'next', '9', '0', '0', '0']);
  await page.click('.sheet [data-method="split"]');
  await key(['9', '0', '0']);                       // tip on card 1 ($45.00)
  await page.click('.sheet [data-swap="1"]');       // second half paid in cash, exact
  await expectText('.sheet', 'Remaining on check');
  await shot('04-split-entry');
  await page.click('#kpSave'); await page.waitForTimeout(500);
  await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(400);
});
await step('Dashboard totals: tips $15.00, sales $164.65, 3 checks', async () => {
  await expectText('.hero', '$15.00');
  await expectText('#view', '$164.65'); await expectText('#view', '$87.65'); await expectText('#view', '$77.00');
  await shot('05-home-dashboard');
});
await step('Active shift and records survive reload (app closed/reopened)', async () => {
  await page.reload(); await ready();
  await expectText('.hero', '$15.00'); await expectText('#view', 'Active Shift');
});
await step('Service worker caches the app for offline use', async () => {
  await page.waitForFunction(async () => { const ks = await caches.keys(); return ks.some(k => k.startsWith('shiftcash-')) && !!navigator.serviceWorker.controller; }, null, { timeout: 15000 })
    .catch(async () => { await page.reload(); await ready(); await page.waitForFunction(() => !!navigator.serviceWorker.controller, null, { timeout: 10000 }); });
});
await step('Reopen with no internet (airplane mode): app and data load', async () => {
  await ctx.setOffline(true);
  await page.reload(); await ready();
  await expectText('.hero', '$15.00'); await expectText('#topbar', 'Offline');
  await shot('06-offline-reopen');
});
await step('Offline: log another card table ($20, no tip) and it saves', async () => {
  await page.click('.fab'); await page.waitForSelector('#kp');
  await key(['3', 'next', '2', '0', '0', '0']); await page.click('.sheet [data-method="card"]'); await page.click('.sheet [data-act="no-tip"]');
  await page.click('#kpSave'); await page.waitForTimeout(400); await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(300);
  await expectText('#view', '$184.65');
});
await step('Card "Tip later", then enter the tip from the transaction detail (no duplicate sale)', async () => {
  await page.click('.fab'); await page.waitForSelector('#kp');
  await key(['7', 'next', '1', '0', '0', '0']); await page.click('.sheet [data-method="card"]'); await page.click('.sheet [data-act="tip-later"]');
  await page.click('#kpSave'); await page.waitForTimeout(400); await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(300);
  await expectText('#view', 'Enter tips');
  await page.click('#view [data-check]'); await page.waitForTimeout(350);
  await page.click('.sheet [data-tip-edit]'); await page.waitForTimeout(300);
  await page.fill('.sheet:last-of-type [data-money="tip"]', '2'); await page.click('.sheet:last-of-type .sheet-foot .btn'); await page.waitForTimeout(400);
  await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(350);
  await expectText('.hero', '$17.00'); await expectText('#view', '$194.65');
});
await step('Enter tips list: $5 left at table 12, no tip on the split cash half', async () => {
  await page.click('[data-act="tips"]'); await page.waitForSelector('#tkp');
  await expectText('.sheet', 'Cash · bill $42.65');
  await shot('05b-enter-tips');
  await page.click('#tkp [data-k="5"]'); await page.click('#tkp [data-k="0"]'); await page.click('#tkp [data-k="0"]'); await page.click('#tkSave'); await page.waitForTimeout(500);
  await page.click('#tkp [data-k="none"]'); await page.waitForTimeout(500);
  await expectText('.sheet', '2 tips entered');
  await page.click('.sheet .btn.primary[data-sheet-close]'); await page.waitForTimeout(400);
  await expectText('.hero', '$22.00');
});
await step('Tables tab lists transactions with filters', async () => {
  await page.click('#nav [data-tab="tables"]'); await page.waitForTimeout(300);
  await expectText('#view', 'Split'); await page.click('[data-filter="card"]'); await shot('07-tables');
});
await step('Transaction detail opens with full cash breakdown', async () => {
  await page.click('[data-filter="cash"]'); await page.click('#view [data-check]'); await page.waitForTimeout(350);
  await expectText('.sheet', 'Rounded payable'); await shot('08-detail');
  await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(300);
});
await step('Settlement wizard: compare POS report, count cash, close shift', async () => {
  await page.click('#nav [data-tab="shift"]'); await page.waitForTimeout(300);
  await shot('09-shift');
  await page.click('[data-act="settle"]'); await page.waitForTimeout(350);
  await shot('10-settle-review');
  await page.click('.sheet [data-tab="report"]');
  await page.fill('.sheet [data-rep="cardTips"]', '10'); await page.dispatchEvent('.sheet [data-rep="cardTips"]', 'change');
  await expectText('.sheet .cmp', '−$7.00');
  await shot('11-settle-compare');
  await page.click('.sheet [data-tab="cash"]');
  await page.click('.sheet [data-act="paid-expected"]');
  await page.click('.sheet [data-tab="summary"]');
  await shot('12-settle-summary');
  await page.click('.sheet [data-close-shift]'); await page.waitForTimeout(400);
  await page.click('.sheet-foot [data-x="yes"]'); await page.waitForTimeout(700);
  await expectText('#topbar', 'Reports');
  await shot('13-reports');
});
await step('Tip Records & Taxes shows the year summary', async () => {
  await page.click('[data-act="taxes"]'); await page.waitForTimeout(400);
  await expectText('.sheet', 'Net retained tips'); await expectText('.sheet', '$22.00');
  await shot('13b-taxes');
  await page.click('.sheet [data-sheet-close]'); await page.waitForTimeout(350);
});
await step('Backup creates a verified file', async () => {
  await ctx.setOffline(false);
  await page.click('#nav [data-tab="setup"]'); await page.waitForTimeout(400);
  await page.click('[data-act="backup"]');
  const dlp = page.waitForEvent('download', { timeout: 8000 });
  await page.click('.sheet-foot .btn.primary');
  const dl = await dlp.catch(async e => { throw new Error('no download; message: ' + await page.locator('#flash').innerText()); });
  const path = await dl.path(); const txt = await readFile(path, 'utf8');
  const j = JSON.parse(txt); if (!j.checksum || j.data.checks.length !== 5) throw new Error('backup content wrong');
  await shot('14-settings');
});
await step('In-app self-test passes', async () => {
  await page.click('[data-act="diag"]'); await page.waitForSelector('.sheet .banner'); await expectText('.sheet .banner', 'passed');
  const t = await text('.sheet .banner'); if (!/(\d+)\/\1 accounting/.test(t)) throw new Error(t);
});
await step('Dark mode renders', async () => {
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  await page.selectOption('[data-set="theme"]', 'dark'); await page.waitForTimeout(300);
  await page.click('#nav [data-tab="home"]'); await page.waitForTimeout(300); await shot('15-dark-home');
});

await step('Delete a shift (with safety snapshot) and erase all records', async () => {
  await page.click('#nav [data-tab="reports"]'); await page.waitForTimeout(400);
  await page.click('#view [data-shift]'); await page.waitForTimeout(400);
  await page.click('.sheet [data-a="delete"]'); await page.waitForTimeout(350);
  await expectText('.sheet:last-of-type', 'Delete this shift?');
  await page.click('.sheet-foot [data-x="yes"]'); await page.waitForTimeout(700);
  await expectText('#view', 'No shifts in this period');
  await page.click('#nav [data-tab="setup"]'); await page.waitForTimeout(400);
  await expectText('#view', 'Before deleting shift');           // safety snapshot listed
  await page.click('.fab'); await page.waitForTimeout(400);          // make a new practice shift + table
  await page.fill('.sheet [data-money="startingCash"]', '0'); await page.click('.sheet [data-go]'); await page.waitForTimeout(600);
  await page.click('.sheet [data-sheet-close]').catch(() => {}); await page.waitForTimeout(400);
  await page.click('#nav [data-tab="setup"]'); await page.waitForTimeout(400);
  await page.click('[data-act="erase"]'); await page.waitForTimeout(350);
  await page.fill('.sheet:last-of-type input', 'DELETE'); await page.click('.sheet:last-of-type [data-x="yes"]'); await page.waitForTimeout(800);
  await page.click('#nav [data-tab="home"]'); await page.waitForTimeout(400);
  await expectText('#view', 'No active shift');
});
await browser.close(); server.close();
for (const [s, n] of results) console.log(`  ${s} ${n}`);
const failed = results.filter(r => r[0] === '✗').length;
if (errors.length) { console.log('\nBrowser errors:'); errors.forEach(e => console.log('  ' + e)); }
console.log(`\n${results.length - failed}/${results.length} browser checks passed${errors.length ? `, ${errors.length} console error(s)` : ''}`);
process.exit(failed || errors.length ? 1 : 0);
