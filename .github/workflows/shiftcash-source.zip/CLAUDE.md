# ShiftCash: notes for Claude / developers

Offline restaurant-server tip and cash tracker. Vanilla JS ES modules, no bundler.

- `www/`: the app (also Capacitor's `webDir`). Entry point `www/js/app.js`.
- Accounting is pure and tested: `www/js/money.js` (rounding, integer cents), `www/js/ledger.js` (shift summary, settlement, tip-outs, taxes), `www/js/schema.js` (migrations, validation, integrity).
- Storage: `www/js/db.js` picks SQLite (`sqlite-store.js` + `native.js`, Capacitor) or IndexedDB in browsers. All related writes go through `putMany` (atomic).
- Tests: `npm test` (accounting + SQLite), `npm run test:e2e` (Playwright, needs `npx playwright install chromium`).
- Web build: `npm run build:web` creates `dist/web` (stamped service worker + strict CSP + `.htaccess`).
- Android: `node scripts/android-setup.mjs` runs `npx cap add android` if needed, sync, version and signing, then `cd android && ./gradlew assembleDebug`. Needs JDK 21 and the Android SDK. CI: `.github/workflows/build.yml`.

Rules: never store floats for money; never auto-classify rounding or unconfirmed cash as tips; never delete records automatically; keep history on every correction; escape all interpolated HTML (use the `html` tagged template).
Default restaurant policy: cash checks round DOWN (`allowRoundUp: false`), and the restaurant collects rounded totals.
