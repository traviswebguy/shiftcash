// Builds dist/web (the PWA for Namecheap) from www/: stamps the service worker with a content hash
// and the full list of files to cache for offline use. Run: node scripts/build-web.mjs
import { readdirSync, statSync, readFileSync, writeFileSync, mkdirSync, rmSync, cpSync } from 'node:fs';
import { join, relative } from 'node:path';
import { createHash } from 'node:crypto';

const root = new URL('..', import.meta.url).pathname;
const src = join(root, 'www'), out = join(root, 'dist', 'web');
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
cpSync(src, out, { recursive: true });
cpSync(join(root, 'hosting', '.htaccess'), join(out, '.htaccess'));

// Strict Content-Security-Policy for the hosted PWA. (The Android app omits it because Capacitor
// injects its native bridge as an inline script.)
const CSP = `<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; font-src 'self'; connect-src 'self' blob: data:; worker-src 'self'; manifest-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none';">`;
const idx = join(out, 'index.html');
writeFileSync(idx, readFileSync(idx, 'utf8').replace('<!--CSP-->', CSP));

const files = [];
(function walk(d) { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else files.push(p); } })(out);
const assets = files.map(f => relative(out, f).split('\\').join('/'))
  .filter(f => f !== 'sw.js' && !f.startsWith('.') && !f.endsWith('.txt'))
  .sort();
const hash = createHash('sha256');
for (const a of assets) hash.update(a).update(readFileSync(join(out, a)));
const version = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version + '-' + hash.digest('hex').slice(0, 10);
const list = ['./', ...assets.map(a => './' + a)];
const sw = readFileSync(join(out, 'sw.js'), 'utf8').replace('__VERSION__', version).replace('__ASSETS__', JSON.stringify(list, null, 2));
writeFileSync(join(out, 'sw.js'), sw);
console.log(`dist/web built: ${list.length} files cached offline, version ${version}`);
