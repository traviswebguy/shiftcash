// Prepares the native Android project with the official Capacitor CLI, then applies ShiftCash settings.
//  1. `npx cap add android` (only if android/ does not exist yet — generates all native project files)
//  2. app icons from resources/icon-only.png (via @capacitor/assets, optional)
//  3. `npx cap sync android` (copies www/ and installs native plugins)
//  4. version + signing configuration in android/app/build.gradle:
//     - versionName from package.json, versionCode from VERSION_CODE env (CI run number) or a date stamp
//     - debug builds use applicationId suffix ".debug" so a test build and the real app can coexist
//     - release builds are signed when SHIFTCASH_KEYSTORE* environment variables are present
import { existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { join } from 'node:path';
import { homedir } from 'node:os';

const root = new URL('..', import.meta.url).pathname;
const run = (cmd, opts = {}) => { console.log('› ' + cmd); execSync(cmd, { stdio: 'inherit', cwd: root, ...opts }); };
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));

if (!existsSync(join(root, 'android'))) run('npx cap add android');
else console.log('android/ already exists — keeping it');

try { run('npx @capacitor/assets generate --android --assetPath resources --iconBackgroundColor "#0A3520" --iconBackgroundColorDark "#0A3520" --splashBackgroundColor "#0A3520" --splashBackgroundColorDark "#0A3520"'); }
catch { console.warn('Icon generation skipped (default icons will be used).'); }

run('npx cap sync android');

// Shared, non-secret debug key so every debug APK can update the previous one in place (keeps data).
const dbg = join(homedir(), '.android');
mkdirSync(dbg, { recursive: true });
copyFileSync(join(root, 'android-config', 'debug.keystore'), join(dbg, 'debug.keystore'));

const gradlePath = join(root, 'android', 'app', 'build.gradle');
let g = readFileSync(gradlePath, 'utf8');
const versionCode = parseInt(process.env.VERSION_CODE || '', 10) || Math.floor(Date.now() / 60000 - 29_000_000);
g = g.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`).replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`);

if (!g.includes('// shiftcash-signing')) {
  g = g.replace(/android\s*\{/, `android {
    // shiftcash-signing
    signingConfigs {
        shiftcashRelease {
            def ks = System.getenv("SHIFTCASH_KEYSTORE_FILE")
            if (ks != null && new File(ks).exists()) {
                storeFile file(ks)
                storePassword System.getenv("SHIFTCASH_KEYSTORE_PASSWORD")
                keyAlias System.getenv("SHIFTCASH_KEY_ALIAS")
                keyPassword System.getenv("SHIFTCASH_KEY_PASSWORD")
            }
        }
    }`);
  g = g.replace(/buildTypes\s*\{/, `buildTypes {
        debug {
            applicationIdSuffix ".debug"
            versionNameSuffix "-debug"
        }`);
  g = g.replace(/release\s*\{/, `release {
            if (System.getenv("SHIFTCASH_KEYSTORE_FILE") != null) { signingConfig signingConfigs.shiftcashRelease }`);
}
writeFileSync(gradlePath, g);
console.log(`Android project ready: version ${pkg.version} (code ${versionCode})`);
