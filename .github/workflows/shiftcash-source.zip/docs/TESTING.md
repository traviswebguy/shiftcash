# ShiftCash: testing & verification

## Automated suites (run on every GitHub build)

| Command | What it covers |
|---|---|
| `node tests/run.mjs` | Accounting engine. The same cases also run on the phone under **Settings → Run tests**. |
| `node --no-warnings tests/storage.mjs` | The Android SQLite storage layer, run against a real SQLite engine: atomic writes, rollback of interrupted writes, data surviving a reopen, migrations, integrity check, checksummed and encrypted backups. |
| `node scripts/build-web.mjs && node tests/e2e.mjs` | The real web app in headless Chromium: start shift, cash, card, split and "tip later" entries, reload, **airplane-mode reopen** through the service worker, history, settlement, taxes, backup, self-test, dark mode. |

## Latest results (run while building this package)

```
  ✓ Parse money strings into cents
  ✓ Keypad entry shifts digits in from the right
  ✓ Exact cash payment (no rounding needed)
  ✓ Ticket rounded up to whole dollar
  ✓ Ticket rounded down to whole dollar
  ✓ Half-dollar: rounds up by default, down when configured
  ✓ Always up / always down / exact / manual
  ✓ Rounding the change amount instead of the ticket
  ✓ Original ticket total is never modified
  ✓ Customer says keep the change → confirmed tip
  ✓ Unreturned change is NOT a tip unless confirmed
  ✓ Excessive change returned is flagged
  ✓ Cash tip left after change is not double counted
  ✓ Kept tip cannot exceed actual excess
  ✓ Underpayment detected
  ✓ Card payment with additional cash tip
  ✓ Split check: payments sum, ticket not double counted
  ✓ Multiple checks at one table, table reused later
  ✓ Partial payment leaves outstanding balance
  ✓ Discounts and comps reduce billable total only
  ✓ Refund and voided check / payment
  ✓ Tip-outs, cash removed and added mid-shift
  ✓ Settlement: rounded vs original basis and card-tip deduction
  ✓ Missing card tips & outstanding card tips
  ✓ Restaurant settlement discrepancies are reported, not forced
  ✓ Cash counter totals bills and coins
  ✓ Hours after unpaid breaks; paid breaks count
  ✓ Shift crossing midnight
  ✓ Double shift: lunch + dinner segments aggregate
  ✓ Backup round trip preserves every record
  ✓ Unsafe or malformed imports are rejected
  ✓ Migration v1 → v2 upgrades old records
  ✓ CSV export neutralises spreadsheet formulas
  ✓ Spec example: $42.65 ticket, $60 given → $43 payable, $17 change, +$0.35 rounding, $0 tip
  ✓ Card payment without a tip
  ✓ Card tip entered later (pending → entered) without duplicating sales
  ✓ Customer walkout: no sales, no cash, flagged — not a shortage of your cash
  ✓ Card tips paid in cash at checkout (policy: paid separately)
  ✓ Card tips offset against cash owed (policy: deducted)
  ✓ Card tips through payroll stay outstanding and are never physical cash
  ✓ Settlement after a cash shortage (too much change) shows the shortage
  ✓ Spec example: card tips $62 vs restaurant $52 → $10 discrepancy pointing to a $10 tip
  ✓ Spec example: 10 AM–9 PM double with 2-hour unpaid break = 9 hours
  ✓ Tip-outs: fixed, % of sales, % of tips (integer cents)
  ✓ Monthly tax record summary compares retained vs reported tips
  ✓ Default cash discount: $42.65 rounds DOWN to $42, $18 change, −$0.65 discount, restaurant collects $42
  ✓ Round-up disabled: no option can make the customer pay more than the ticket
  ✓ Full shift reconciles with no double counting
  ✓ Create schema and save related records atomically
  ✓ Interrupted / failing write is rolled back completely
  ✓ Active shift and records survive closing and reopening the database (app restart)
  ✓ Integer cents are stored exactly (no floating point drift)
  ✓ Meta values (schema version) persist
  ✓ Database migration upgrades stored v1 records in one transaction
  ✓ SQLite integrity check passes and detects unreadable rows
  ✓ Restore "replace" swaps stores atomically
  ✓ Accounting integrity check flags orphans and duplicate active shifts
  ✓ Backup: checksum verified, tampering detected
  ✓ Encrypted backup round trip; wrong password rejected

48/48 accounting tests passed
11/11 storage & backup tests passed

  ✓ App loads with empty database
  ✓ Start shift with $50 starting cash
  ✓ Cash: $42.65 ticket, $60 given → rounds DOWN to $42, $18 change (cash discount)
  ✓ Card: $32.00 ticket, $6.00 tip, entered on the same open screen
  ✓ Split: $90 ticket — $45 card ($9 tip) + $45 cash
  ✓ Dashboard totals: tips $15.00, sales $164.65, 3 checks
  ✓ Active shift and records survive reload (app closed/reopened)
  ✓ Service worker caches the app for offline use
  ✓ Reopen with no internet (airplane mode): app and data load
  ✓ Offline: log another card table ($20, no tip) and it saves
  ✓ Card "Tip later", then enter the tip from the transaction detail (no duplicate sale)
  ✓ Tables tab lists transactions with filters
  ✓ Transaction detail opens with full cash breakdown
  ✓ Settlement wizard: compare POS report, count cash, close shift
  ✓ Tip Records & Taxes shows the year summary
  ✓ Backup creates a verified file
  ✓ In-app self-test passes
  ✓ Dark mode renders
18/18 browser checks passed
```

## What has NOT been verified yet

- **The Android APK has not been built or run yet.** The GitHub workflow builds it. Treat the APK as unverified until that workflow shows a green check and the app passes the on-device checks below.
- **The Capacitor SQLite plugin calls** (`createConnection`, `open`, `execute`, `query`, `executeSet`) can only run on a device. The SQL behind them is tested above. If the plugin fails, the app automatically falls back to IndexedDB. **Settings → Storage & offline → Database** shows which one is in use.
- **Device restart, screen lock and the Android back button** need a manual check on the phone (below).

## Manual on-device checklist
1. Settings → **Run tests**: everything passes. Settings → **Integrity check**: no problems.
2. Start a shift and log a cash table. Swipe the app away, reopen it: the shift is still active and the table is there.
3. **Restart the phone**, open the app: the shift is still active.
4. Turn on airplane mode. Open the app, log a table, run settlement: everything works.
5. Lock the screen mid-entry, unlock: the app is still there. With a PIN set, it locks after the chosen delay.
6. Settings → Back up now (try once with a password). Then Restore → Merge: no errors, totals unchanged.
7. Attach a receipt photo, redact part of it, save. It shows in the transaction detail.
8. Install a newer test build over the old one: all records are still there.
