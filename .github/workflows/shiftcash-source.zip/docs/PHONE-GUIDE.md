# ShiftCash: setup guide using only an Android phone

## Everyday use (Simple mode)
1. **New table** → type the table number → **Next** → type the bill (every digit: 4 2 6 5 = $42.65) → **Next**.
2. Tap **Cash** or **Card**.
   - **Card** saves right away.
   - **Cash**: tap the bills they gave you (+$20, +$50…). **GIVE BACK** shows the change. Tap **Save**.
   - **Split**: add each part with **+ Card part** or **+ Cash part** until it says **All paid**, then **Save**. Cash parts show their own change.
   - **Several checks at one table** (big parties): enter each check as a **New table** with the same table number. The app groups them under that table, and **+ Another check** adds the next one quickly.
3. When the table leaves, tap it under **Waiting for tip**, type the tip, and tap **Close table** (or **No tip**).
4. At the end, tap **End of night**. It shows your tips and what to pay the restaurant. Tap **Finish night**.

Everything else (splits, corrections, the full settlement with the restaurant printout, reports, backups) is under **More details & settings**.

---


You get two ways to test ShiftCash. Neither one needs a computer.

| | **A. Web app (PWA)** | **B. Android APK** |
|---|---|---|
| Where it runs | Chrome, then "Add to Home screen" | Installed like any Android app |
| Storage | Browser storage (IndexedDB) | SQLite inside the app |
| Built by | Nothing to build. Upload the files | GitHub's cloud computers |
| Best for | Trying it today | Daily use |

> Records always stay on the phone. A web-app install and an APK install keep **separate** records. Use **Settings → Back up now** and **Restore** to move data between them.

---

## A. Web app on your Namecheap hosting (about 10 minutes)

1. On your phone, download **`shiftcash-web-upload.zip`**.
2. Open Namecheap → **cPanel** → **File Manager**.
3. Open `public_html`. Create a folder named **`shiftcash`** and open it.
   - You can upload into `public_html` directly instead, but then the app becomes your whole website.
4. Tap **Upload**, then choose `shiftcash-web-upload.zip`.
5. Back in File Manager, select the zip → **Extract** → extract into `/public_html/shiftcash`. Delete the zip afterwards.
6. Check that the folder contains `index.html`, `sw.js`, `manifest.webmanifest`, the folders `css`, `js`, `fonts`, `icons`, and **`.htaccess`**.
   - Hidden files: Settings (top right) → *Show Hidden Files*.
7. Your site **must use HTTPS**. Offline mode and installing only work over HTTPS. In cPanel, open **SSL/TLS Status** and run **AutoSSL** if the domain isn't covered.
8. On the phone, open Chrome and go to `https://yourdomain.com/shiftcash/`.
9. Chrome menu (⋮) → **Add to Home screen** (or **Install app**).
10. Open ShiftCash from the home-screen icon. Go to **Settings → Storage & offline**. Check that it says **Offline ready: Yes**, then tap **Persistent storage → request** if it isn't granted yet.

### Check that offline really works
1. Open ShiftCash once while online. Wait about 5 seconds, then close it.
2. Turn on **Airplane mode**.
3. Open ShiftCash from the home screen. It should load with your data, and the top bar shows **Offline**.
4. Start a shift, log a table, close the app fully (swipe it away), and reopen it. The shift and table are still there.
5. Turn Airplane mode off.

### Updating the web app
Upload and extract a new `shiftcash-web-upload.zip` over the old files. Next time the app is opened online, it shows **"Update ready"**. Tap **Update**. Your records are not touched, because only the app's program files are replaced.

---

## B. Android APK built by GitHub (about 15 minutes the first time)

### One-time setup
1. Create a free account at **github.com** (in Chrome on your phone).
2. Tap **+** → **New repository**. Name it `shiftcash` and choose **Private**. Tap **Create repository**.
3. **Add the build instructions file:**
   - In the repository, tap **Add file → Create new file**.
   - In the name box, type exactly: `.github/workflows/build.yml` (the slashes create folders).
   - Open the file **`build.yml`** from the downloads, select all, copy, and paste it into the big box.
   - Tap **Commit changes**.
   - A first build starts right away and **fails** with "package.json not found". That's expected, because the app isn't uploaded yet.
4. **Upload the app:**
   - Tap **Add file → Upload files**.
   - Choose **`shiftcash-source.zip`**. **Do not unzip it** and **do not rename it**.
   - Tap **Commit changes**.
5. Tap the **Actions** tab. A run called **Build ShiftCash** starts automatically. It takes about 8–15 minutes.
   - Green check: success.
   - Red X: tap it, open the step with the X, and send me the error text.

### Install the APK
1. In your repository, open **Releases** (on the main page, or go to `github.com/YOURNAME/shiftcash/releases`).
2. Open **"ShiftCash test build N"** and tap the **`.apk`** file to download it.
   - The APK is also under **Actions → the run → Artifacts → shiftcash-debug-apk**. That one is a zip you'd have to extract.
3. Open the downloaded APK. Android asks you to allow **"Install unknown apps"** for Chrome or your Files app. Allow it, then tap **Install**.
4. Open **ShiftCash**. Go to **Settings → Storage & offline**. It should say **Database: SQLite (Android app)**.
   - If it says IndexedDB, the native database didn't load. The app still works, but tell me.
5. Tap **Run tests** in Settings. Every test should pass.

### Getting a new test build
Upload a new `shiftcash-source.zip` the same way: **Add file → Upload files**, with the same name, and commit. GitHub builds again.

Install the new APK **over** the old one. **Your data stays**, because every test build is signed with the same project debug key.

### Optional: let GitHub email you
Go to github.com → your picture → **Settings → Notifications → Actions**. Turn on notifications for failed or successful workflows.

---

## C. Moving from the test (debug) APK to a real release APK

The two versions are separate apps:

- **Test builds** are `com.shiftcash.app.debug`.
- **Release builds** are `com.shiftcash.app` and are signed with *your own* permanent key.

They can be installed side by side. Moving to release never forces an uninstall.

### One time: create your release key (in the cloud)
1. Repository → **Settings → Secrets and variables → Actions → New repository secret**.
   - Name: `SHIFTCASH_KEYSTORE_PASSWORD`
   - Value: a long password you will **keep forever**. Store it in your password manager.
2. **Actions** → **Create release signing key (one time)** → **Run workflow** → type `CREATE` → **Run**.
3. When it finishes, open the run and **download the `release-key` artifact right away** (it's deleted after 1 day). It contains:
   - `shiftcash-release.jks`: your key. **Save it in two safe places**, such as Google Drive plus email to yourself.
   - `keystore.b64.txt`: the same key as text.
4. Add three more secrets:
   - `SHIFTCASH_KEYSTORE_BASE64`: the entire contents of `keystore.b64.txt`. Open it in a text viewer, select all, copy, and paste.
   - `SHIFTCASH_KEY_ALIAS`: `shiftcash`
   - `SHIFTCASH_KEY_PASSWORD`: the same password as step 1.
5. From now on, every build **also** produces **shiftcash-release-apk** (under Actions → run → Artifacts).

### Move your data from the test app to the release app
1. In the **test** app: **Settings → Back up now**. Saving it to Google Drive is recommended.
2. Install the **release** APK. It appears as a second ShiftCash.
3. In the **release** app: **Settings → Restore** → pick the backup → **Replace all**.
4. Check your shifts and totals. Then you may uninstall the test app.

### Rules that protect your data in future updates
- **Always sign release updates with the same key.** If the key is lost, Android refuses to install updates over the existing app. You would have to back up, uninstall and restore.
- Every build gets a higher version number automatically (the GitHub run number), so Android accepts it as an update.
- **Install updates over the existing app. Never uninstall first.** Uninstalling deletes the app's data.
- Make a backup before each update anyway. It takes a second.
- Database changes between versions are migrated automatically when the app opens, and your records are kept.

---

## D. Hosting the APK on Namecheap (optional)
Upload the APK into `public_html/shiftcash/download/` with File Manager. The included `.htaccess` already sends `.apk` files with the correct Android type. Share the link `https://yourdomain.com/shiftcash/download/ShiftCash-v1.0.0.apk`. The server only stores the installer and never your records.
