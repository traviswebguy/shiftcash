# ShiftCash accounting rules

Every amount is an **integer number of cents**. Nothing is ever calculated with floating-point dollars. Original ticket totals are never modified.

## Cash rounding

**Default for this restaurant: cash checks round DOWN to the whole dollar.** The cents are a cash discount. Rounding up is switched off. While it is off, no option in the app can make a customer pay more than the ticket:
- "round up" and "nearest" are hidden;
- "round change" is hidden (rounding change *down* would mean the customer pays more);
- a manual override can't exceed the ticket.

Example: ticket $42.65, customer hands $60.00.
- Rounded payable: **$42.00**. Expected change: **$18.00**. Rounding adjustment: **−$0.65** (discount). Tip: **$0** unless confirmed.
- With the default settlement basis *"restaurant collects rounded totals"*, the restaurant is owed $42.00, so the discount doesn't cost the server anything.

If round-up is enabled in Settings, these methods are available:

| Method | Ticket target | Change target |
|---|---|---|
| Nearest | 1–49¢ down, 51–99¢ up | change rounded the same way |
| Always up | next whole dollar | change rounded up (customer pays less) |
| Always down | previous whole dollar | change rounded down (customer pays more) |
| Exact | no rounding | no rounding |
| Manual | you type the payable amount | — |

**Half-dollar rule (nearest only):** exactly $0.50 rounds **up** by default. It can be set to round **down** in Settings. If the customer hands over less than the ticket, change-rounding falls back to ticket rounding.

## Cash payment fields
- `roundedDue`: what the customer actually pays.
- `roundingAdj` = roundedDue − ticket. Tracked separately. **Never a tip.**
- `expectedChange` = received − roundedDue.
- `excess` = expectedChange − changeGiven, when positive. This is cash kept but **not a tip** until the customer confirms it ("Keep the change").
- `shortage` = changeGiven − expectedChange, when positive. This is a possible cash shortage, and the app warns immediately.
- `extraTip`: cash left after change was returned. It adds to cash and tips only, so the payment itself is not counted twice.
- Cash added to the apron = received − changeGiven + extraTip.

## Card payments
- Never rounded. Final card charge = ticket portion + card tip.
- Tip states: **pending** (waiting for the signed receipt; counts $0 until entered), **entered**, **confirmed**, **disputed**.
- An entered tip is *earned*. It is never assumed to be *received*. Received card tips come only from payouts:
  - deducted from the settlement,
  - paid in cash,
  - paid through payroll or later (marked paid in Reports).

## Checks, visits, payments
- A **check** has one ticket total and any number of payments. Sales are counted from payments, so split checks are never double-counted.
- A **visit** groups separate checks for one party. **Tables** = distinct table numbers. Table numbers can be reused all shift.
- Discounts and comps reduce the amount due but leave the original ticket intact.
- A refund is a negative payment. A cash refund also leaves the apron.
- Voided checks and payments stay in history and are excluded from totals.
- A walkout is flagged. It doesn't count as a sale, as owed cash, or as a cash shortage.

## Physical cash vs. income
Expected physical cash =
- starting personal cash
- \+ cash taken in from payments (net of change) + extra cash tips
- \+ cash added + card tips paid to you in cash during the shift
- − tip-outs paid in cash − cash removed − cash paid to the restaurant mid-shift − cash refunds

Starting cash is **not income**. Restaurant money is **not tips**. Unpaid card tips are **not cash**.

## Restaurant settlement
Expected amount owed to the restaurant =
- cash collected: original **or** rounded cash totals, per policy, minus cash refunds
- − card tips, *if the policy deducts them* (minus any already paid to you separately)
- \+ tip-outs the restaurant pays on your behalf
- − cash already paid during the shift
- ± custom adjustments

A negative result means the restaurant owes you. Reported POS figures are compared line by line (reported − yours). Differences are flagged with **possible causes**, such as a card tip that equals the gap, an unentered tip, or rounding totals. They are **never forced to balance** and never presented as wrongdoing.

## Tip records & taxes
Monthly and annual summaries cover cash tips, card tips, tip-outs, net retained tips, tips received, tips outstanding, and the tips you report to your employer. The app warns when recorded and reported tips differ. W-2 boxes 1, 7 and 8 can be compared with your records. Qualified-tip-deduction rules are entered by you as yearly notes. ShiftCash does not decide eligibility or give tax advice.
